import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  GameScreen,
  BattlePhase,
  BossData,
  PlayerSaveData,
  GameSettings,
  InventoryItem,
  SoulSkin,
  BattleStats,
} from './types/game';
import { BOSSES } from './data/bosses';
import { SOUL_SKINS, INITIAL_ACHIEVEMENTS } from './data/shop';
import {
  loadSavedGame,
  saveGame,
  loadSettings,
  saveSettings,
  resetProgress,
} from './utils/storage';
import { soundManager } from './audio/soundManager';

// Components
import { MainMenu } from './components/MainMenu';
import { BossSelect } from './components/BossSelect';
import { BestiaryModal } from './components/BestiaryModal';
import { ProfileModal } from './components/ProfileModal';
import { ShopModal } from './components/ShopModal';
import { SettingsModal } from './components/SettingsModal';
import { InfoModal } from './components/InfoModal';
import { SoulNewsModal } from './components/SoulNewsModal';
import { BattleHistoryModal } from './components/BattleHistoryModal';
import { ChallengesModal } from './components/ChallengesModal';
import { PixelBoss } from './components/PixelBoss';
import { BattleArena } from './components/BattleArena';
import { BattleControls } from './components/BattleControls';
import { CombatResultsModal } from './components/CombatResultsModal';
import { AndroidPackageModal } from './components/AndroidPackageModal';

import { Pause, Play, Volume2, VolumeX, Heart, Shield, Maximize2 } from 'lucide-react';

const MAX_ITEMS_PER_BATTLE = 3;

export default function App() {
  const [playerData, setPlayerData] = useState<PlayerSaveData>(() => loadSavedGame());
  const [settings, setSettings] = useState<GameSettings>(() => loadSettings());

  const [currentScreen, setCurrentScreen] = useState<GameScreen>('MENU');

  // Battle State
  const [activeBoss, setActiveBoss] = useState<BossData>(() => BOSSES[0]);
  const [bossHp, setBossHp] = useState<number>(() => BOSSES[0].maxHp);
  const [bossPhaseNumber, setBossPhaseNumber] = useState<number>(1);
  const [playerHp, setPlayerHp] = useState<number>(() => playerData.maxHp);
  const [battlePhase, setBattlePhase] = useState<BattlePhase>('MENU_SELECT');
  const [statusMessage, setStatusMessage] = useState<string>('');
  const [isBossHit, setIsBossHit] = useState<boolean>(false);
  const [isBossAttacking, setIsBossAttacking] = useState<boolean>(false);
  const [isPaused, setIsPaused] = useState<boolean>(false);
  const [isMercyWin, setIsMercyWin] = useState<boolean>(false);

  // Battle Tracking Stats
  const [battleDamageTaken, setBattleDamageTaken] = useState<number>(0);
  const [battleHitsReceived, setBattleHitsReceived] = useState<number>(0);
  const [battleItemsUsed, setBattleItemsUsed] = useState<number>(0);
  const battleStartTimeRef = useRef<number>(Date.now());
  const battleDodgedProjectilesRef = useRef<number>(0);
  const [finalCombatStats, setFinalCombatStats] = useState<BattleStats | null>(null);

  // Zero-lag Ref-based Movement Vector for Virtual Joystick or D-Pad
  const moveVectorRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });

  // Playtime Tracker
  useEffect(() => {
    const timer = setInterval(() => {
      setPlayerData((prev) => ({
        ...prev,
        playtimeSeconds: prev.playtimeSeconds + 1,
      }));
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Save changes to storage
  useEffect(() => {
    saveGame(playerData);
  }, [playerData]);

  useEffect(() => {
    saveSettings(settings);
    soundManager.toggleMusic(settings.musicEnabled);
    soundManager.toggleSfx(settings.sfxEnabled);
    soundManager.setMusicVolume(settings.musicVolume);
    soundManager.setSfxVolume(settings.sfxVolume);
  }, [settings]);

  // Audio track coordinator
  useEffect(() => {
    if (
      currentScreen === 'MENU' ||
      currentScreen === 'BOSS_SELECT' ||
      currentScreen === 'BESTIARY' ||
      currentScreen === 'PROFILE' ||
      currentScreen === 'SHOP' ||
      currentScreen === 'SETTINGS' ||
      currentScreen === 'INFO' ||
      currentScreen === 'SOUL_NEWS' ||
      currentScreen === 'BATTLE_HISTORY' ||
      currentScreen === 'CHALLENGES' ||
      currentScreen === 'ANDROID_PACKAGE'
    ) {
      soundManager.playMusic('menu');
    } else if (currentScreen === 'BATTLE') {
      const trackNumber = Math.min(activeBoss.number, 8);
      const trackId = `boss${trackNumber}` as 'boss1' | 'boss2' | 'boss3' | 'boss4' | 'boss5' | 'boss6' | 'boss7' | 'boss8';
      soundManager.playMusic(trackId);
    }
  }, [currentScreen, activeBoss]);

  // Start Battle
  const startBattle = useCallback((boss: BossData) => {
    setActiveBoss(boss);
    setBossHp(boss.maxHp);
    setBossPhaseNumber(1);
    setPlayerHp(playerData.maxHp);
    setBattlePhase('MENU_SELECT');
    setIsPaused(false);
    setIsMercyWin(false);
    setFinalCombatStats(null);
    setBattleDamageTaken(0);
    setBattleHitsReceived(0);
    setBattleItemsUsed(0);
    battleDodgedProjectilesRef.current = 0;
    moveVectorRef.current = { x: 0, y: 0 };
    battleStartTimeRef.current = Date.now();
    setStatusMessage(`${boss.nameAr} يستعد للنزال!`);
    setCurrentScreen('BATTLE');
  }, [playerData.maxHp]);

  // Continue last adventure
  const handleContinue = () => {
    const boss = BOSSES.find((b) => b.number === playerData.unlockedBossNumber) || BOSSES[0];
    startBattle(boss);
  };

  // Turn Action Selection
  const handleSelectAction = (action: 'FIGHT' | 'CHECK' | 'ITEM' | 'MERCY') => {
    if (action === 'FIGHT') {
      setBattlePhase('ATTACK_MINIGAME');
    } else if (action === 'CHECK') {
      setBattlePhase('CHECK_INFO');
    } else if (action === 'ITEM') {
      setBattlePhase('ITEM_SELECT');
    } else if (action === 'MERCY') {
      handleMercyAttempt();
    }
  };

  // Check and grant achievements and XP
  const awardXpAndCheckAchievements = (
    earnedXp: number,
    earnedCoins: number,
    isVictory: boolean,
    bossDefeated: BossData,
    itemsUsedCount: number
  ) => {
    setPlayerData((prev) => {
      let newXp = prev.xp + earnedXp;
      let newLevel = prev.level;
      let xpThreshold = newLevel * 200;

      while (newXp >= xpThreshold) {
        newXp -= xpThreshold;
        newLevel++;
        xpThreshold = newLevel * 200;
        soundManager.playLevelUp();
      }

      const newAchievements = [...prev.achievements];
      const newTitles = [...prev.unlockedTitles];
      const newBackgrounds = [...(prev.unlockedBackgrounds || ['bg_cosmic'])];

      // Achievement checks
      if (isVictory && !newAchievements.includes('ach_first_win')) {
        newAchievements.push('ach_first_win');
        if (!newTitles.includes('مبتدئ الأرواح')) newTitles.push('مبتدئ الأرواح');
      }

      const totalDefeatedCount = prev.defeatedBosses.includes(bossDefeated.id)
        ? prev.defeatedBosses.length
        : prev.defeatedBosses.length + 1;

      if (totalDefeatedCount >= 3 && !newAchievements.includes('ach_three_bosses')) {
        newAchievements.push('ach_three_bosses');
        if (!newTitles.includes('صياد الظلام')) newTitles.push('صياد الظلام');
      }

      if (totalDefeatedCount >= 5 && !newAchievements.includes('ach_five_bosses')) {
        newAchievements.push('ach_five_bosses');
        if (!newTitles.includes('فاتح الأرواح')) newTitles.push('فاتح الأرواح');
      }

      if (totalDefeatedCount >= 7 && !newAchievements.includes('ach_all_seven')) {
        newAchievements.push('ach_all_seven');
        if (!newTitles.includes('قاهر الصفر')) newTitles.push('قاهر الصفر');
      }

      // Boss 8: Ancient Bone King special victory rewards (Title: كاسر التاج, Background: bg_bone_throne)
      if (isVictory && bossDefeated.id === 'boss_8') {
        if (!newTitles.includes('كاسر التاج')) newTitles.push('كاسر التاج');
        if (!newBackgrounds.includes('bg_bone_throne')) newBackgrounds.push('bg_bone_throne');
      }

      if (isVictory && itemsUsedCount === 0 && !newAchievements.includes('ach_pure_soul')) {
        newAchievements.push('ach_pure_soul');
      }

      // Hardest boss calculation
      const currentHardestNum = BOSSES.find((b) => b.nameAr === prev.hardestBossDefeated)?.number || 0;
      const newHardest = isVictory && bossDefeated.number > currentHardestNum ? bossDefeated.nameAr : prev.hardestBossDefeated;

      // Boss win/loss records
      const prevRec = prev.bossRecords[bossDefeated.id] || { wins: 0, losses: 0 };
      const updatedRec = {
        wins: isVictory ? prevRec.wins + 1 : prevRec.wins,
        losses: isVictory ? prevRec.losses : prevRec.losses + 1,
      };

      return {
        ...prev,
        level: newLevel,
        xp: newXp,
        totalWins: isVictory ? prev.totalWins + 1 : prev.totalWins,
        totalLosses: isVictory ? prev.totalLosses : prev.totalLosses + 1,
        soulCoins: prev.soulCoins + earnedCoins,
        totalCoinsEarned: prev.totalCoinsEarned + earnedCoins,
        hardestBossDefeated: newHardest,
        achievements: newAchievements,
        unlockedTitles: newTitles,
        unlockedBackgrounds: newBackgrounds,
        bossRecords: {
          ...prev.bossRecords,
          [bossDefeated.id]: updatedRec,
        },
      };
    });
  };

  // Confirm Attack
  const handleConfirmAttack = (damageMultiplier: number) => {
    const baseDamage = 35;
    const finalDamage = Math.round(baseDamage * damageMultiplier);

    setIsBossHit(true);
    setTimeout(() => setIsBossHit(false), 350);

    const nextBossHp = Math.max(0, bossHp - finalDamage);
    setBossHp(nextBossHp);

    setStatusMessage(`ضربة متقنة! ألحقت بـ ${activeBoss.nameAr} ضررًا مقداره ${finalDamage} نقطة.`);

    if (nextBossHp <= 0) {
      handleBossDefeated(false);
      return;
    }

    checkPhaseTransition(nextBossHp);

    setTimeout(() => {
      startEnemyTurn();
    }, 1200);
  };

  // Phase transition check
  const checkPhaseTransition = (hp: number) => {
    const hpPercent = (hp / activeBoss.maxHp) * 100;
    const eligiblePhases = activeBoss.phases
      .filter((p) => hpPercent <= p.hpThresholdPercent)
      .sort((a, b) => b.phaseNumber - a.phaseNumber);

    if (eligiblePhases.length > 0 && eligiblePhases[0].phaseNumber > bossPhaseNumber) {
      const newPhase = eligiblePhases[0];
      setBossPhaseNumber(newPhase.phaseNumber);
      setStatusMessage(`⚠️ ${activeBoss.nameAr} يطلق العنان للمرحلة ${newPhase.phaseNumber}!`);
    }
  };

  // Start Enemy Turn (Dodge Phase)
  const startEnemyTurn = () => {
    setIsBossAttacking(true);
    setBattlePhase('DODGE_PHASE');
    const phase = activeBoss.phases.find((p) => p.phaseNumber === bossPhaseNumber) || activeBoss.phases[0];
    setStatusMessage(phase.dialogue);
  };

  // Dodge Complete with projectile count tracking for challenge
  const handleDodgeComplete = (dodgedCount: number) => {
    battleDodgedProjectilesRef.current += (dodgedCount || 0);
    setIsBossAttacking(false);
    setBattlePhase('MENU_SELECT');
    setStatusMessage(`نجوت من هجوم ${activeBoss.nameAr}! تفاديت بنجاح. حان دورك الآن.`);

    // Progress projectile hunter challenge immediately
    setPlayerData((prev) => {
      const currentChals = { ...(prev.challenges || {}) };
      const hunterChal = currentChals['chal_projectile_hunter'];
      if (!hunterChal || hunterChal.isCompleted) return prev;

      const nextProg = Math.min(30, (hunterChal.currentProgress || 0) + (dodgedCount || 0));
      return {
        ...prev,
        challenges: {
          ...currentChals,
          chal_projectile_hunter: {
            ...hunterChal,
            currentProgress: nextProg,
            isCompleted: nextProg >= 30,
          },
        },
      };
    });
  };

  // Player takes damage
  const handlePlayerHit = (damage: number) => {
    setBattleDamageTaken((prev) => prev + damage);
    setBattleHitsReceived((prev) => prev + 1);

    setPlayerHp((prev) => {
      const nextHp = Math.max(0, prev - damage);
      if (nextHp <= 0) {
        handlePlayerDefeated();
      }
      return nextHp;
    });
  };

  // Use Item
  const handleUseItem = (item: InventoryItem) => {
    if (item.quantity <= 0) return;
    if (battleItemsUsed >= MAX_ITEMS_PER_BATTLE) {
      setStatusMessage('بلغت الحد الأقصى لاستخدام الأدوات في هذه المعركة!');
      return;
    }

    setBattleItemsUsed((prev) => prev + 1);

    setPlayerData((prev) => ({
      ...prev,
      inventory: prev.inventory.map((i) =>
        i.id === item.id ? { ...i, quantity: i.quantity - 1 } : i
      ),
    }));

    if (item.type === 'HEAL_30') {
      const healAmount = 35;
      setPlayerHp((prev) => Math.min(playerData.maxHp, prev + healAmount));
      soundManager.playHeal();
      setStatusMessage(`استخدمت ${item.nameAr} واستعدت ${healAmount} نقطة صحة!`);
    } else if (item.type === 'HEAL_FULL') {
      setPlayerHp(playerData.maxHp);
      soundManager.playHeal();
      setStatusMessage(`استخدمت ${item.nameAr} وامتلأت صحتك بالكامل!`);
    } else if (item.type === 'SHIELD_BUFF') {
      setPlayerData((prev) => ({ ...prev, shieldActiveForBattles: 1 }));
      soundManager.playShield();
      setStatusMessage('تم تفعيل درع الفراغ! تم تخفيض الضرر بنسبة 50%.');
    }

    setTimeout(() => {
      startEnemyTurn();
    }, 1100);
  };

  // Mercy Attempt
  const handleMercyAttempt = () => {
    const hpPercent = (bossHp / activeBoss.maxHp) * 100;
    if (hpPercent <= activeBoss.mercyHpPercentThreshold) {
      soundManager.playMercyChime();
      setStatusMessage(activeBoss.mercyQuote);
      setTimeout(() => {
        handleBossDefeated(true);
      }, 1500);
    } else {
      soundManager.playDamage();
      setStatusMessage(`${activeBoss.nameAr}: "ما زالت روحي مشتعلة! لن أستسلم!"`);
      setTimeout(() => {
        startEnemyTurn();
      }, 1200);
    }
  };

  // Boss Defeat
  const handleBossDefeated = (mercy: boolean) => {
    soundManager.playVictory();
    setIsMercyWin(mercy);

    const dur = Math.round((Date.now() - battleStartTimeRef.current) / 1000);
    const earnedXp = activeBoss.rewardXp;
    const earnedCoins = activeBoss.rewardCoins;

    const willUnlockNext =
      activeBoss.number === playerData.unlockedBossNumber &&
      playerData.unlockedBossNumber < BOSSES.length;

    setPlayerData((prev) => {
      const nextUnlocked = willUnlockNext ? prev.unlockedBossNumber + 1 : prev.unlockedBossNumber;
      const newDefeated = prev.defeatedBosses.includes(activeBoss.id)
        ? prev.defeatedBosses
        : [...prev.defeatedBosses, activeBoss.id];

      // Update battleHistory
      const prevHist = prev.battleHistory?.[activeBoss.id] || {
        bossId: activeBoss.id,
        encounters: 0,
        wins: 0,
        losses: 0,
        bestTimeSeconds: dur,
        lastPlayedAt: Date.now(),
        winStreak: 0,
        lastDurationSeconds: dur,
        lastItemsUsed: battleItemsUsed,
        lastDamageTaken: battleDamageTaken,
      };

      const updatedHist = {
        ...prevHist,
        encounters: prevHist.encounters + 1,
        wins: prevHist.wins + 1,
        winStreak: (prevHist.winStreak || 0) + 1,
        bestTimeSeconds: Math.min(prevHist.bestTimeSeconds || dur, dur),
        lastDurationSeconds: dur,
        lastItemsUsed: battleItemsUsed,
        lastDamageTaken: battleDamageTaken,
        lastPlayedAt: Date.now(),
      };

      // Evaluate Challenges
      const updatedChal = { ...(prev.challenges || {}) };

      // Challenge 1: Flawless (< 45 damage taken)
      if (battleDamageTaken < 45 && updatedChal['chal_flawless']) {
        updatedChal['chal_flawless'] = {
          ...updatedChal['chal_flawless'],
          currentProgress: 1,
          isCompleted: true,
        };
      }

      // Challenge 2: No Heal (0 items used in victory)
      if (battleItemsUsed === 0 && updatedChal['chal_no_heal']) {
        updatedChal['chal_no_heal'] = {
          ...updatedChal['chal_no_heal'],
          currentProgress: 1,
          isCompleted: true,
        };
      }

      // Challenge 4: Endurance (Boss #5+ with > 25% HP)
      const remainingHpPct = (playerHp / prev.maxHp) * 100;
      if (activeBoss.number >= 5 && remainingHpPct > 25 && updatedChal['chal_endurance']) {
        updatedChal['chal_endurance'] = {
          ...updatedChal['chal_endurance'],
          currentProgress: 1,
          isCompleted: true,
        };
      }

      return {
        ...prev,
        unlockedBossNumber: nextUnlocked,
        defeatedBosses: newDefeated,
        shieldActiveForBattles: 0,
        battleHistory: {
          ...(prev.battleHistory || {}),
          [activeBoss.id]: updatedHist,
        },
        challenges: updatedChal,
      };
    });

    awardXpAndCheckAchievements(earnedXp, earnedCoins, true, activeBoss, battleItemsUsed);

    setFinalCombatStats({
      damageTaken: battleDamageTaken,
      hitsReceived: battleHitsReceived,
      itemsUsed: battleItemsUsed,
      durationSeconds: dur,
      bossId: activeBoss.id,
      isVictory: true,
      earnedCoins,
      earnedXp,
    });

    setBattlePhase('VICTORY');
  };

  // Player Defeat
  const handlePlayerDefeated = () => {
    soundManager.playGameOver();
    const dur = Math.round((Date.now() - battleStartTimeRef.current) / 1000);
    const earnedXp = Math.round(activeBoss.rewardXp * 0.25);

    setPlayerData((prev) => {
      const prevHist = prev.battleHistory?.[activeBoss.id] || {
        bossId: activeBoss.id,
        encounters: 0,
        wins: 0,
        losses: 0,
        bestTimeSeconds: 0,
        lastPlayedAt: Date.now(),
        winStreak: 0,
        lastDurationSeconds: dur,
        lastItemsUsed: battleItemsUsed,
        lastDamageTaken: battleDamageTaken,
      };

      const updatedHist = {
        ...prevHist,
        encounters: prevHist.encounters + 1,
        losses: prevHist.losses + 1,
        winStreak: 0,
        lastDurationSeconds: dur,
        lastItemsUsed: battleItemsUsed,
        lastDamageTaken: battleDamageTaken,
        lastPlayedAt: Date.now(),
      };

      return {
        ...prev,
        battleHistory: {
          ...(prev.battleHistory || {}),
          [activeBoss.id]: updatedHist,
        },
      };
    });

    awardXpAndCheckAchievements(earnedXp, 0, false, activeBoss, battleItemsUsed);

    setFinalCombatStats({
      damageTaken: battleDamageTaken,
      hitsReceived: battleHitsReceived,
      itemsUsed: battleItemsUsed,
      durationSeconds: dur,
      bossId: activeBoss.id,
      isVictory: false,
      earnedCoins: 0,
      earnedXp,
    });

    setBattlePhase('GAME_OVER');
  };

  // Next Boss
  const handleNextBoss = () => {
    const nextBoss = BOSSES.find((b) => b.number === activeBoss.number + 1);
    if (nextBoss) {
      startBattle(nextBoss);
    } else {
      setCurrentScreen('MENU');
    }
  };

  // Reset Progress
  const handleResetProgress = () => {
    const fresh = resetProgress();
    setPlayerData(fresh);
    setCurrentScreen('MENU');
  };

  const equippedSkin: SoulSkin =
    SOUL_SKINS.find((s) => s.id === playerData.equippedSkin) || SOUL_SKINS[0];

  const playerHpPercent = Math.max(0, (playerHp / playerData.maxHp) * 100);

  return (
    <div
      className="relative w-screen h-screen bg-[#050508] text-white overflow-hidden flex flex-col items-center justify-between font-['Cairo',sans-serif]"
      style={{
        transform: `scale(${settings.gameScale})`,
        transformOrigin: 'center center',
      }}
    >
      <div className="crt-overlay absolute inset-0 z-40 pointer-events-none opacity-40" />

      {/* 1. Main Navigation Screens */}
      {currentScreen === 'MENU' && (
        <MainMenu
          playerData={playerData}
          onStartAdventure={() => startBattle(BOSSES[0])}
          onContinue={handleContinue}
          onOpenBossSelect={() => setCurrentScreen('BOSS_SELECT')}
          onOpenBestiary={() => setCurrentScreen('BESTIARY')}
          onOpenProfile={() => setCurrentScreen('PROFILE')}
          onOpenShop={() => setCurrentScreen('SHOP')}
          onOpenSettings={() => setCurrentScreen('SETTINGS')}
          onOpenInfo={() => setCurrentScreen('INFO')}
          onOpenNews={() => {
            setPlayerData((p) => ({ ...p, hasReadNewsV21: true }));
            setCurrentScreen('SOUL_NEWS');
          }}
          onOpenHistory={() => setCurrentScreen('BATTLE_HISTORY')}
          onOpenChallenges={() => setCurrentScreen('CHALLENGES')}
          onOpenAndroidPackage={() => setCurrentScreen('ANDROID_PACKAGE')}
        />
      )}

      {currentScreen === 'SOUL_NEWS' && (
        <SoulNewsModal
          playerData={playerData}
          onBackToMenu={() => setCurrentScreen('MENU')}
        />
      )}

      {currentScreen === 'BATTLE_HISTORY' && (
        <BattleHistoryModal
          playerData={playerData}
          onBackToMenu={() => setCurrentScreen('MENU')}
        />
      )}

      {currentScreen === 'CHALLENGES' && (
        <ChallengesModal
          playerData={playerData}
          onUpdatePlayerData={setPlayerData}
          onBackToMenu={() => setCurrentScreen('MENU')}
        />
      )}

      {currentScreen === 'BOSS_SELECT' && (
        <BossSelect
          playerData={playerData}
          onSelectBoss={startBattle}
          onBackToMenu={() => setCurrentScreen('MENU')}
        />
      )}

      {currentScreen === 'BESTIARY' && (
        <BestiaryModal
          playerData={playerData}
          onSelectBoss={startBattle}
          onBackToMenu={() => setCurrentScreen('MENU')}
        />
      )}

      {currentScreen === 'PROFILE' && (
        <ProfileModal
          playerData={playerData}
          onUpdatePlayerData={setPlayerData}
          onBackToMenu={() => setCurrentScreen('MENU')}
        />
      )}

      {currentScreen === 'SHOP' && (
        <ShopModal
          playerData={playerData}
          onUpdatePlayerData={setPlayerData}
          onBackToMenu={() => setCurrentScreen('MENU')}
        />
      )}

      {currentScreen === 'SETTINGS' && (
        <SettingsModal
          settings={settings}
          playerData={playerData}
          onUpdateSettings={setSettings}
          onUpdatePlayerData={setPlayerData}
          onResetProgress={handleResetProgress}
          onBackToMenu={() => setCurrentScreen('MENU')}
          onOpenAndroidPackage={() => setCurrentScreen('ANDROID_PACKAGE')}
        />
      )}

      {currentScreen === 'ANDROID_PACKAGE' && (
        <AndroidPackageModal onBackToMenu={() => setCurrentScreen('MENU')} />
      )}

      {currentScreen === 'INFO' && (
        <InfoModal onBackToMenu={() => setCurrentScreen('MENU')} />
      )}

      {/* 2. Active Combat Screen */}
      {currentScreen === 'BATTLE' && (
        <div className="relative w-full h-full flex flex-col justify-between items-center py-2 max-w-md mx-auto select-none">
          {/* Top HUD */}
          {(!settings.zenMode || battlePhase !== 'DODGE_PHASE') && (
            <div className="w-full px-3 flex items-center justify-between text-xs z-20">
              <button
                onClick={() => {
                  soundManager.playSelect();
                  setIsPaused(true);
                }}
                className="p-1.5 bg-gray-900 border border-gray-700 hover:bg-gray-800 rounded active:scale-95 text-gray-300"
                title="إيقاف مؤقت"
              >
                <Pause size={16} />
              </button>

              {/* Player Health Bar */}
              <div className="flex-1 max-w-[200px] mx-3">
                <div className="flex items-center justify-between text-[11px] mb-0.5">
                  <span className="flex items-center gap-1 font-bold text-red-400">
                    <Heart size={12} className="fill-red-500 text-red-500" />
                    <span>الروح</span>
                  </span>
                  <span className="font-pixel text-[10px] tabular-nums text-gray-300">
                    {playerHp} / {playerData.maxHp} HP
                  </span>
                </div>
                <div className="w-full h-2.5 bg-gray-900 border border-gray-600 rounded-sm overflow-hidden p-0.5">
                  <div
                    className="h-full bg-red-500 transition-all duration-200 rounded-xs"
                    style={{
                      width: `${playerHpPercent}%`,
                      boxShadow: '0 0 8px rgba(239, 68, 68, 0.8)',
                    }}
                  />
                </div>
              </div>

              {/* Quick Audio Mute */}
              <button
                onClick={() => {
                  const next = !settings.musicEnabled;
                  setSettings({ ...settings, musicEnabled: next, sfxEnabled: next });
                }}
                className="p-1.5 bg-gray-900 border border-gray-700 hover:bg-gray-800 rounded active:scale-95 text-gray-300"
              >
                {settings.musicEnabled ? (
                  <Volume2 size={16} className="text-cyan-400" />
                ) : (
                  <VolumeX size={16} className="text-gray-500" />
                )}
              </button>
            </div>
          )}

          {/* Upper Section: Pixel Boss Sprite & Health */}
          <div className="w-full flex flex-col items-center justify-center my-auto">
            <PixelBoss
              boss={activeBoss}
              currentHp={bossHp}
              maxHp={activeBoss.maxHp}
              currentPhase={bossPhaseNumber}
              isHit={isBossHit}
              isAttacking={isBossAttacking}
            />
          </div>

          {/* Middle Section: Battle Arena (Combat Box with Ref-based Movement & 60FPS physics) */}
          <div className="w-full flex items-center justify-center my-auto">
            <BattleArena
              boss={activeBoss}
              currentPhaseNumber={bossPhaseNumber}
              difficulty={settings.difficulty}
              isDodging={battlePhase === 'DODGE_PHASE'}
              onDodgeComplete={handleDodgeComplete}
              onPlayerHit={handlePlayerHit}
              playerHp={playerHp}
              playerMaxHp={playerData.maxHp}
              equippedSkin={equippedSkin}
              shieldActive={playerData.shieldActiveForBattles > 0}
              externalMoveVectorRef={moveVectorRef}
              settings={settings}
            />
          </div>

          {/* Lower Section: Controls, Actions, & Virtual Joystick */}
          <div className="w-full z-20">
            <BattleControls
              battlePhase={battlePhase}
              boss={activeBoss}
              currentHp={playerHp}
              inventory={playerData.inventory}
              itemsUsedInBattle={battleItemsUsed}
              maxItemsPerBattle={MAX_ITEMS_PER_BATTLE}
              controlType={settings.controlType}
              joystickSize={settings.joystickSize}
              joystickOpacity={settings.joystickOpacity}
              joystickPosition={settings.joystickPosition}
              joystickSensitivity={settings.joystickSensitivity}
              joystickFloating={settings.joystickFloating}
              dpadSize={settings.dpadSize}
              statusMessage={statusMessage}
              onSelectAction={handleSelectAction}
              onConfirmAttack={handleConfirmAttack}
              onUseItem={handleUseItem}
              onMercyAttempt={handleMercyAttempt}
              onDismissCheck={() => startEnemyTurn()}
              moveVectorRef={moveVectorRef}
              isDodging={battlePhase === 'DODGE_PHASE'}
              zenMode={settings.zenMode}
            />
          </div>

          {/* Pause Modal */}
          {isPaused && (
            <div className="absolute inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm select-none">
              <div className="w-full max-w-xs bg-gray-900 border-2 border-gray-600 rounded-xl p-4 flex flex-col items-center gap-3 text-center">
                <h3 className="font-bold text-sm text-white">المعركة متوقفة مؤقتًا</h3>
                <div className="w-full flex flex-col gap-2 mt-2">
                  <button
                    onClick={() => setIsPaused(false)}
                    className="py-2 bg-cyan-600 hover:bg-cyan-500 text-white font-bold rounded text-xs flex items-center justify-center gap-1.5 transition-all"
                  >
                    <Play size={14} />
                    <span>استئناف المعركة</span>
                  </button>
                  <button
                    onClick={() => {
                      setIsPaused(false);
                      setCurrentScreen('MENU');
                    }}
                    className="py-2 bg-gray-800 hover:bg-gray-700 text-gray-300 font-semibold rounded text-xs transition-all"
                  >
                    الانسحاب إلى القائمة الرئيسية
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Combat Results Screen (Victory or Game Over with complete stats) */}
          {finalCombatStats && (battlePhase === 'VICTORY' || battlePhase === 'GAME_OVER') && (
            <CombatResultsModal
              boss={activeBoss}
              stats={finalCombatStats}
              isVictory={battlePhase === 'VICTORY'}
              isMercy={isMercyWin}
              unlockedNextBoss={
                activeBoss.number === playerData.unlockedBossNumber - 1 &&
                playerData.unlockedBossNumber <= 8
              }
              onRetry={() => startBattle(activeBoss)}
              onNextBoss={handleNextBoss}
              onReturnToMenu={() => setCurrentScreen('MENU')}
            />
          )}
        </div>
      )}
    </div>
  );
}
