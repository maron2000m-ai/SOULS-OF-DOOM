import { PlayerSaveData, GameSettings, BattleHistoryEntry } from '../types/game';
import { BOSSES } from '../data/bosses';

const SAVE_KEY_V21 = 'souls_of_doom_save_v2_1';
const LEGACY_V2 = 'souls_of_doom_save_v2';
const LEGACY_V1 = 'souls_of_doom_save_v1';
const SETTINGS_KEY = 'souls_of_doom_settings_v2_1';

const generateInitialBattleHistory = (): Record<string, BattleHistoryEntry> => {
  const history: Record<string, BattleHistoryEntry> = {};
  BOSSES.forEach((b) => {
    history[b.id] = {
      bossId: b.id,
      bossNameAr: b.nameAr,
      encounters: 0,
      wins: 0,
      losses: 0,
      lastResult: 'NONE',
      lastDurationSeconds: 0,
      lastItemsUsed: 0,
      winStreak: 0,
    };
  });
  return history;
};

export const INITIAL_PLAYER_DATA: PlayerSaveData = {
  playerName: 'محارب الأرواح',
  avatar: 'avatar_soul',
  avatarFrame: 'frame_basic',
  profileBg: 'bg_void',
  level: 1,
  xp: 0,
  equippedTitle: 'مبتدئ الأرواح',
  unlockedTitles: ['مبتدئ الأرواح'],
  unlockedFrames: ['frame_basic'],
  unlockedBackgrounds: ['bg_void'],

  currentHp: 60,
  maxHp: 60,
  baseMaxHp: 60,
  hpUpgradesBought: 0,
  soulCoins: 150,
  unlockedBossNumber: 1, // 1 to 7
  defeatedBosses: [],
  selectedBossId: 'boss_1',
  totalWins: 0,
  totalLosses: 0,
  totalCoinsEarned: 150,
  totalCoinsSpent: 0,
  playtimeSeconds: 0,
  hardestBossDefeated: 'لم يُهزم أي زعيم بعد',
  bossRecords: {},
  battleHistory: generateInitialBattleHistory(),

  inventory: [
    {
      id: 'potion_heal_30',
      nameAr: 'جرعة علاج الروح',
      descriptionAr: 'تستعيد 35 نقطة صحة على الفور.',
      type: 'HEAL_30',
      quantity: 2,
      iconName: 'FlaskConical',
    },
    {
      id: 'item_shield',
      nameAr: 'درع الفراغ الواقي',
      descriptionAr: 'يقلل كل الأضرار بنسبة 50%.',
      type: 'SHIELD_BUFF',
      quantity: 1,
      iconName: 'Shield',
    },
  ],
  equippedSkin: 'skin_crimson',
  purchasedSkins: ['skin_crimson'],
  equippedTrail: 'none',
  unlockedTrails: ['none'],
  equippedVictoryAura: 'none',
  unlockedVictoryAuras: ['none'],
  shieldActiveForBattles: 0,

  achievements: [],
  challenges: {
    chal_flawless: { isCompleted: false, isClaimed: false },
    chal_no_heal: { isCompleted: false, isClaimed: false },
    chal_projectile_hunter: { isCompleted: false, isClaimed: false },
    chal_endurance: { isCompleted: false, isClaimed: false },
  },
  dailyRewards: {
    lastClaimDate: '',
    streak: 0,
    bossMilestoneClaimed: false,
  },

  hasReadNewsV21: false,
  lastSaveTimestamp: new Date().toISOString(),
};

export const INITIAL_SETTINGS: GameSettings = {
  musicVolume: 0.6,
  sfxVolume: 0.8,
  musicEnabled: true,
  sfxEnabled: true,
  difficulty: 'NORMAL',
  hapticFeedback: true,

  controlType: 'JOYSTICK',
  joystickSize: 'MEDIUM',
  joystickOpacity: 0.85,
  joystickPosition: 'BOTTOM_LEFT',
  joystickSensitivity: 1.0,
  joystickFloating: false,
  dpadSize: 'MEDIUM',

  gameScale: 1.0,
  isFullscreen: false,
  autoFit: true,
  arenaScale: 1.0,
  heartScale: 'LARGE',
  zenMode: false,
  uiScale: 'NORMAL',

  // Performance & Anti-Lag Settings (v2.1)
  performancePreset: 'BALANCED',
  targetFps: 60,
  reduceParticles: false,
  reduceBloom: false,
  shadowQuality: 'HIGH',
  animatedBackground: true,
  screenShakeEnabled: true,
  graphicsQuality: 'HIGH',
  showPerfHud: false,
};

export function loadSavedGame(): PlayerSaveData {
  try {
    let raw = localStorage.getItem(SAVE_KEY_V21);
    if (!raw) raw = localStorage.getItem(LEGACY_V2);
    if (!raw) raw = localStorage.getItem(LEGACY_V1);
    if (!raw) return { ...INITIAL_PLAYER_DATA };

    const parsed = JSON.parse(raw);
    const initialHistory = generateInitialBattleHistory();

    return {
      ...INITIAL_PLAYER_DATA,
      ...parsed,
      inventory: parsed.inventory || INITIAL_PLAYER_DATA.inventory,
      unlockedTitles: parsed.unlockedTitles || INITIAL_PLAYER_DATA.unlockedTitles,
      purchasedSkins: parsed.purchasedSkins || INITIAL_PLAYER_DATA.purchasedSkins,
      unlockedTrails: parsed.unlockedTrails || INITIAL_PLAYER_DATA.unlockedTrails,
      unlockedFrames: parsed.unlockedFrames || INITIAL_PLAYER_DATA.unlockedFrames,
      unlockedBackgrounds: parsed.unlockedBackgrounds || INITIAL_PLAYER_DATA.unlockedBackgrounds,
      bossRecords: parsed.bossRecords || {},
      battleHistory: {
        ...initialHistory,
        ...(parsed.battleHistory || {}),
      },
      achievements: parsed.achievements || [],
      challenges: {
        ...INITIAL_PLAYER_DATA.challenges,
        ...(parsed.challenges || {}),
      },
      dailyRewards: {
        ...INITIAL_PLAYER_DATA.dailyRewards,
        ...(parsed.dailyRewards || {}),
      },
    };
  } catch (e) {
    console.error('Failed to load save data:', e);
    return { ...INITIAL_PLAYER_DATA };
  }
}

export function saveGame(data: PlayerSaveData): void {
  try {
    const updated = {
      ...data,
      lastSaveTimestamp: new Date().toISOString(),
    };
    localStorage.setItem(SAVE_KEY_V21, JSON.stringify(updated));
  } catch (e) {
    console.error('Failed to save game data:', e);
  }
}

export function loadSettings(): GameSettings {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (!raw) return { ...INITIAL_SETTINGS };
    return { ...INITIAL_SETTINGS, ...JSON.parse(raw) };
  } catch (e) {
    console.error('Failed to load settings:', e);
    return { ...INITIAL_SETTINGS };
  }
}

export function saveSettings(settings: GameSettings): void {
  try {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
  } catch (e) {
    console.error('Failed to save settings:', e);
  }
}

export function resetProgress(): PlayerSaveData {
  try {
    localStorage.removeItem(SAVE_KEY_V21);
    localStorage.removeItem(LEGACY_V2);
    localStorage.removeItem(LEGACY_V1);
  } catch (e) {
    console.error('Failed to clear storage:', e);
  }
  return { ...INITIAL_PLAYER_DATA };
}

export function exportSaveBackup(data: PlayerSaveData): string {
  return JSON.stringify(data, null, 2);
}

export function importSaveBackup(jsonStr: string): PlayerSaveData | null {
  try {
    const parsed = JSON.parse(jsonStr);
    if (parsed && typeof parsed.currentHp === 'number' && Array.isArray(parsed.inventory)) {
      const merged = { ...INITIAL_PLAYER_DATA, ...parsed };
      saveGame(merged);
      return merged;
    }
    return null;
  } catch {
    return null;
  }
}
