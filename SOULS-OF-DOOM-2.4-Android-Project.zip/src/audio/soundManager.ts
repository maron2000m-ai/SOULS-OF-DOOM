/**
 * Procedural Web Audio 8-bit / Chiptune Sound Engine - Update 2.0
 * Completely self-contained, zero external MP3 dependencies.
 */

class SoundEngine {
  private ctx: AudioContext | null = null;
  private musicGain: GainNode | null = null;
  private sfxGain: GainNode | null = null;
  private isMusicMuted: boolean = false;
  private isSfxMuted: boolean = false;
  private musicVolume: number = 0.6;
  private sfxVolume: number = 0.8;
  
  private currentMusicInterval: number | null = null;
  private currentTrack: string | null = null;

  constructor() {}

  private initContext() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioCtx();
      
      this.musicGain = this.ctx.createGain();
      this.musicGain.gain.value = this.isMusicMuted ? 0 : this.musicVolume * 0.4;
      this.musicGain.connect(this.ctx.destination);

      this.sfxGain = this.ctx.createGain();
      this.sfxGain.gain.value = this.isSfxMuted ? 0 : this.sfxVolume;
      this.sfxGain.connect(this.ctx.destination);
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  public setMusicVolume(val: number) {
    this.musicVolume = Math.max(0, Math.min(1, val));
    if (this.musicGain && this.ctx) {
      this.musicGain.gain.setTargetAtTime(
        this.isMusicMuted ? 0 : this.musicVolume * 0.4, 
        this.ctx.currentTime, 
        0.05
      );
    }
  }

  public setSfxVolume(val: number) {
    this.sfxVolume = Math.max(0, Math.min(1, val));
    if (this.sfxGain && this.ctx) {
      this.sfxGain.gain.setTargetAtTime(
        this.isSfxMuted ? 0 : this.sfxVolume, 
        this.ctx.currentTime, 
        0.05
      );
    }
  }

  public toggleMusic(enabled: boolean) {
    this.isMusicMuted = !enabled;
    this.setMusicVolume(this.musicVolume);
  }

  public toggleSfx(enabled: boolean) {
    this.isSfxMuted = !enabled;
    this.setSfxVolume(this.sfxVolume);
  }

  // --- Sound Effects ---

  public playSelect() {
    this.initContext();
    if (this.isSfxMuted || !this.ctx || !this.sfxGain) return;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    const t = this.ctx.currentTime;

    osc.type = 'triangle';
    osc.frequency.setValueAtTime(440, t);
    osc.frequency.exponentialRampToValueAtTime(880, t + 0.08);

    gain.gain.setValueAtTime(0.3, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.08);

    osc.connect(gain);
    gain.connect(this.sfxGain);

    osc.start(t);
    osc.stop(t + 0.09);
  }

  public playDamage() {
    this.initContext();
    if (this.isSfxMuted || !this.ctx || !this.sfxGain) return;

    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(160, t);
    osc.frequency.exponentialRampToValueAtTime(40, t + 0.2);

    gain.gain.setValueAtTime(0.5, t);
    gain.gain.exponentialRampToValueAtTime(0.01, t + 0.22);

    osc.connect(gain);
    gain.connect(this.sfxGain);

    osc.start(t);
    osc.stop(t + 0.23);
  }

  public playAttackSlice(crit: boolean = false) {
    this.initContext();
    if (this.isSfxMuted || !this.ctx || !this.sfxGain) return;

    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = crit ? 'square' : 'sawtooth';
    const baseFreq = crit ? 900 : 600;
    osc.frequency.setValueAtTime(baseFreq, t);
    osc.frequency.exponentialRampToValueAtTime(100, t + (crit ? 0.28 : 0.18));

    gain.gain.setValueAtTime(crit ? 0.6 : 0.4, t);
    gain.gain.exponentialRampToValueAtTime(0.01, t + (crit ? 0.28 : 0.18));

    osc.connect(gain);
    gain.connect(this.sfxGain);

    osc.start(t);
    osc.stop(t + (crit ? 0.3 : 0.2));
  }

  public playLaser() {
    this.initContext();
    if (this.isSfxMuted || !this.ctx || !this.sfxGain) return;

    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(1200, t);
    osc.frequency.exponentialRampToValueAtTime(150, t + 0.15);

    gain.gain.setValueAtTime(0.3, t);
    gain.gain.exponentialRampToValueAtTime(0.01, t + 0.15);

    osc.connect(gain);
    gain.connect(this.sfxGain);

    osc.start(t);
    osc.stop(t + 0.16);
  }

  public playHeal() {
    this.initContext();
    if (this.isSfxMuted || !this.ctx || !this.sfxGain) return;

    const notes = [330, 440, 554, 660, 880];
    const t = this.ctx.currentTime;

    notes.forEach((freq, idx) => {
      if (!this.ctx || !this.sfxGain) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      const noteTime = t + idx * 0.06;

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, noteTime);

      gain.gain.setValueAtTime(0.25, noteTime);
      gain.gain.exponentialRampToValueAtTime(0.001, noteTime + 0.15);

      osc.connect(gain);
      gain.connect(this.sfxGain);

      osc.start(noteTime);
      osc.stop(noteTime + 0.16);
    });
  }

  public playShield() {
    this.initContext();
    if (this.isSfxMuted || !this.ctx || !this.sfxGain) return;

    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(220, t);
    osc.frequency.exponentialRampToValueAtTime(880, t + 0.35);

    gain.gain.setValueAtTime(0.35, t);
    gain.gain.exponentialRampToValueAtTime(0.01, t + 0.4);

    osc.connect(gain);
    gain.connect(this.sfxGain);

    osc.start(t);
    osc.stop(t + 0.42);
  }

  public playMercyChime() {
    this.initContext();
    if (this.isSfxMuted || !this.ctx || !this.sfxGain) return;

    const chord = [523.25, 659.25, 783.99, 1046.50];
    const t = this.ctx.currentTime;

    chord.forEach((freq, i) => {
      if (!this.ctx || !this.sfxGain) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, t + i * 0.05);

      gain.gain.setValueAtTime(0.2, t + i * 0.05);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.8);

      osc.connect(gain);
      gain.connect(this.sfxGain);

      osc.start(t + i * 0.05);
      osc.stop(t + 0.85);
    });
  }

  public playVictory() {
    this.initContext();
    if (this.isSfxMuted || !this.ctx || !this.sfxGain) return;

    const fanfare = [
      { f: 440, d: 0.12 },
      { f: 440, d: 0.12 },
      { f: 440, d: 0.12 },
      { f: 554, d: 0.3 },
      { f: 493, d: 0.15 },
      { f: 554, d: 0.15 },
      { f: 659, d: 0.5 },
    ];

    let offset = 0;
    const t = this.ctx.currentTime;
    fanfare.forEach((n) => {
      if (!this.ctx || !this.sfxGain) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'square';
      osc.frequency.setValueAtTime(n.f, t + offset);

      gain.gain.setValueAtTime(0.3, t + offset);
      gain.gain.exponentialRampToValueAtTime(0.01, t + offset + n.d - 0.02);

      osc.connect(gain);
      gain.connect(this.sfxGain);

      osc.start(t + offset);
      osc.stop(t + offset + n.d);
      offset += n.d;
    });
  }

  public playGameOver() {
    this.initContext();
    if (this.isSfxMuted || !this.ctx || !this.sfxGain) return;

    const notes = [293.66, 277.18, 261.63, 246.94];
    let offset = 0;
    const t = this.ctx.currentTime;

    notes.forEach((freq) => {
      if (!this.ctx || !this.sfxGain) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(freq, t + offset);

      gain.gain.setValueAtTime(0.35, t + offset);
      gain.gain.exponentialRampToValueAtTime(0.01, t + offset + 0.35);

      osc.connect(gain);
      gain.connect(this.sfxGain);

      osc.start(t + offset);
      osc.stop(t + offset + 0.4);
      offset += 0.35;
    });
  }

  // --- New SFX for Update 2.0 ---

  public playLevelUp() {
    this.initContext();
    if (this.isSfxMuted || !this.ctx || !this.sfxGain) return;

    const notes = [440, 554, 659, 880, 1108];
    const t = this.ctx.currentTime;
    notes.forEach((freq, idx) => {
      if (!this.ctx || !this.sfxGain) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      const noteTime = t + idx * 0.07;
      osc.type = 'square';
      osc.frequency.setValueAtTime(freq, noteTime);
      gain.gain.setValueAtTime(0.3, noteTime);
      gain.gain.exponentialRampToValueAtTime(0.001, noteTime + 0.2);
      osc.connect(gain);
      gain.connect(this.sfxGain);
      osc.start(noteTime);
      osc.stop(noteTime + 0.21);
    });
  }

  public playEquip() {
    this.initContext();
    if (this.isSfxMuted || !this.ctx || !this.sfxGain) return;
    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(300, t);
    osc.frequency.exponentialRampToValueAtTime(900, t + 0.12);
    gain.gain.setValueAtTime(0.35, t);
    gain.gain.exponentialRampToValueAtTime(0.01, t + 0.14);
    osc.connect(gain);
    gain.connect(this.sfxGain);
    osc.start(t);
    osc.stop(t + 0.15);
  }

  public playChestOpen() {
    this.initContext();
    if (this.isSfxMuted || !this.ctx || !this.sfxGain) return;
    const t = this.ctx.currentTime;
    const notes = [261.6, 329.6, 392.0, 523.25, 659.25, 783.99];
    notes.forEach((freq, idx) => {
      if (!this.ctx || !this.sfxGain) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      const noteTime = t + idx * 0.05;
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, noteTime);
      gain.gain.setValueAtTime(0.25, noteTime);
      gain.gain.exponentialRampToValueAtTime(0.001, noteTime + 0.3);
      osc.connect(gain);
      gain.connect(this.sfxGain);
      osc.start(noteTime);
      osc.stop(noteTime + 0.32);
    });
  }

  public playScytheSlash() {
    this.initContext();
    if (this.isSfxMuted || !this.ctx || !this.sfxGain) return;
    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(700, t);
    osc.frequency.exponentialRampToValueAtTime(90, t + 0.22);
    gain.gain.setValueAtTime(0.45, t);
    gain.gain.exponentialRampToValueAtTime(0.01, t + 0.24);
    osc.connect(gain);
    gain.connect(this.sfxGain);
    osc.start(t);
    osc.stop(t + 0.25);
  }

  public playDragonRoar() {
    this.initContext();
    if (this.isSfxMuted || !this.ctx || !this.sfxGain) return;
    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const subOsc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(95, t);
    osc.frequency.linearRampToValueAtTime(140, t + 0.2);
    osc.frequency.exponentialRampToValueAtTime(45, t + 0.5);

    subOsc.type = 'square';
    subOsc.frequency.setValueAtTime(55, t);
    subOsc.frequency.exponentialRampToValueAtTime(30, t + 0.5);

    gain.gain.setValueAtTime(0.5, t);
    gain.gain.exponentialRampToValueAtTime(0.01, t + 0.55);

    osc.connect(gain);
    subOsc.connect(gain);
    gain.connect(this.sfxGain);

    osc.start(t);
    subOsc.start(t);
    osc.stop(t + 0.56);
    subOsc.stop(t + 0.56);
  }

  // --- Background Procedural Music Generators ---

  public stopMusic() {
    if (this.currentMusicInterval) {
      clearInterval(this.currentMusicInterval);
      this.currentMusicInterval = null;
    }
    this.currentTrack = null;
  }

  public playMusic(track: 'menu' | 'boss1' | 'boss2' | 'boss3' | 'boss4' | 'boss5' | 'boss6' | 'boss7' | 'boss8') {
    if (this.currentTrack === track) return;
    this.stopMusic();
    this.initContext();
    this.currentTrack = track;

    let notes: number[] = [];
    let tempoMs = 180;
    let waveType: OscillatorType = 'square';

    if (track === 'menu') {
      notes = [220, 261.6, 329.6, 440, 392, 329.6, 261.6, 246.9];
      tempoMs = 240;
      waveType = 'triangle';
    } else if (track === 'boss1') {
      notes = [293.66, 293.66, 587.33, 440, 415.3, 392, 349.23, 293.66, 349.23, 392];
      tempoMs = 140;
      waveType = 'square';
    } else if (track === 'boss2') {
      notes = [329.6, 392, 493.88, 523.25, 493.88, 392, 329.6, 311.13, 329.6, 493.88];
      tempoMs = 120;
      waveType = 'sawtooth';
    } else if (track === 'boss3') {
      notes = [146.83, 146.83, 220, 293.66, 220, 146.83, 196, 185];
      tempoMs = 160;
      waveType = 'sawtooth';
    } else if (track === 'boss4') {
      notes = [330, 493.88, 440, 659.25, 330, 587.33, 523.25, 493.88];
      tempoMs = 130;
      waveType = 'triangle';
    } else if (track === 'boss5') {
      notes = [220, 220, 440, 330, 293.66, 330, 349.23, 392, 440, 523.25, 493.88, 440];
      tempoMs = 110;
      waveType = 'square';
    } else if (track === 'boss6') {
      // Soul Reaper - Ghostly, menacing, chromatic gothic march
      notes = [174.61, 207.65, 261.63, 246.94, 207.65, 174.61, 164.81, 196.0];
      tempoMs = 125;
      waveType = 'sawtooth';
    } else if (track === 'boss7') {
      // The Zero Dragon - Grand climactic dragon boss anthem
      notes = [220, 277.18, 329.63, 440, 493.88, 554.37, 440, 370, 329.63, 277.18];
      tempoMs = 100;
      waveType = 'square';
    } else if (track === 'boss8') {
      // Ancient Bone King - Regal, chilling ancient bone symphony
      notes = [196.0, 233.08, 293.66, 392.0, 369.99, 293.66, 233.08, 220.0, 293.66, 329.63];
      tempoMs = 115;
      waveType = 'sawtooth';
    }

    let noteIndex = 0;
    this.currentMusicInterval = window.setInterval(() => {
      if (this.isMusicMuted || !this.ctx || !this.musicGain) return;

      const freq = notes[noteIndex];
      noteIndex = (noteIndex + 1) % notes.length;

      const t = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const bassOsc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = waveType;
      osc.frequency.setValueAtTime(freq, t);

      bassOsc.type = 'triangle';
      bassOsc.frequency.setValueAtTime(freq / 2, t);

      const dur = tempoMs / 1000 * 0.85;
      gain.gain.setValueAtTime(0.16, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + dur);

      osc.connect(gain);
      bassOsc.connect(gain);
      gain.connect(this.musicGain);

      osc.start(t);
      bassOsc.start(t);
      osc.stop(t + dur + 0.02);
      bassOsc.stop(t + dur + 0.02);
    }, tempoMs);
  }
}

export const soundManager = new SoundEngine();
