import React, { useRef, useState, useCallback, useEffect } from 'react';

interface VirtualJoystickProps {
  onMoveRef: React.MutableRefObject<{ x: number; y: number }>;
  size?: 'SMALL' | 'MEDIUM' | 'LARGE';
  opacity?: number;
  position?: 'BOTTOM_LEFT' | 'BOTTOM_RIGHT' | 'BOTTOM_CENTER';
  sensitivity?: number;
  floating?: boolean;
}

export const VirtualJoystick: React.FC<VirtualJoystickProps> = ({
  onMoveRef,
  size = 'MEDIUM',
  opacity = 0.85,
  position = 'BOTTOM_LEFT',
  sensitivity = 1.0,
  floating = false,
}) => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const [knobPos, setKnobPos] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [isActive, setIsActive] = useState<boolean>(false);
  const touchIdRef = useRef<number | null>(null);
  const baseCenterRef = useRef<{ x: number; y: number } | null>(null);

  // Scaled dimensions
  const dimensions = {
    SMALL: { outer: 96, inner: 40, maxDist: 34, hitRadius: 65 },
    MEDIUM: { outer: 120, inner: 48, maxDist: 44, hitRadius: 80 },
    LARGE: { outer: 144, inner: 56, maxDist: 54, hitRadius: 95 },
  }[size];

  const positionClasses = {
    BOTTOM_LEFT: 'left-3 bottom-3',
    BOTTOM_RIGHT: 'right-3 bottom-3',
    BOTTOM_CENTER: 'left-1/2 -translate-x-1/2 bottom-3',
  }[position];

  const updateJoystickPosition = (clientX: number, clientY: number) => {
    if (!baseCenterRef.current) return;
    const dx = clientX - baseCenterRef.current.x;
    const dy = clientY - baseCenterRef.current.y;
    const dist = Math.hypot(dx, dy);

    const clampedDist = Math.min(dist, dimensions.maxDist);
    const angle = Math.atan2(dy, dx);
    const kx = Math.cos(angle) * clampedDist;
    const ky = Math.sin(angle) * clampedDist;

    setKnobPos({ x: kx, y: ky });

    // Diagonal normalization & sensitivity application
    const rawMagnitude = clampedDist / dimensions.maxDist;
    // Normalized vector strictly clamped between -1 and 1
    const vx = Math.cos(angle) * rawMagnitude * sensitivity;
    const vy = Math.sin(angle) * rawMagnitude * sensitivity;

    onMoveRef.current = {
      x: Math.max(-1, Math.min(1, vx)),
      y: Math.max(-1, Math.min(1, vy)),
    };
  };

  const handlePointerDown = (clientX: number, clientY: number, id: number) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();

    if (floating) {
      baseCenterRef.current = { x: clientX, y: clientY };
    } else {
      baseCenterRef.current = {
        x: rect.left + rect.width / 2,
        y: rect.top + rect.height / 2,
      };
    }

    touchIdRef.current = id;
    setIsActive(true);
    updateJoystickPosition(clientX, clientY);
  };

  const handlePointerMove = useCallback((clientX: number, clientY: number) => {
    if (touchIdRef.current === null || !baseCenterRef.current) return;
    updateJoystickPosition(clientX, clientY);
  }, [dimensions.maxDist, sensitivity]);

  const handlePointerUp = useCallback(() => {
    touchIdRef.current = null;
    baseCenterRef.current = null;
    setIsActive(false);
    setKnobPos({ x: 0, y: 0 });
    onMoveRef.current = { x: 0, y: 0 }; // Immediate zero vector, no lingering inertia
  }, [onMoveRef]);

  // Window event listeners for robust multi-touch tracking
  useEffect(() => {
    if (!isActive) return;

    const onTouchMove = (e: TouchEvent) => {
      for (let i = 0; i < e.touches.length; i++) {
        if (e.touches[i].identifier === touchIdRef.current) {
          handlePointerMove(e.touches[i].clientX, e.touches[i].clientY);
          break;
        }
      }
    };

    const onTouchEnd = (e: TouchEvent) => {
      let touchStillPresent = false;
      for (let i = 0; i < e.touches.length; i++) {
        if (e.touches[i].identifier === touchIdRef.current) {
          touchStillPresent = true;
          break;
        }
      }
      if (!touchStillPresent) {
        handlePointerUp();
      }
    };

    const onMouseMove = (e: MouseEvent) => {
      handlePointerMove(e.clientX, e.clientY);
    };

    const onMouseUp = () => {
      handlePointerUp();
    };

    window.addEventListener('touchmove', onTouchMove, { passive: true });
    window.addEventListener('touchend', onTouchEnd);
    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mouseup', onMouseUp);

    return () => {
      window.removeEventListener('touchmove', onTouchMove);
      window.removeEventListener('touchend', onTouchEnd);
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mouseup', onMouseUp);
    };
  }, [isActive, handlePointerMove, handlePointerUp]);

  return (
    <div
      ref={containerRef}
      onTouchStart={(e) => {
        // Find touch inside hit radius
        const rect = containerRef.current?.getBoundingClientRect();
        if (!rect) return;
        const centerX = rect.left + rect.width / 2;
        const centerY = rect.top + rect.height / 2;

        for (let i = 0; i < e.changedTouches.length; i++) {
          const t = e.changedTouches[i];
          const dist = Math.hypot(t.clientX - centerX, t.clientY - centerY);
          if (dist <= dimensions.hitRadius) {
            handlePointerDown(t.clientX, t.clientY, t.identifier);
            break;
          }
        }
      }}
      onMouseDown={(e) => {
        handlePointerDown(e.clientX, e.clientY, 1);
      }}
      className={`absolute z-30 select-none touch-none flex items-center justify-center ${positionClasses}`}
      style={{
        width: `${dimensions.outer}px`,
        height: `${dimensions.outer}px`,
        opacity,
      }}
    >
      {/* Outer Fixed Ring */}
      <div
        className="w-full h-full rounded-full border-2 border-cyan-400/80 bg-gray-950/80 flex items-center justify-center transition-colors shadow-lg"
        style={{
          boxShadow: isActive
            ? '0 0 16px rgba(6, 182, 212, 0.6), inset 0 0 8px rgba(6, 182, 212, 0.3)'
            : '0 0 8px rgba(6, 182, 212, 0.2)',
        }}
      >
        <div className="absolute w-full h-[1px] bg-cyan-500/20 pointer-events-none" />
        <div className="absolute h-full w-[1px] bg-cyan-500/20 pointer-events-none" />

        {/* Inner Movable Knob */}
        <div
          className="rounded-full bg-gradient-to-br from-cyan-400 to-blue-600 border-2 border-white flex items-center justify-center transition-none pointer-events-none"
          style={{
            width: `${dimensions.inner}px`,
            height: `${dimensions.inner}px`,
            transform: `translate3d(${knobPos.x}px, ${knobPos.y}px, 0)`,
            boxShadow: isActive ? '0 0 12px rgba(56, 189, 248, 0.9)' : 'none',
          }}
        >
          <div className="w-2.5 h-2.5 bg-white rotate-45 rounded-xs" />
        </div>
      </div>
    </div>
  );
};
