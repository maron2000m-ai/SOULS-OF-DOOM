import React, { useState } from 'react';
import { PlayerSaveData } from '../types/game';
import { soundManager } from '../audio/soundManager';
import { ArrowRight, Newspaper, Zap, CheckCircle2, Shield, Sparkles, Clock, Skull, Trophy, History } from 'lucide-react';

interface SoulNewsModalProps {
  playerData: PlayerSaveData;
  onBackToMenu: () => void;
}

export const SoulNewsModal: React.FC<SoulNewsModalProps> = ({ playerData, onBackToMenu }) => {
  const [activeTab, setActiveTab] = useState<'CURRENT' | 'STATUS' | 'HISTORY'>('CURRENT');

  const defeatedCount = playerData.defeatedBosses.length;
  const remainingCount = 7 - defeatedCount;
  const lastDefeated = playerData.hardestBossDefeated || 'لا يوجد بعد';
  const lastAchievement = playerData.achievements.length > 0
    ? playerData.achievements[playerData.achievements.length - 1]
    : 'لم يتم فتح إنجازات بعد';

  return (
    <div className="relative w-full h-full flex flex-col p-4 bg-gradient-to-b from-gray-950 via-black to-gray-950 overflow-y-auto select-none">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-gray-800 pb-3 mb-3">
        <button
          onClick={() => {
            soundManager.playSelect();
            onBackToMenu();
          }}
          className="flex items-center gap-1.5 text-xs text-gray-400 hover:text-white bg-gray-900 border border-gray-700 px-3 py-1.5 rounded active:scale-95 transition-all"
        >
          <ArrowRight size={16} />
          <span>الرئيسية</span>
        </button>

        <h2 className="text-base font-bold text-white flex items-center gap-2">
          <Newspaper size={18} className="text-amber-400" />
          <span>دفتر أخبار الأرواح — SOUL NEWS</span>
        </h2>
      </div>

      {/* Tabs */}
      <div className="grid grid-cols-3 gap-2 mb-3 max-w-md mx-auto w-full">
        <button
          onClick={() => {
            soundManager.playSelect();
            setActiveTab('CURRENT');
          }}
          className={`py-2 rounded-lg text-xs font-bold border transition-all ${
            activeTab === 'CURRENT'
              ? 'bg-amber-950 border-amber-500 text-amber-200'
              : 'bg-gray-900/60 border-gray-800 text-gray-400 hover:bg-gray-800'
          }`}
        >
          تحديث 2.2 👑
        </button>

        <button
          onClick={() => {
            soundManager.playSelect();
            setActiveTab('STATUS');
          }}
          className={`py-2 rounded-lg text-xs font-bold border transition-all ${
            activeTab === 'STATUS'
              ? 'bg-cyan-950 border-cyan-500 text-cyan-200'
              : 'bg-gray-900/60 border-gray-800 text-gray-400 hover:bg-gray-800'
          }`}
        >
          حالة اللعبة 📊
        </button>

        <button
          onClick={() => {
            soundManager.playSelect();
            setActiveTab('HISTORY');
          }}
          className={`py-2 rounded-lg text-xs font-bold border transition-all ${
            activeTab === 'HISTORY'
              ? 'bg-purple-950 border-purple-500 text-purple-200'
              : 'bg-gray-900/60 border-gray-800 text-gray-400 hover:bg-gray-800'
          }`}
        >
          أرشيف التحديثات 🏛️
        </button>
      </div>

      {/* Content Area */}
      <div className="max-w-md mx-auto w-full flex flex-col gap-3 pb-8 text-right text-xs">
        {activeTab === 'CURRENT' && (
          <div className="bg-gray-900/90 border border-gray-800 rounded-2xl p-4 flex flex-col gap-3.5 shadow-xl">
            {/* Version Stamp */}
            <div className="flex items-center justify-between border-b border-gray-800 pb-2">
              <div className="font-pixel text-amber-400 text-sm font-bold">إصدار 2.2 — عودة ملك العظام 👑💀</div>
              <div className="font-pixel text-[10px] text-gray-400 bg-black/60 px-2 py-0.5 rounded border border-gray-700">
                2026-10-28
              </div>
            </div>

            <p className="text-gray-300 leading-relaxed text-[11px]">
              تحديث مدروس يضيف الزعيم الثامن الأسطوري ملك العظام القديم، ساحة عرش العظام، ثلاث مكافآت تجميلية جديدة، والميزة الكبرى: تجهيز اللعبة كتطبيق Android قابل للتثبيت والمشاركة المباشرة!
            </p>

            {/* Boss 8 Highlights */}
            <div className="bg-amber-950/30 border border-amber-600/50 rounded-xl p-3 flex flex-col gap-1.5">
              <span className="font-bold text-amber-300 text-xs flex items-center gap-1.5">
                <Skull size={14} className="text-amber-400" />
                <span>الزعيم الثامن: ملك العظام القديم (عرش العظام)</span>
              </span>
              <ul className="text-[11px] text-gray-300 space-y-1 pr-1 list-disc list-inside">
                <li>هيكل عظمي ملكي ضخم يرتدي تاجًا ذهبيًا متصدعًا وعينين زرقاوين مشتعلتين.</li>
                <li>يطلق صفوف عظام متحركة وحلقات مقذوفات ملكية مع فتحات آمنة للمراوغة.</li>
                <li>سقوط عظام عملاقة بعد ظهور تحذير بصري أحمر واضح في الساحة.</li>
                <li>مكافأة أول انتصار: 700 قطعة روح + لقب «كاسر التاج» + خلفية عرش العظام.</li>
                <li>يفتح فور هزيمة الزعيم السابع (التنين الصفري) وقابل لإعادة التحدي دائمًا.</li>
              </ul>
            </div>

            {/* Android Packaging Feature */}
            <div className="bg-emerald-950/30 border border-emerald-600/50 rounded-xl p-3 flex flex-col gap-1.5">
              <span className="font-bold text-emerald-300 text-xs flex items-center gap-1.5">
                <Zap size={14} className="text-emerald-400" />
                <span>الميزة الكبرى: تجهيز اللعبة كتطبيق Android 📱</span>
              </span>
              <ul className="text-[11px] text-gray-300 space-y-1 pr-1 list-disc list-inside">
                <li>قسم جديد مخصص بالكامل في القائمة والإعدادات لتجهيز وتثبيت ومشاركة اللعبة.</li>
                <li>تثبيت فوري بنقرة واحدة (WebAPK) دون الحاجة لمتجر Google Play أو محرر Rezona.</li>
                <li>تنزيل حزمة APK / PWA مستقلة خفيفة الحجم (~2.38 MB).</li>
                <li>مشاركة اللعبة مع الأصدقاء برابط مباشر ورمز QR للمسح بالكاميرا.</li>
                <li>تشغيل 100% دون اتصال بالإنترنت (Offline Ready) مع حفظ التقدم المحلي.</li>
              </ul>
            </div>

            {/* Shop & Combat Polish */}
            <div className="bg-purple-950/30 border border-purple-600/50 rounded-xl p-3 flex flex-col gap-1.5">
              <span className="font-bold text-purple-300 text-xs flex items-center gap-1.5">
                <Sparkles size={14} className="text-purple-400" />
                <span>إضافات المتجر وتحسينات القتال:</span>
              </span>
              <ul className="text-[11px] text-gray-300 space-y-1 pr-1 list-disc list-inside">
                <li>أثر العظام الأزرق (200 قطعة) — يترك مسار عظام زرقاء خلف الروح.</li>
                <li>إطار «التاج المكسور» (300 قطعة) — إطار مهيب مزين بالذهب والعظام.</li>
                <li>تأثير انتصار «روح الملك» (400 قطعة) — هالة نصر ملكية مشعة عند الفوز.</li>
                <li>إصلاح المقذوفات المعلقة بعد انتهاء الجولات، وتحذير بصري أحمر للهجمات الثقيلة.</li>
              </ul>
            </div>
          </div>
        )}

        {activeTab === 'STATUS' && (
          <div className="bg-gray-900/90 border border-gray-800 rounded-2xl p-4 flex flex-col gap-3 shadow-xl">
            <div className="font-bold text-sm text-cyan-400 border-b border-gray-800 pb-2 flex items-center gap-2">
              <Shield size={16} />
              <span>حالة رحلة المحارب الحالية</span>
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="p-3 bg-gray-950 rounded-xl border border-gray-800 flex flex-col justify-between">
                <span className="text-gray-400 flex items-center gap-1">
                  <Skull size={13} className="text-red-400" />
                  <span>الزعماء المهزومون:</span>
                </span>
                <span className="font-pixel text-sm text-white mt-1">
                  {defeatedCount} / 7
                </span>
              </div>

              <div className="p-3 bg-gray-950 rounded-xl border border-gray-800 flex flex-col justify-between">
                <span className="text-gray-400 flex items-center gap-1">
                  <Trophy size={13} className="text-amber-400" />
                  <span>الزعماء المتبقون:</span>
                </span>
                <span className="font-pixel text-sm text-amber-300 mt-1">
                  {remainingCount} زعماء
                </span>
              </div>

              <div className="p-3 bg-gray-950 rounded-xl border border-gray-800 flex flex-col justify-between">
                <span className="text-gray-400">آخر زعيم تمت هزيمته:</span>
                <span className="text-xs font-bold text-cyan-300 mt-1">
                  {lastDefeated}
                </span>
              </div>

              <div className="p-3 bg-gray-950 rounded-xl border border-gray-800 flex flex-col justify-between">
                <span className="text-gray-400">آخر إنجاز مفتوح:</span>
                <span className="text-xs font-bold text-purple-300 mt-1 truncate">
                  {lastAchievement}
                </span>
              </div>
            </div>

            <div className="p-2.5 bg-gray-950 rounded-xl border border-gray-800/80 flex items-center justify-between text-[11px] text-gray-400">
              <span className="flex items-center gap-1.5">
                <Clock size={13} className="text-blue-400" />
                <span>آخر مزامنة وحفظ تلقائي:</span>
              </span>
              <span className="font-pixel text-[9px] text-gray-300">
                {new Date(playerData.lastSaveTimestamp || Date.now()).toLocaleTimeString('ar-EG')}
              </span>
            </div>
          </div>
        )}

        {activeTab === 'HISTORY' && (
          <div className="flex flex-col gap-2.5">
            <div className="p-3 bg-gray-900 border border-gray-800 rounded-xl">
              <div className="flex items-center justify-between mb-1">
                <span className="font-bold text-white text-xs">إصدار 2.0 — الظلام الصاعد</span>
                <span className="text-[10px] text-gray-500 font-pixel">2026-10-26</span>
              </div>
              <p className="text-[11px] text-gray-400">
                إضافة الزعيمين السادس والسابع (حاصد الأرواح والتنين الصفري)، وإطلاق الملف الشخصي والمكافآت اليومية.
              </p>
            </div>

            <div className="p-3 bg-gray-900 border border-gray-800 rounded-xl">
              <div className="flex items-center justify-between mb-1">
                <span className="font-bold text-white text-xs">إصدار 1.0 — ولادة الأرواح</span>
                <span className="text-[10px] text-gray-500 font-pixel">2026-10-26</span>
              </div>
              <p className="text-[11px] text-gray-400">
                إطلاق اللعبة الأصلية بخمسة زعماء ونظام القتال والمراوغة والمتجر التأسيسي.
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
