import React from 'react';
import { BossData, BattleStats } from '../types/game';
import { soundManager } from '../audio/soundManager';
import { Trophy, Skull, RotateCcw, ArrowRight, Play, Coins, ShieldAlert, Sparkles, HeartCrack } from 'lucide-react';

interface CombatResultsModalProps {
  boss: BossData;
  stats: BattleStats;
  isVictory: boolean;
  isMercy: boolean;
  unlockedNextBoss: boolean;
  onRetry: () => void;
  onNextBoss: () => void;
  onReturnToMenu: () => void;
}

export const CombatResultsModal: React.FC<CombatResultsModalProps> = ({
  boss,
  stats,
  isVictory,
  isMercy,
  unlockedNextBoss,
  onRetry,
  onNextBoss,
  onReturnToMenu,
}) => {
  return (
    <div className="absolute inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md select-none overflow-y-auto">
      <div
        className={`w-full max-w-sm rounded-2xl border-2 p-5 flex flex-col items-center text-center shadow-2xl transition-all ${
          isVictory
            ? 'bg-gray-950 border-amber-500 shadow-[0_0_30px_rgba(245,158,11,0.35)]'
            : 'bg-gray-950 border-red-700 shadow-[0_0_30px_rgba(239,68,68,0.35)]'
        }`}
      >
        {/* Top Icon Emblem */}
        <div
          className={`w-16 h-16 rounded-full flex items-center justify-center mb-2 border-2 ${
            isVictory
              ? 'bg-amber-950/80 border-amber-400 text-amber-400 shadow-[0_0_15px_rgba(245,158,11,0.5)]'
              : 'bg-red-950/80 border-red-500 text-red-500 shadow-[0_0_15px_rgba(239,68,68,0.5)]'
          }`}
        >
          {isVictory ? (
            <Trophy size={32} className="animate-bounce" />
          ) : (
            <HeartCrack size={32} className="animate-pulse" />
          )}
        </div>

        {/* Title */}
        <h2 className="text-lg font-black font-pixel mb-0.5">
          {isVictory
            ? isMercy
              ? 'انتصار بنبل الروح! 🕊️'
              : 'انتصـار سـاحق! ⚔️'
            : 'سقطـت الـروح في الظلام 💀'}
        </h2>
        <p className="text-xs text-gray-400 mb-3">
          {isVictory
            ? `تجاوزت بنجاح معركة ${boss.nameAr} (#${boss.number})`
            : `هزمتك طاقة ${boss.nameAr}، لكن الإرادة لا تموت.`}
        </p>

        {/* Boss 7 Title Special Banner */}
        {isVictory && boss.number === 7 && (
          <div className="w-full p-2 bg-gradient-to-r from-cyan-950 via-blue-950 to-cyan-950 border border-cyan-400 rounded-xl mb-3 text-cyan-200">
            <div className="text-[11px] font-bold flex items-center justify-center gap-1">
              <Sparkles size={13} className="text-cyan-300" />
              <span>لقب أسطوري مكتسب:</span>
            </div>
            <div className="text-sm font-black text-cyan-300 font-pixel mt-0.5">
              👑 قاهر الصفر
            </div>
          </div>
        )}

        {/* Battle Stats Breakdown Grid */}
        <div className="w-full bg-gray-900/90 border border-gray-800 rounded-xl p-3 mb-3 text-right text-xs flex flex-col gap-2">
          <div className="font-bold text-gray-300 border-b border-gray-800 pb-1 flex items-center justify-between">
            <span>تقرير المعركة التكتيكي</span>
            <span className="font-pixel text-[10px] text-gray-500">
              {stats.durationSeconds} ثانية
            </span>
          </div>

          <div className="grid grid-cols-2 gap-2 text-[11px]">
            <div className="bg-gray-950 p-2 rounded border border-gray-800/80 flex items-center justify-between">
              <span className="text-gray-400">الضرر المتلقى:</span>
              <span className="font-pixel text-red-400">{stats.damageTaken} HP</span>
            </div>
            <div className="bg-gray-950 p-2 rounded border border-gray-800/80 flex items-center justify-between">
              <span className="text-gray-400">مرات الإصابة:</span>
              <span className="font-pixel text-amber-400">{stats.hitsReceived}</span>
            </div>
            <div className="bg-gray-950 p-2 rounded border border-gray-800/80 flex items-center justify-between">
              <span className="text-gray-400">أدوات مستخدمة:</span>
              <span className="font-pixel text-purple-400">{stats.itemsUsed}</span>
            </div>
            <div className="bg-gray-950 p-2 rounded border border-gray-800/80 flex items-center justify-between">
              <span className="text-gray-400">الخبرة (XP):</span>
              <span className="font-pixel text-cyan-400">+{stats.earnedXp}</span>
            </div>
          </div>

          {/* Reward Coins */}
          {isVictory && (
            <div className="bg-amber-950/40 border border-amber-600/40 p-2 rounded flex items-center justify-between font-pixel text-amber-300">
              <span className="flex items-center gap-1.5 font-sans font-bold">
                <Coins size={14} className="text-amber-400" />
                <span>مكافأة المعركة:</span>
              </span>
              <span>+{stats.earnedCoins} قطعة روح</span>
            </div>
          )}
        </div>

        {/* Buttons Stack */}
        <div className="w-full flex flex-col gap-2">
          {isVictory && boss.number < 7 && (
            <button
              onClick={() => {
                soundManager.playSelect();
                onNextBoss();
              }}
              className="w-full py-2.5 bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-500 hover:to-amber-400 active:scale-95 text-white font-bold rounded-lg shadow-lg flex items-center justify-center gap-2 text-xs transition-all"
            >
              <Play size={16} className="fill-white" />
              <span>مواجهة الزعيم التالي (#{boss.number + 1})</span>
            </button>
          )}

          <button
            onClick={() => {
              soundManager.playSelect();
              onRetry();
            }}
            className="w-full py-2 bg-gray-800 hover:bg-gray-700 active:scale-95 border border-gray-700 text-gray-200 font-semibold rounded-lg flex items-center justify-center gap-1.5 text-xs transition-all"
          >
            <RotateCcw size={15} />
            <span>إعادة المعركة فورًا</span>
          </button>

          <button
            onClick={() => {
              soundManager.playSelect();
              onReturnToMenu();
            }}
            className="w-full py-2 bg-gray-900 hover:bg-gray-800 active:scale-95 border border-gray-800 text-gray-400 font-semibold rounded-lg flex items-center justify-center gap-1.5 text-xs transition-all"
          >
            <ArrowRight size={15} />
            <span>العودة للقائمة الرئيسية</span>
          </button>
        </div>
      </div>
    </div>
  );
};
