import React, { useState, useEffect, useRef } from 'react';
import {
  BattlePhase,
  BossData,
  InventoryItem,
  DpadSize,
} from '../types/game';
import { soundManager } from '../audio/soundManager';
import { VirtualJoystick } from './VirtualJoystick';
import { Swords, Eye, Sparkles, HeartHandshake, ChevronUp, ChevronDown, ChevronLeft, ChevronRight, X } from 'lucide-react';

interface BattleControlsProps {
  battlePhase: BattlePhase;
  boss: BossData;
  currentHp: number;
  inventory: InventoryItem[];
  itemsUsedInBattle: number;
  maxItemsPerBattle: number;
  controlType: 'JOYSTICK' | 'DPAD' | 'TOUCH_FOLLOW';
  joystickSize?: 'SMALL' | 'MEDIUM' | 'LARGE';
  joystickOpacity?: number;
  joystickPosition?: 'BOTTOM_LEFT' | 'BOTTOM_RIGHT' | 'BOTTOM_CENTER';
  joystickSensitivity?: number;
  joystickFloating?: boolean;
  dpadSize: DpadSize;
  statusMessage: string;
  onSelectAction: (action: 'FIGHT' | 'CHECK' | 'ITEM' | 'MERCY') => void;
  onConfirmAttack: (damageMultiplier: number) => void;
  onUseItem: (item: InventoryItem) => void;
  onMercyAttempt: () => void;
  onDismissCheck: () => void;
  moveVectorRef: React.MutableRefObject<{ x: number; y: number }>;
  isDodging: boolean;
  zenMode?: boolean;
}

export const BattleControls: React.FC<BattleControlsProps> = ({
  battlePhase,
  boss,
  inventory,
  itemsUsedInBattle,
  maxItemsPerBattle,
  controlType,
  joystickSize = 'MEDIUM',
  joystickOpacity = 0.85,
  joystickPosition = 'BOTTOM_LEFT',
  joystickSensitivity = 1.0,
  joystickFloating = false,
  dpadSize,
  statusMessage,
  onSelectAction,
  onConfirmAttack,
  onUseItem,
  onMercyAttempt,
  onDismissCheck,
  moveVectorRef,
  isDodging,
  zenMode = false,
}) => {
  const [sliderPos, setSliderPos] = useState<number>(0);
  const attackAnimRef = useRef<number | null>(null);

  const activeDirs = useRef<{ up: boolean; down: boolean; left: boolean; right: boolean }>({
    up: false,
    down: false,
    left: false,
    right: false,
  });

  const updateDpadVector = () => {
    let x = 0;
    let y = 0;
    if (activeDirs.current.left) x -= 1;
    if (activeDirs.current.right) x += 1;
    if (activeDirs.current.up) y -= 1;
    if (activeDirs.current.down) y += 1;
    moveVectorRef.current = { x, y };
  };

  const handleDirStart = (dir: 'up' | 'down' | 'left' | 'right') => {
    activeDirs.current[dir] = true;
    updateDpadVector();
  };

  const handleDirEnd = (dir: 'up' | 'down' | 'left' | 'right') => {
    activeDirs.current[dir] = false;
    updateDpadVector();
  };

  // Attack timing slider animation
  useEffect(() => {
    if (battlePhase === 'ATTACK_MINIGAME') {
      let pos = 0;
      let dir = 1;
      const speed = 2.5;

      const tick = () => {
        pos += dir * speed;
        if (pos >= 100) {
          pos = 100;
          dir = -1;
        } else if (pos <= 0) {
          pos = 0;
          dir = 1;
        }
        setSliderPos(pos);
        attackAnimRef.current = requestAnimationFrame(tick);
      };

      attackAnimRef.current = requestAnimationFrame(tick);
      return () => {
        if (attackAnimRef.current) cancelAnimationFrame(attackAnimRef.current);
      };
    }
  }, [battlePhase]);

  const handleStrike = () => {
    if (attackAnimRef.current) cancelAnimationFrame(attackAnimRef.current);
    const distFromCenter = Math.abs(sliderPos - 50);
    let multiplier = 1.0;
    let crit = false;

    if (distFromCenter <= 6) {
      multiplier = 2.4;
      crit = true;
    } else if (distFromCenter <= 18) {
      multiplier = 1.6;
    } else if (distFromCenter <= 35) {
      multiplier = 1.0;
    } else {
      multiplier = 0.5;
    }

    soundManager.playAttackSlice(crit);
    onConfirmAttack(multiplier);
  };

  const dpadDimensions = {
    SMALL: 'w-10 h-10',
    MEDIUM: 'w-12 h-12',
    LARGE: 'w-14 h-14',
  }[dpadSize];

  const itemsRemaining = Math.max(0, maxItemsPerBattle - itemsUsedInBattle);

  return (
    <div className="w-full max-w-sm flex flex-col gap-2 px-3 py-1 select-none relative">
      {/* 1. Combat Dialogue / Status Box */}
      {(!zenMode || !isDodging) && (
        <div className="bg-black/85 border-2 border-gray-600 rounded p-2.5 min-h-[54px] flex items-center justify-between text-right text-xs leading-relaxed text-gray-200">
          <div className="flex-1">
            <p className="font-semibold text-amber-300 mb-0.5">
              {battlePhase === 'DODGE_PHASE'
                ? '⚡ راوغ الهجمات داخل الساحة!'
                : battlePhase === 'ATTACK_MINIGAME'
                ? '🎯 اضغط في المنتصف لتحقيق ضربة حرجة!'
                : statusMessage || 'اختر أمرًا لمواجهة الزعيم...'}
            </p>
          </div>
        </div>
      )}

      {/* 2. Interactive Phase Centerpiece */}
      {battlePhase === 'ATTACK_MINIGAME' && (
        <div className="bg-gray-950 border-2 border-red-500 rounded p-3 flex flex-col items-center gap-2 shadow-[0_0_15px_rgba(239,68,68,0.3)]">
          <div className="text-xs font-bold text-red-400">مقياس دقة الهجوم</div>
          <div className="relative w-full h-8 bg-gray-900 border-2 border-gray-500 rounded flex items-center overflow-hidden">
            <div className="absolute left-1/2 -translate-x-1/2 w-8 h-full bg-yellow-400/80 border-x-2 border-white flex items-center justify-center">
              <span className="text-[9px] font-bold text-black">حرجة</span>
            </div>
            <div className="absolute left-1/2 -translate-x-1/2 w-24 h-full bg-red-600/30" />
            <div
              className="absolute top-0 bottom-0 w-2.5 bg-white border border-black shadow-[0_0_8px_#ffffff] transition-none"
              style={{ left: `calc(${sliderPos}% - 5px)` }}
            />
          </div>
          <button
            onClick={handleStrike}
            className="w-full py-2.5 bg-red-600 hover:bg-red-500 active:scale-95 text-white font-bold rounded shadow-lg flex items-center justify-center gap-2 text-sm transition-all"
          >
            <Swords size={18} />
            <span>اضـرب الآن!</span>
          </button>
        </div>
      )}

      {/* Check Boss Info */}
      {battlePhase === 'CHECK_INFO' && (
        <div className="bg-gray-900 border-2 border-cyan-500 rounded p-3 flex flex-col gap-2 text-right text-xs">
          <div className="flex items-center justify-between border-b border-gray-700 pb-1">
            <span className="font-bold text-cyan-400">{boss.nameAr}</span>
            <span className="text-gray-400">{boss.titleAr}</span>
          </div>
          <div className="grid grid-cols-2 gap-2 text-gray-300 bg-gray-950/60 p-2 rounded">
            <div>⚔️ {boss.checkInfo.attack}</div>
            <div>🛡️ {boss.checkInfo.defense}</div>
          </div>
          <p className="text-gray-300">{boss.checkInfo.description}</p>
          <div className="bg-amber-950/40 border border-amber-600/40 p-1.5 rounded text-amber-200">
            💡 <span className="font-semibold">نصيحة تكتيكية:</span> {boss.checkInfo.strategy}
          </div>
          <button
            onClick={onDismissCheck}
            className="w-full py-2 bg-cyan-700 hover:bg-cyan-600 active:scale-95 text-white font-semibold rounded text-xs mt-1 transition-all"
          >
            متابعة المعركة
          </button>
        </div>
      )}

      {/* Item Selection View with Usage Limit */}
      {battlePhase === 'ITEM_SELECT' && (
        <div className="bg-gray-900 border-2 border-purple-500 rounded p-3 flex flex-col gap-2 text-right text-xs">
          <div className="flex items-center justify-between border-b border-gray-700 pb-1">
            <span className="font-bold text-purple-400">حقيبة الأدوات</span>
            <span className="text-[10px] bg-purple-950 text-purple-200 border border-purple-600 px-2 py-0.5 rounded">
              المتبقي بالمعركة: {itemsRemaining}/{maxItemsPerBattle}
            </span>
            <button
              onClick={() => onSelectAction('FIGHT')}
              className="text-gray-400 hover:text-white p-1"
            >
              <X size={16} />
            </button>
          </div>

          <div className="flex flex-col gap-1.5 max-h-36 overflow-y-auto">
            {itemsRemaining <= 0 ? (
              <div className="text-center py-4 text-amber-400 font-semibold">
                وصلت للحد الأقصى لاستخدام الأدوات في هذه المعركة ({maxItemsPerBattle}/{maxItemsPerBattle})!
              </div>
            ) : inventory.filter((item) => item.quantity > 0).length === 0 ? (
              <div className="text-center py-4 text-gray-400">
                لا توجد أدوات في حقيبتك حاليًا. زر المتجر لتزود نفسك بالجرعات!
              </div>
            ) : (
              inventory
                .filter((item) => item.quantity > 0)
                .map((item) => (
                  <button
                    key={item.id}
                    onClick={() => onUseItem(item)}
                    className="flex items-center justify-between p-2 bg-gray-800 hover:bg-gray-700 active:scale-95 border border-gray-700 rounded transition-all"
                  >
                    <div className="text-right">
                      <div className="font-bold text-white">{item.nameAr}</div>
                      <div className="text-[10px] text-gray-400">{item.descriptionAr}</div>
                    </div>
                    <span className="bg-purple-900 text-purple-200 px-2 py-0.5 rounded font-pixel text-[10px]">
                      x{item.quantity}
                    </span>
                  </button>
                ))
            )}
          </div>
        </div>
      )}

      {/* 3. The 4 Battle Command Buttons */}
      <div className="grid grid-cols-4 gap-1.5 pt-1">
        <button
          onClick={() => {
            soundManager.playSelect();
            onSelectAction('FIGHT');
          }}
          disabled={battlePhase !== 'MENU_SELECT'}
          className={`py-2 px-1 flex flex-col items-center justify-center gap-1 rounded border-2 font-bold text-xs transition-all active:scale-95 ${
            battlePhase === 'MENU_SELECT'
              ? 'bg-red-950/60 hover:bg-red-900/80 border-red-500 text-red-200 shadow-[0_0_8px_rgba(239,68,68,0.3)]'
              : 'bg-gray-900/40 border-gray-700 text-gray-500 opacity-50 cursor-not-allowed'
          }`}
        >
          <Swords size={16} className="text-red-400" />
          <span>قتـال</span>
        </button>

        <button
          onClick={() => {
            soundManager.playSelect();
            onSelectAction('CHECK');
          }}
          disabled={battlePhase !== 'MENU_SELECT'}
          className={`py-2 px-1 flex flex-col items-center justify-center gap-1 rounded border-2 font-bold text-xs transition-all active:scale-95 ${
            battlePhase === 'MENU_SELECT'
              ? 'bg-cyan-950/60 hover:bg-cyan-900/80 border-cyan-500 text-cyan-200 shadow-[0_0_8px_rgba(6,182,212,0.3)]'
              : 'bg-gray-900/40 border-gray-700 text-gray-500 opacity-50 cursor-not-allowed'
          }`}
        >
          <Eye size={16} className="text-cyan-400" />
          <span>فحـص</span>
        </button>

        <button
          onClick={() => {
            soundManager.playSelect();
            onSelectAction('ITEM');
          }}
          disabled={battlePhase !== 'MENU_SELECT'}
          className={`py-2 px-1 flex flex-col items-center justify-center gap-1 rounded border-2 font-bold text-xs transition-all active:scale-95 ${
            battlePhase === 'MENU_SELECT'
              ? 'bg-purple-950/60 hover:bg-purple-900/80 border-purple-500 text-purple-200 shadow-[0_0_8px_rgba(168,85,247,0.3)]'
              : 'bg-gray-900/40 border-gray-700 text-gray-500 opacity-50 cursor-not-allowed'
          }`}
        >
          <Sparkles size={16} className="text-purple-400" />
          <span>عنصـر</span>
        </button>

        <button
          onClick={() => {
            soundManager.playSelect();
            onMercyAttempt();
          }}
          disabled={battlePhase !== 'MENU_SELECT'}
          className={`py-2 px-1 flex flex-col items-center justify-center gap-1 rounded border-2 font-bold text-xs transition-all active:scale-95 ${
            battlePhase === 'MENU_SELECT'
              ? 'bg-amber-950/60 hover:bg-amber-900/80 border-amber-500 text-amber-200 shadow-[0_0_8px_rgba(245,158,11,0.3)]'
              : 'bg-gray-900/40 border-gray-700 text-gray-500 opacity-50 cursor-not-allowed'
          }`}
        >
          <HeartHandshake size={16} className="text-amber-400" />
          <span>رحمـة</span>
        </button>
      </div>

      {/* 4. Controls Zone: Virtual Joystick OR D-Pad */}
      <div className="relative w-full h-36 flex items-center justify-center">
        {controlType === 'JOYSTICK' ? (
          <VirtualJoystick
            onMoveRef={moveVectorRef}
            size={joystickSize}
            opacity={joystickOpacity}
            position={joystickPosition}
            sensitivity={joystickSensitivity}
            floating={joystickFloating}
          />
        ) : controlType === 'DPAD' ? (
          <div className="relative w-36 h-36 flex items-center justify-center">
            <div className="w-9 h-9 rounded-full bg-gray-800 border border-gray-600 flex items-center justify-center text-[10px] text-gray-400 select-none">
              روح
            </div>
            <button
              onTouchStart={(e) => { e.preventDefault(); handleDirStart('up'); }}
              onTouchEnd={(e) => { e.preventDefault(); handleDirEnd('up'); }}
              onMouseDown={() => handleDirStart('up')}
              onMouseUp={() => handleDirEnd('up')}
              className={`absolute top-0 left-1/2 -translate-x-1/2 ${dpadDimensions} bg-gray-800/90 hover:bg-gray-700 active:bg-cyan-600 active:scale-95 border-2 border-gray-600 rounded-lg flex items-center justify-center shadow transition-all`}
            >
              <ChevronUp size={22} className="text-gray-200" />
            </button>
            <button
              onTouchStart={(e) => { e.preventDefault(); handleDirStart('down'); }}
              onTouchEnd={(e) => { e.preventDefault(); handleDirEnd('down'); }}
              onMouseDown={() => handleDirStart('down')}
              onMouseUp={() => handleDirEnd('down')}
              className={`absolute bottom-0 left-1/2 -translate-x-1/2 ${dpadDimensions} bg-gray-800/90 hover:bg-gray-700 active:bg-cyan-600 active:scale-95 border-2 border-gray-600 rounded-lg flex items-center justify-center shadow transition-all`}
            >
              <ChevronDown size={22} className="text-gray-200" />
            </button>
            <button
              onTouchStart={(e) => { e.preventDefault(); handleDirStart('left'); }}
              onTouchEnd={(e) => { e.preventDefault(); handleDirEnd('left'); }}
              onMouseDown={() => handleDirStart('left')}
              onMouseUp={() => handleDirEnd('left')}
              className={`absolute left-0 top-1/2 -translate-y-1/2 ${dpadDimensions} bg-gray-800/90 hover:bg-gray-700 active:bg-cyan-600 active:scale-95 border-2 border-gray-600 rounded-lg flex items-center justify-center shadow transition-all`}
            >
              <ChevronLeft size={22} className="text-gray-200" />
            </button>
            <button
              onTouchStart={(e) => { e.preventDefault(); handleDirStart('right'); }}
              onTouchEnd={(e) => { e.preventDefault(); handleDirEnd('right'); }}
              onMouseDown={() => handleDirStart('right')}
              onMouseUp={() => handleDirEnd('right')}
              className={`absolute right-0 top-1/2 -translate-y-1/2 ${dpadDimensions} bg-gray-800/90 hover:bg-gray-700 active:bg-cyan-600 active:scale-95 border-2 border-gray-600 rounded-lg flex items-center justify-center shadow transition-all`}
            >
              <ChevronRight size={22} className="text-gray-200" />
            </button>
          </div>
        ) : (
          <div className="text-xs text-gray-500 font-semibold">
            المس واسحب داخل ساحة المعركة للتحكم المباشر
          </div>
        )}
      </div>
    </div>
  );
};
