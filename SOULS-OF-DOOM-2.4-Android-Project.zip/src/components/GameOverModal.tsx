import React from 'react';
import { BossData } from '../types/game';
import { soundManager } from '../audio/soundManager';
import { RotateCcw, ArrowRight, HeartCrack } from 'lucide-react';

interface GameOverModalProps {
  boss: BossData;
  bossHpRemaining: number;
  onRetry: () => void;
  onReturnToMenu: () => void;
}

export const GameOverModal: React.FC<GameOverModalProps> = ({
  boss,
  bossHpRemaining,
  onRetry,
  onReturnToMenu,
}) => {
  return (
    <div className="absolute inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md select-none">
      <div className="w-full max-w-sm bg-gray-950 border-2 border-red-700 rounded-2xl p-5 flex flex-col items-center text-center shadow-[0_0_30px_rgba(239,68,68,0.3)]">
        {/* Shattered Heart Icon */}
        <div className="w-16 h-16 rounded-full bg-red-950/80 border-2 border-red-500 flex items-center justify-center mb-3">
          <HeartCrack size={34} className="text-red-500 animate-pulse" />
        </div>

        {/* Title */}
        <h2 className="text-xl font-black text-red-500 font-pixel mb-1">
          انكسـرت الـروح!
        </h2>
        <p className="text-xs text-gray-400 mb-2">
          لا تيأس... كل هزيمة هي خطوة إضافية نحو إتقان مراوغة الظلام.
        </p>

        {/* Boss HP Remaining */}
        <div className="w-full bg-gray-900 border border-gray-800 rounded-lg p-2.5 mb-4 text-xs text-gray-300 flex items-center justify-between">
          <span>صحة {boss.nameAr} المتبقية:</span>
          <span className="font-pixel text-red-400">
            {bossHpRemaining} / {boss.maxHp} HP
          </span>
        </div>

        {/* Action Buttons */}
        <div className="w-full flex flex-col gap-2">
          <button
            onClick={() => {
              soundManager.playSelect();
              onRetry();
            }}
            className="w-full py-2.5 bg-red-600 hover:bg-red-500 active:scale-95 text-white font-bold rounded-lg shadow-[0_0_12px_rgba(239,68,68,0.5)] flex items-center justify-center gap-2 text-xs transition-all"
          >
            <RotateCcw size={16} />
            <span>إعادة المحاولة فورًا</span>
          </button>

          <button
            onClick={() => {
              soundManager.playSelect();
              onReturnToMenu();
            }}
            className="w-full py-2 bg-gray-800 hover:bg-gray-700 active:scale-95 border border-gray-700 text-gray-300 font-semibold rounded-lg flex items-center justify-center gap-1.5 text-xs transition-all"
          >
            <ArrowRight size={15} />
            <span>العودة للقائمة الرئيسية وتطوير العتاد</span>
          </button>
        </div>
      </div>
    </div>
  );
};
