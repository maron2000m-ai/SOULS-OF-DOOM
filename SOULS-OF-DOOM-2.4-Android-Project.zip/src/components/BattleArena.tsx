import React, { useRef, useEffect, useState, useCallback } from 'react';
import { Projectile, HazardZone, Difficulty, BossData, SoulSkin, HeartScale, GameSettings } from '../types/game';
import { soundManager } from '../audio/soundManager';

interface BattleArenaProps {
  boss: BossData;
  currentPhaseNumber: number;
  difficulty: Difficulty;
  isDodging: boolean;
  onDodgeComplete: (dodgedCount: number) => void;
  onPlayerHit: (damage: number) => void;
  playerHp: number;
  playerMaxHp: number;
  equippedSkin: SoulSkin;
  shieldActive: boolean;
  externalMoveVectorRef: React.MutableRefObject<{ x: number; y: number }>;
  settings: GameSettings;
}

const BASE_WIDTH = 300;
const BASE_HEIGHT = 180;

export const BattleArena: React.FC<BattleArenaProps> = ({
  boss,
  currentPhaseNumber,
  difficulty,
  isDodging,
  onDodgeComplete,
  onPlayerHit,
  equippedSkin,
  shieldActive,
  externalMoveVectorRef,
  settings,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Heart scaling
  const heartRadius = settings.heartScale === 'XLARGE' ? 12 : settings.heartScale === 'LARGE' ? 9.5 : 7.5;
  const hitboxRadius = heartRadius * 0.7;
  const hitboxRadiusSq = hitboxRadius * hitboxRadius;

  const heartPos = useRef<{ x: number; y: number }>({
    x: BASE_WIDTH / 2,
    y: BASE_HEIGHT * 0.75,
  });

  // Projectiles & Hazard storage
  const projectiles = useRef<Projectile[]>([]);
  const hazards = useRef<HazardZone[]>([]);
  const particles = useRef<Array<{ x: number; y: number; vx: number; vy: number; life: number; maxLife: number; color: string; size: number }>>([]);
  const trails = useRef<Array<{ x: number; y: number; life: number; color: string }>>([]);

  const iframeTimer = useRef<number>(0);
  const screenShake = useRef<number>(0);
  const dodgeTimer = useRef<number>(0);
  const spawnTimer = useRef<number>(0);
  const waveCycle = useRef<number>(0);
  const dodgedProjectilesCount = useRef<number>(0);

  // Performance diagnostics tracking
  const fpsRef = useRef<number>(60);
  const frameTimeRef = useRef<number>(16);
  const frameCountRef = useRef<number>(0);
  const lastFpsCalcRef = useRef<number>(performance.now());
  const [perfStats, setPerfStats] = useState({ fps: 60, frameTime: 16, objCount: 0 });

  const keysDown = useRef<{ [key: string]: boolean }>({});
  const touchTracking = useRef<boolean>(false);
  const touchTarget = useRef<{ x: number; y: number } | null>(null);

  const [remainingTime, setRemainingTime] = useState<number>(0);
  const [warningBanner, setWarningBanner] = useState<string | null>(null);

  // Caps based on performance mode
  const isSaver = settings.performancePreset === 'SAVER' || settings.graphicsQuality === 'LOW';
  const maxProjectiles = isSaver ? 26 : 42;
  const maxParticles = settings.reduceParticles ? 0 : isSaver ? 6 : 18;

  const startDodgeRound = useCallback(() => {
    projectiles.current = [];
    hazards.current = [];
    heartPos.current = { x: BASE_WIDTH / 2, y: BASE_HEIGHT * 0.75 };
    iframeTimer.current = 0;
    screenShake.current = 0;
    waveCycle.current = 0;
    dodgedProjectilesCount.current = 0;

    const phase = boss.phases.find((p) => p.phaseNumber === currentPhaseNumber) || boss.phases[0];
    const pattern = phase.attackPatterns[0];

    let dur = pattern.duration;
    if (difficulty === 'EASY') dur = Math.max(5, dur - 1.5);
    if (difficulty === 'HARD') dur = dur + 1.5;

    dodgeTimer.current = dur;
    spawnTimer.current = 0;
    setRemainingTime(Math.ceil(dur));

    if (pattern.warningHintAr) {
      setWarningBanner(pattern.warningHintAr);
      setTimeout(() => setWarningBanner(null), 2200);
    }
  }, [boss, currentPhaseNumber, difficulty]);

  useEffect(() => {
    if (isDodging) {
      startDodgeRound();
    } else {
      projectiles.current = [];
      hazards.current = [];
      particles.current = [];
      iframeTimer.current = 0;
      screenShake.current = 0;
      touchTracking.current = false;
      setWarningBanner(null);
    }
  }, [isDodging, startDodgeRound]);

  // Keyboard controls
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      keysDown.current[e.code] = true;
    };
    const handleKeyUp = (e: KeyboardEvent) => {
      keysDown.current[e.code] = false;
    };
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, []);

  // Spawn pattern projectiles
  const spawnPatternProjectiles = (dt: number, speedMult: number) => {
    if (projectiles.current.length >= maxProjectiles) return;

    spawnTimer.current += dt;
    const phase = boss.phases.find((p) => p.phaseNumber === currentPhaseNumber) || boss.phases[0];
    const pattern = phase.attackPatterns[0];

    let interval = pattern.spawnInterval;
    if (difficulty === 'EASY') interval *= 1.3;
    if (difficulty === 'HARD') interval *= 0.75;

    if (spawnTimer.current >= interval) {
      spawnTimer.current = 0;
      waveCycle.current++;

      // Rhythmic breathing interval
      if (waveCycle.current % 8 === 0) {
        return;
      }

      const speed = 120 * speedMult * (difficulty === 'HARD' ? 1.25 : difficulty === 'EASY' ? 0.8 : 1.0);

      // Boss 1: Dark Bones
      if (boss.id === 'boss_1') {
        const side = Math.random() > 0.5 ? 'horizontal' : 'vertical';
        if (side === 'horizontal') {
          const fromLeft = Math.random() > 0.5;
          const yPos = 25 + Math.random() * (BASE_HEIGHT - 50);
          projectiles.current.push({
            id: Math.random().toString(),
            x: fromLeft ? -10 : BASE_WIDTH + 10,
            y: yPos,
            vx: fromLeft ? speed : -speed,
            vy: 0,
            size: 6,
            width: 22,
            height: 10,
            type: 'bone',
            color: '#38bdf8',
            damage: 10,
          });
        } else {
          const fromTop = Math.random() > 0.5;
          const xPos = 25 + Math.random() * (BASE_WIDTH - 50);
          projectiles.current.push({
            id: Math.random().toString(),
            x: xPos,
            y: fromTop ? -10 : BASE_HEIGHT + 10,
            vx: 0,
            vy: fromTop ? speed : -speed,
            size: 6,
            width: 10,
            height: 22,
            type: 'bone',
            color: '#f8fafc',
            damage: 10,
          });
        }
      }

      // Boss 2: Flame Witch
      else if (boss.id === 'boss_2') {
        const xPos = 20 + Math.random() * (BASE_WIDTH - 40);
        projectiles.current.push({
          id: Math.random().toString(),
          x: xPos,
          y: -10,
          vx: (Math.random() - 0.5) * 45,
          vy: speed * 1.1,
          size: 7,
          type: 'fireball',
          color: Math.random() > 0.5 ? '#f43f5e' : '#c084fc',
          damage: 12,
        });

        if (Math.random() < 0.3) {
          hazards.current.push({
            id: Math.random().toString(),
            x: 40 + Math.random() * (BASE_WIDTH - 80),
            y: 40 + Math.random() * (BASE_HEIGHT - 80),
            width: 44,
            height: 44,
            isCircle: true,
            radius: 22,
            warningDuration: 0.9,
            activeDuration: 0.35,
            timer: 0,
            damage: 15,
            color: '#c084fc',
          });
        }
      }

      // Boss 3: Void Knight
      else if (boss.id === 'boss_3') {
        const isHorizontal = Math.random() > 0.5;
        const coord = isHorizontal
          ? 25 + Math.random() * (BASE_HEIGHT - 50)
          : 25 + Math.random() * (BASE_WIDTH - 50);

        hazards.current.push({
          id: Math.random().toString(),
          x: isHorizontal ? 0 : coord,
          y: isHorizontal ? coord : 0,
          width: isHorizontal ? BASE_WIDTH : 14,
          height: isHorizontal ? 14 : BASE_HEIGHT,
          isCircle: false,
          warningDuration: 0.7,
          activeDuration: 0.35,
          timer: 0,
          damage: 16,
          color: '#06b6d4',
        });

        const angle = Math.atan2(heartPos.current.y - 10, heartPos.current.x - BASE_WIDTH / 2);
        projectiles.current.push({
          id: Math.random().toString(),
          x: BASE_WIDTH / 2,
          y: 0,
          vx: Math.cos(angle) * speed * 1.2,
          vy: Math.sin(angle) * speed * 1.2,
          size: 8,
          width: 24,
          height: 8,
          rotation: angle,
          type: 'void_blade',
          color: '#38bdf8',
          damage: 14,
        });
      }

      // Boss 4: Time Warden
      else if (boss.id === 'boss_4') {
        const count = isSaver ? 2 : 3;
        for (let i = 0; i < count; i++) {
          const angle = (Math.PI * 2 * i) / count + Math.random();
          projectiles.current.push({
            id: Math.random().toString(),
            x: BASE_WIDTH / 2 + Math.cos(angle) * 30,
            y: 30 + Math.sin(angle) * 20,
            vx: Math.cos(angle) * speed * 0.9,
            vy: Math.sin(angle) * speed * 0.9,
            size: 8,
            type: 'time_gear',
            color: '#f59e0b',
            damage: 15,
            vRot: 4.5,
            rotation: 0,
          });
        }
      }

      // Boss 5: King of the Void
      else if (boss.id === 'boss_5') {
        if (Math.random() < 0.4) {
          const isHoriz = Math.random() > 0.5;
          hazards.current.push({
            id: Math.random().toString(),
            x: isHoriz ? 0 : heartPos.current.x - 10,
            y: isHoriz ? heartPos.current.y - 10 : 0,
            width: isHoriz ? BASE_WIDTH : 20,
            height: isHoriz ? 20 : BASE_HEIGHT,
            isCircle: false,
            warningDuration: 0.65,
            activeDuration: 0.35,
            timer: 0,
            damage: 20,
            color: '#ef4444',
          });
        }

        const orbCount = isSaver ? 3 : 4;
        for (let i = 0; i < orbCount; i++) {
          const angle = (Math.PI * 2 * i) / orbCount + Math.random() * 0.5;
          projectiles.current.push({
            id: Math.random().toString(),
            x: BASE_WIDTH / 2,
            y: 35,
            vx: Math.cos(angle) * speed * 1.15,
            vy: Math.sin(angle) * speed * 1.15,
            size: 7,
            type: 'star',
            color: '#ef4444',
            damage: 18,
          });
        }
      }

      // Boss 6: Soul Reaper
      else if (boss.id === 'boss_6') {
        const angle = Math.atan2(heartPos.current.y - 15, heartPos.current.x - BASE_WIDTH / 2);
        projectiles.current.push({
          id: Math.random().toString(),
          x: BASE_WIDTH / 2,
          y: 10,
          vx: Math.cos(angle) * speed * 1.3,
          vy: Math.sin(angle) * speed * 1.3,
          size: 9,
          width: 24,
          height: 10,
          rotation: angle,
          vRot: 6,
          type: 'scythe_arc',
          color: '#c084fc',
          damage: 22,
        });

        if (currentPhaseNumber > 1 || Math.random() < 0.45) {
          projectiles.current.push({
            id: Math.random().toString(),
            x: Math.random() > 0.5 ? 10 : BASE_WIDTH - 10,
            y: 20 + Math.random() * (BASE_HEIGHT - 40),
            vx: (Math.random() - 0.5) * speed * 0.7,
            vy: speed * 0.7,
            size: 8,
            type: 'spectral_soul',
            color: '#a855f7',
            damage: 18,
            homing: true,
          });
        }

        if (Math.random() < 0.35) {
          soundManager.playScytheSlash();
          const isHoriz = Math.random() > 0.5;
          hazards.current.push({
            id: Math.random().toString(),
            x: isHoriz ? 0 : heartPos.current.x - 12,
            y: isHoriz ? heartPos.current.y - 12 : 0,
            width: isHoriz ? BASE_WIDTH : 24,
            height: isHoriz ? 24 : BASE_HEIGHT,
            isCircle: false,
            warningDuration: 0.6,
            activeDuration: 0.3,
            timer: 0,
            damage: 25,
            color: '#a855f7',
          });
        }
      }

      // Boss 7: The Zero Dragon
      else if (boss.id === 'boss_7') {
        soundManager.playLaser();
        const crossX = 50 + Math.random() * (BASE_WIDTH - 100);
        const crossY = 35 + Math.random() * (BASE_HEIGHT - 70);

        hazards.current.push({
          id: Math.random().toString(),
          x: crossX - 10,
          y: 0,
          width: 20,
          height: BASE_HEIGHT,
          isCircle: false,
          warningDuration: 0.7,
          activeDuration: 0.35,
          timer: 0,
          damage: 28,
          color: '#38bdf8',
        });

        hazards.current.push({
          id: Math.random().toString(),
          x: 0,
          y: crossY - 10,
          width: BASE_WIDTH,
          height: 20,
          isCircle: false,
          warningDuration: 0.7,
          activeDuration: 0.35,
          timer: 0,
          damage: 28,
          color: '#38bdf8',
        });

        const orbCount = isSaver ? 3 : 5;
        for (let i = 0; i < orbCount; i++) {
          const a = (Math.PI * 2 * i) / orbCount + waveCycle.current * 0.3;
          projectiles.current.push({
            id: Math.random().toString(),
            x: BASE_WIDTH / 2,
            y: 30,
            vx: Math.cos(a) * speed * 1.25,
            vy: Math.sin(a) * speed * 1.25,
            size: 8,
            type: 'dragon_orb',
            color: '#0284c7',
            damage: 24,
          });
        }
      }

      // Boss 8: Ancient Bone King (ملك العظام القديم) - UPDATE 2.2
      else if (boss.id === 'boss_8') {
        const isPhase2 = currentPhaseNumber > 1;
        const kingSpeed = speed * (isPhase2 ? 1.35 : 1.1);

        // Pattern 1: Expanding Bone Rings with Guaranteed Safe Dodging Gap
        if (waveCycle.current % 3 === 0) {
          const ringCount = isSaver ? 8 : 12;
          const safeAngle = (waveCycle.current * 1.25) % (Math.PI * 2);
          for (let i = 0; i < ringCount; i++) {
            const angle = (Math.PI * 2 * i) / ringCount;
            // 50-degree gap for player heart to slip through safely
            const diff = Math.abs(Math.atan2(Math.sin(angle - safeAngle), Math.cos(angle - safeAngle)));
            if (diff < 0.5) continue;

            projectiles.current.push({
              id: Math.random().toString(),
              x: BASE_WIDTH / 2,
              y: 40,
              vx: Math.cos(angle) * kingSpeed,
              vy: Math.sin(angle) * kingSpeed,
              size: 7,
              width: 18,
              height: 7,
              type: 'royal_bone',
              color: i % 2 === 0 ? '#38bdf8' : '#eab308',
              damage: 22,
            });
          }
        }

        // Pattern 2: Rows of Bones Sweeping with Gap Lanes
        if (waveCycle.current % 2 === 1) {
          const fromLeft = Math.random() > 0.5;
          const yPos = 30 + Math.random() * (BASE_HEIGHT - 60);
          projectiles.current.push({
            id: Math.random().toString(),
            x: fromLeft ? -12 : BASE_WIDTH + 12,
            y: yPos,
            vx: fromLeft ? kingSpeed * 1.2 : -kingSpeed * 1.2,
            vy: 0,
            size: 6,
            width: 24,
            height: 9,
            type: 'bone',
            color: '#38bdf8',
            damage: 20,
          });
        }

        // Pattern 3: Giant Bone Slam with Clear Visual Telegraph Hazard Indicator
        if (Math.random() < (isPhase2 ? 0.65 : 0.35)) {
          soundManager.playLaser();
          const targetX = Math.max(35, Math.min(BASE_WIDTH - 35, heartPos.current.x + (Math.random() - 0.5) * 40));
          hazards.current.push({
            id: Math.random().toString(),
            x: targetX - 16,
            y: 0,
            width: 32,
            height: BASE_HEIGHT,
            isCircle: false,
            warningDuration: isPhase2 ? 0.55 : 0.75,
            activeDuration: 0.35,
            timer: 0,
            damage: 28,
            color: '#ef4444',
            label: '⚠️',
          });

          // Giant Bone falling projectile timed with warning expiry
          setTimeout(() => {
            if (isDodging) {
              projectiles.current.push({
                id: Math.random().toString(),
                x: targetX,
                y: -30,
                vx: 0,
                vy: kingSpeed * 1.8,
                size: 14,
                width: 24,
                height: 52,
                type: 'giant_bone',
                color: '#facc15',
                damage: 30,
              });
            }
          }, isPhase2 ? 550 : 750);
        }
      }
    }
  };

  // Dedicated, High-Performance Simulation Loop decoupled from React re-renders!
  useEffect(() => {
    let animId: number;
    let lastTime = performance.now();
    let frameAccumulator = 0;
    const targetInterval = settings.targetFps === 30 ? 1000 / 30 : 1000 / 60;

    const loop = (currentTime: number) => {
      const elapsed = currentTime - lastTime;
      lastTime = currentTime;

      // FPS tracking for performance diagnostics HUD
      frameCountRef.current++;
      if (currentTime - lastFpsCalcRef.current >= 600) {
        fpsRef.current = Math.round((frameCountRef.current * 1000) / (currentTime - lastFpsCalcRef.current));
        frameTimeRef.current = Math.round(elapsed);
        frameCountRef.current = 0;
        lastFpsCalcRef.current = currentTime;

        if (settings.showPerfHud) {
          setPerfStats({
            fps: fpsRef.current,
            frameTime: frameTimeRef.current,
            objCount: projectiles.current.length + hazards.current.length,
          });
        }
      }

      // Delta time clamped to prevent spiral of death
      const rawDt = elapsed / 1000;
      const dt = Math.min(rawDt, 0.033);

      const canvas = canvasRef.current;
      if (!canvas) {
        animId = requestAnimationFrame(loop);
        return;
      }
      const ctx = canvas.getContext('2d');
      if (!ctx) {
        animId = requestAnimationFrame(loop);
        return;
      }

      // 1. Process movement inputs from ref without React re-render overhead!
      const moveSpeed = 195;
      let dx = 0;
      let dy = 0;

      if (keysDown.current['ArrowLeft'] || keysDown.current['KeyA']) dx -= 1;
      if (keysDown.current['ArrowRight'] || keysDown.current['KeyD']) dx += 1;
      if (keysDown.current['ArrowUp'] || keysDown.current['KeyW']) dy -= 1;
      if (keysDown.current['ArrowDown'] || keysDown.current['KeyS']) dy += 1;

      // Virtual Joystick direct ref
      const joyVec = externalMoveVectorRef.current;
      if (joyVec.x !== 0 || joyVec.y !== 0) {
        dx += joyVec.x;
        dy += joyVec.y;
      }

      const inputLen = Math.hypot(dx, dy);
      if (inputLen > 0) {
        const factor = Math.min(1, inputLen);
        heartPos.current.x += (dx / inputLen) * moveSpeed * factor * dt;
        heartPos.current.y += (dy / inputLen) * moveSpeed * factor * dt;

        // Trail generation
        if (!settings.reduceParticles && equippedSkin.trailType && equippedSkin.trailType !== 'none' && trails.current.length < 8) {
          trails.current.push({
            x: heartPos.current.x,
            y: heartPos.current.y,
            life: 0.22,
            color: equippedSkin.particleColor,
          });
        }
      }

      // Direct touch-follow
      if (touchTracking.current && touchTarget.current && settings.controlType === 'TOUCH_FOLLOW') {
        const lerp = 0.35;
        heartPos.current.x += (touchTarget.current.x - heartPos.current.x) * lerp;
        heartPos.current.y += (touchTarget.current.y - heartPos.current.y) * lerp;
      }

      // Boundaries clamp
      const pad = heartRadius + 4;
      heartPos.current.x = Math.max(pad, Math.min(BASE_WIDTH - pad, heartPos.current.x));
      heartPos.current.y = Math.max(pad, Math.min(BASE_HEIGHT - pad, heartPos.current.y));

      // 2. Dodge Phase Simulation
      if (isDodging) {
        dodgeTimer.current -= dt;
        const remainingCeil = Math.max(0, Math.ceil(dodgeTimer.current));
        if (remainingCeil !== remainingTime) {
          setRemainingTime(remainingCeil);
        }

        if (dodgeTimer.current <= 0) {
          onDodgeComplete(dodgedProjectilesCount.current);
        }

        const phase = boss.phases.find((p) => p.phaseNumber === currentPhaseNumber) || boss.phases[0];
        spawnPatternProjectiles(dt, phase.speedMultiplier);

        // Update Projectiles
        for (let i = projectiles.current.length - 1; i >= 0; i--) {
          const p = projectiles.current[i];

          if (p.homing) {
            const hAngle = Math.atan2(heartPos.current.y - p.y, heartPos.current.x - p.x);
            p.vx += Math.cos(hAngle) * 35 * dt;
            p.vy += Math.sin(hAngle) * 35 * dt;
          }

          p.x += p.vx * dt;
          p.y += p.vy * dt;
          if (p.vRot) {
            p.rotation = (p.rotation || 0) + p.vRot * dt;
          }

          // Offscreen culling & dodge count increment
          if (p.x < -40 || p.x > BASE_WIDTH + 40 || p.y < -40 || p.y > BASE_HEIGHT + 40) {
            dodgedProjectilesCount.current++;
            projectiles.current.splice(i, 1);
            continue;
          }

          // Fast squared distance collision detection
          if (iframeTimer.current <= 0) {
            const dX = heartPos.current.x - p.x;
            const dY = heartPos.current.y - p.y;
            const distSq = dX * dX + dY * dY;
            const hitDist = hitboxRadius + (p.size * 0.7);

            if (distSq <= hitDist * hitDist) {
              let dmg = p.damage;
              if (difficulty === 'EASY') dmg = Math.round(dmg * 0.7);
              if (difficulty === 'HARD') dmg = Math.round(dmg * 1.35);

              if (shieldActive) {
                dmg = Math.max(1, Math.round(dmg * 0.5));
                soundManager.playShield();
              } else {
                soundManager.playDamage();
              }

              if (settings.hapticFeedback && typeof navigator !== 'undefined' && navigator.vibrate) {
                navigator.vibrate(40);
              }

              onPlayerHit(dmg);
              iframeTimer.current = 1.15;
              if (settings.screenShakeEnabled) screenShake.current = 9;

              // Burst particles capped
              if (!settings.reduceParticles && particles.current.length < maxParticles) {
                for (let k = 0; k < 6; k++) {
                  const a = Math.random() * Math.PI * 2;
                  const spd = 40 + Math.random() * 80;
                  particles.current.push({
                    x: heartPos.current.x,
                    y: heartPos.current.y,
                    vx: Math.cos(a) * spd,
                    vy: Math.sin(a) * spd,
                    life: 0.3,
                    maxLife: 0.3,
                    color: equippedSkin.primaryColor,
                    size: 2.5,
                  });
                }
              }

              projectiles.current.splice(i, 1);
              continue;
            }
          }
        }

        // Update Hazards
        for (let i = hazards.current.length - 1; i >= 0; i--) {
          const h = hazards.current[i];
          h.timer += dt;

          const isActive = h.timer >= h.warningDuration && h.timer <= h.warningDuration + h.activeDuration;

          if (isActive && iframeTimer.current <= 0) {
            let hit = false;
            if (h.isCircle && h.radius) {
              const dX = heartPos.current.x - h.x;
              const dY = heartPos.current.y - h.y;
              if (dX * dX + dY * dY <= (h.radius + hitboxRadius) * (h.radius + hitboxRadius)) hit = true;
            } else {
              if (
                heartPos.current.x >= h.x - hitboxRadius &&
                heartPos.current.x <= h.x + h.width + hitboxRadius &&
                heartPos.current.y >= h.y - hitboxRadius &&
                heartPos.current.y <= h.y + h.height + hitboxRadius
              ) {
                hit = true;
              }
            }

            if (hit) {
              let dmg = h.damage;
              if (difficulty === 'EASY') dmg = Math.round(dmg * 0.7);
              if (difficulty === 'HARD') dmg = Math.round(dmg * 1.35);

              if (shieldActive) {
                dmg = Math.max(1, Math.round(dmg * 0.5));
                soundManager.playShield();
              } else {
                soundManager.playDamage();
              }

              if (settings.hapticFeedback && typeof navigator !== 'undefined' && navigator.vibrate) {
                navigator.vibrate(40);
              }

              onPlayerHit(dmg);
              iframeTimer.current = 1.15;
              if (settings.screenShakeEnabled) screenShake.current = 9;
            }
          }

          if (h.timer > h.warningDuration + h.activeDuration) {
            hazards.current.splice(i, 1);
          }
        }
      }

      // Update Trails
      for (let i = trails.current.length - 1; i >= 0; i--) {
        trails.current[i].life -= dt;
        if (trails.current[i].life <= 0) {
          trails.current.splice(i, 1);
        }
      }

      // Update Particles
      for (let i = particles.current.length - 1; i >= 0; i--) {
        const pt = particles.current[i];
        pt.x += pt.vx * dt;
        pt.y += pt.vy * dt;
        pt.life -= dt;
        if (pt.life <= 0) {
          particles.current.splice(i, 1);
        }
      }

      if (iframeTimer.current > 0) iframeTimer.current -= dt;
      if (screenShake.current > 0) screenShake.current = Math.max(0, screenShake.current - dt * 25);

      // --- RENDERING PASS ---
      ctx.save();

      if (screenShake.current > 0 && settings.screenShakeEnabled) {
        const sx = (Math.random() - 0.5) * screenShake.current;
        const sy = (Math.random() - 0.5) * screenShake.current;
        ctx.translate(sx, sy);
      }

      ctx.fillStyle = '#030712';
      ctx.fillRect(0, 0, BASE_WIDTH, BASE_HEIGHT);

      // Clean grid (disabled in Saver mode)
      if (!isSaver) {
        const isBoneThrone = boss.number === 8;
        ctx.strokeStyle = isBoneThrone ? '#0e3a5a' : '#1e293b';
        ctx.lineWidth = 1;
        for (let x = 30; x < BASE_WIDTH; x += 30) {
          ctx.beginPath();
          ctx.moveTo(x, 0);
          ctx.lineTo(x, BASE_HEIGHT);
          ctx.stroke();
        }
        for (let y = 30; y < BASE_HEIGHT; y += 30) {
          ctx.beginPath();
          ctx.moveTo(0, y);
          ctx.lineTo(BASE_WIDTH, y);
          ctx.stroke();
        }

        // Bone Throne Arena Gothic Columns & Archway (Boss 8)
        if (isBoneThrone) {
          ctx.fillStyle = '#0f172a';
          ctx.fillRect(4, 0, 8, BASE_HEIGHT);
          ctx.fillRect(BASE_WIDTH - 12, 0, 8, BASE_HEIGHT);
          ctx.fillStyle = '#eab308';
          ctx.fillRect(3, 0, 10, 4);
          ctx.fillRect(BASE_WIDTH - 13, 0, 10, 4);
          // Bone runes on pillars
          ctx.fillStyle = '#38bdf8';
          ctx.fillRect(7, 30, 2, 8);
          ctx.fillRect(7, 70, 2, 8);
          ctx.fillRect(7, 110, 2, 8);
          ctx.fillRect(BASE_WIDTH - 9, 30, 2, 8);
          ctx.fillRect(BASE_WIDTH - 9, 70, 2, 8);
          ctx.fillRect(BASE_WIDTH - 9, 110, 2, 8);
        }
      }

      // Render Hazards
      hazards.current.forEach((h) => {
        const isWarning = h.timer < h.warningDuration;
        const isActive = h.timer >= h.warningDuration && h.timer <= h.warningDuration + h.activeDuration;

        if (h.isCircle && h.radius) {
          ctx.beginPath();
          ctx.arc(h.x, h.y, h.radius, 0, Math.PI * 2);
          if (isWarning) {
            ctx.fillStyle = `${h.color}33`;
            ctx.fill();
            ctx.strokeStyle = h.color;
            ctx.stroke();
          } else if (isActive) {
            ctx.fillStyle = h.color;
            ctx.fill();
          }
        } else {
          if (isWarning) {
            ctx.fillStyle = `${h.color}33`;
            ctx.fillRect(h.x, h.y, h.width, h.height);
            ctx.strokeStyle = h.color;
            ctx.lineWidth = 1.5;
            ctx.strokeRect(h.x, h.y, h.width, h.height);
            // Visual Telegraph Warning Indicator (Exclamation / Alert)
            ctx.fillStyle = '#ef4444';
            ctx.font = 'bold 12px sans-serif';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText(h.label || '⚠️', h.x + h.width / 2, Math.max(15, Math.min(BASE_HEIGHT - 15, h.y + h.height / 2)));
          } else if (isActive) {
            ctx.fillStyle = '#ffffff';
            ctx.fillRect(h.x, h.y, h.width, h.height);
            ctx.fillStyle = h.color;
            ctx.fillRect(h.x, h.y, h.width, h.height);
          }
        }
      });

      // Render Trails
      if (!settings.reduceParticles) {
        trails.current.forEach((tr) => {
          ctx.fillStyle = tr.color;
          ctx.globalAlpha = Math.max(0, tr.life / 0.22 * 0.5);
          ctx.beginPath();
          ctx.arc(tr.x, tr.y, heartRadius * 0.5, 0, Math.PI * 2);
          ctx.fill();
        });
        ctx.globalAlpha = 1.0;
      }

      // Render Projectiles
      projectiles.current.forEach((p) => {
        ctx.save();
        ctx.translate(p.x, p.y);
        if (p.rotation) ctx.rotate(p.rotation);

        if (p.type === 'bone' || p.type === 'royal_bone') {
          ctx.fillStyle = p.color;
          const w = p.width || 20;
          const h = p.height || 8;
          ctx.fillRect(-w / 2, -h / 2, w, h);
          ctx.beginPath();
          ctx.arc(-w / 2, -h / 2, 2.5, 0, Math.PI * 2);
          ctx.arc(-w / 2, h / 2, 2.5, 0, Math.PI * 2);
          ctx.arc(w / 2, -h / 2, 2.5, 0, Math.PI * 2);
          ctx.arc(w / 2, h / 2, 2.5, 0, Math.PI * 2);
          ctx.fill();
          if (p.type === 'royal_bone') {
            ctx.fillStyle = '#ffffff';
            ctx.fillRect(-w / 4, -h / 4, w / 2, h / 2);
          }
        } else if (p.type === 'giant_bone') {
          // Giant Bone Falling Slam with golden crown emblem
          const w = p.width || 24;
          const h = p.height || 52;
          ctx.fillStyle = '#f8fafc';
          ctx.fillRect(-w / 2, -h / 2, w, h);
          ctx.fillStyle = '#eab308';
          ctx.beginPath();
          ctx.arc(-w / 2, -h / 2, 4, 0, Math.PI * 2);
          ctx.arc(-w / 2, h / 2, 4, 0, Math.PI * 2);
          ctx.arc(w / 2, -h / 2, 4, 0, Math.PI * 2);
          ctx.arc(w / 2, h / 2, 4, 0, Math.PI * 2);
          ctx.fill();
          // Crown Jewel on Giant Bone
          ctx.fillStyle = '#38bdf8';
          ctx.fillRect(-3, -3, 6, 6);
        } else if (p.type === 'scythe_arc') {
          ctx.fillStyle = p.color;
          ctx.beginPath();
          ctx.arc(0, 0, p.size, -Math.PI / 2, Math.PI / 2, false);
          ctx.lineTo(-p.size / 2, 0);
          ctx.closePath();
          ctx.fill();
        } else if (p.type === 'dragon_orb' || p.type === 'spectral_soul') {
          ctx.fillStyle = p.color;
          ctx.beginPath();
          ctx.arc(0, 0, p.size, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = '#ffffff';
          ctx.beginPath();
          ctx.arc(0, 0, p.size * 0.4, 0, Math.PI * 2);
          ctx.fill();
        } else if (p.type === 'time_gear') {
          ctx.strokeStyle = p.color;
          ctx.lineWidth = 2.5;
          ctx.beginPath();
          ctx.arc(0, 0, p.size, 0, Math.PI * 2);
          ctx.stroke();
        } else {
          ctx.fillStyle = p.color;
          ctx.beginPath();
          ctx.arc(0, 0, p.size, 0, Math.PI * 2);
          ctx.fill();
        }

        ctx.restore();
      });

      // Render Particles
      if (!settings.reduceParticles) {
        particles.current.forEach((pt) => {
          ctx.fillStyle = pt.color;
          ctx.fillRect(pt.x, pt.y, pt.size, pt.size);
        });
      }

      // Render Player Soul Heart
      const flash = iframeTimer.current > 0 && Math.floor(iframeTimer.current * 16) % 2 === 0;
      if (!flash) {
        ctx.save();
        ctx.translate(heartPos.current.x, heartPos.current.y);

        if (shieldActive) {
          ctx.strokeStyle = '#06b6d4';
          ctx.lineWidth = 2.5;
          ctx.beginPath();
          ctx.arc(0, 0, heartRadius + 6, 0, Math.PI * 2);
          ctx.stroke();
        }

        ctx.fillStyle = equippedSkin.primaryColor;
        // Subtle glow only when bloom is not reduced
        if (!settings.reduceBloom && !isSaver) {
          ctx.shadowColor = equippedSkin.primaryColor;
          ctx.shadowBlur = 8;
        }

        const hr = heartRadius;
        ctx.beginPath();
        ctx.arc(-hr / 2, -hr / 3, hr / 2, Math.PI, 0, false);
        ctx.arc(hr / 2, -hr / 3, hr / 2, Math.PI, 0, false);
        ctx.lineTo(0, hr);
        ctx.closePath();
        ctx.fill();

        ctx.fillStyle = '#ffffff';
        ctx.fillRect(-hr / 3, -hr / 3, hr / 3, hr / 3);

        ctx.restore();
      }

      ctx.restore();
      animId = requestAnimationFrame(loop);
    };

    animId = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(animId);
  }, [
    isDodging,
    boss,
    currentPhaseNumber,
    difficulty,
    equippedSkin,
    shieldActive,
    settings,
    heartRadius,
    hitboxRadius,
    maxProjectiles,
    maxParticles,
    isSaver,
    onDodgeComplete,
    onPlayerHit,
  ]);

  // Direct touch drag
  const handleTouchStart = (e: React.TouchEvent<HTMLCanvasElement>) => {
    if (settings.controlType !== 'TOUCH_FOLLOW') return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const touch = e.touches[0];
    const scaleX = BASE_WIDTH / rect.width;
    const scaleY = BASE_HEIGHT / rect.height;

    touchTracking.current = true;
    touchTarget.current = {
      x: (touch.clientX - rect.left) * scaleX,
      y: (touch.clientY - rect.top) * scaleY,
    };
  };

  const handleTouchMove = (e: React.TouchEvent<HTMLCanvasElement>) => {
    if (!touchTracking.current) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const touch = e.touches[0];
    const scaleX = BASE_WIDTH / rect.width;
    const scaleY = BASE_HEIGHT / rect.height;

    touchTarget.current = {
      x: (touch.clientX - rect.left) * scaleX,
      y: (touch.clientY - rect.top) * scaleY,
    };
  };

  const handleTouchEnd = () => {
    touchTracking.current = false;
    touchTarget.current = null;
  };

  return (
    <div className="flex flex-col items-center justify-center relative w-full px-2">
      {/* Warning Banner */}
      {warningBanner && (
        <div className="absolute -top-7 z-20 px-3 py-1 bg-red-950/90 border border-red-500 rounded text-red-200 text-xs font-bold animate-pulse shadow-lg flex items-center gap-1.5">
          <span>⚠️ {warningBanner}</span>
        </div>
      )}

      {/* Combat Arena Box */}
      <div
        className="relative border-4 border-white bg-gray-950 rounded shadow-[0_0_15px_rgba(255,255,255,0.2)] overflow-hidden transition-transform duration-200"
        style={{
          transform: `scale(${settings.arenaScale})`,
        }}
      >
        {isDodging && (
          <div className="absolute top-2 left-2 z-10 bg-black/80 border border-gray-700 px-2 py-0.5 rounded text-[10px] font-pixel text-amber-300">
            ⏳ {remainingTime} ث
          </div>
        )}

        {shieldActive && (
          <div className="absolute top-2 right-2 z-10 bg-cyan-950/85 border border-cyan-500/80 px-2 py-0.5 rounded text-[10px] font-bold text-cyan-300">
            🛡️ درع نشط (-50%)
          </div>
        )}

        {/* Real-time Diagnostics Performance Benchmark HUD */}
        {settings.showPerfHud && (
          <div className="absolute bottom-1 right-1 z-10 bg-black/85 border border-green-500/60 px-2 py-0.5 rounded text-[9px] font-pixel text-green-300 pointer-events-none flex items-center gap-1.5">
            <span>FPS: {perfStats.fps}</span>
            <span className="text-gray-400">|</span>
            <span>{perfStats.frameTime}ms</span>
            <span className="text-gray-400">|</span>
            <span>OBJ: {perfStats.objCount}</span>
          </div>
        )}

        <canvas
          ref={canvasRef}
          width={BASE_WIDTH}
          height={BASE_HEIGHT}
          onTouchStart={handleTouchStart}
          onTouchMove={handleTouchMove}
          onTouchEnd={handleTouchEnd}
          className="block w-full max-w-[350px] aspect-[5/3] cursor-crosshair touch-none select-none"
        />
      </div>
    </div>
  );
};
