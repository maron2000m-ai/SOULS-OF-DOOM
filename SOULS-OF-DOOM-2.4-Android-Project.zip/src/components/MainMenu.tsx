import React, { useEffect, useState } from 'react';
import { PlayerSaveData } from '../types/game';
import { BOSSES } from '../data/bosses';
import { soundManager } from '../audio/soundManager';
import {
  Play,
  RotateCcw,
  Skull,
  ShoppingBag,
  Settings as SettingsIcon,
  Info,
  Sparkles,
  Coins,
  Heart,
  User,
  BookOpen,
  Flame,
  Newspaper,
  ScrollText,
  Target,
  Smartphone,
} from 'lucide-react';

interface MainMenuProps {
  playerData: PlayerSaveData;
  onStartAdventure: () => void;
  onContinue: () => void;
  onOpenBossSelect: () => void;
  onOpenBestiary: () => void;
  onOpenProfile: () => void;
  onOpenShop: () => void;
  onOpenSettings: () => void;
  onOpenInfo: () => void;
  onOpenNews: () => void;
  onOpenHistory: () => void;
  onOpenChallenges: () => void;
  onOpenAndroidPackage: () => void;
}

export const MainMenu: React.FC<MainMenuProps> = ({
  playerData,
  onStartAdventure,
  onContinue,
  onOpenBossSelect,
  onOpenBestiary,
  onOpenProfile,
  onOpenShop,
  onOpenSettings,
  onOpenInfo,
  onOpenNews,
  onOpenHistory,
  onOpenChallenges,
  onOpenAndroidPackage,
}) => {
  const [stars, setStars] = useState<Array<{ id: number; x: number; y: number; size: number; speed: number; opacity: number }>>([]);

  useEffect(() => {
    const starList = Array.from({ length: 35 }, (_, i) => ({
      id: i,
      x: Math.random() * 100,
      y: Math.random() * 100,
      size: Math.random() > 0.7 ? 3 : 2,
      speed: 0.15 + Math.random() * 0.35,
      opacity: 0.3 + Math.random() * 0.7,
    }));
    setStars(starList);

    const interval = setInterval(() => {
      setStars((prev) =>
        prev.map((s) => ({
          ...s,
          y: s.y <= 0 ? 100 : s.y - s.speed,
        }))
      );
    }, 50);

    return () => clearInterval(interval);
  }, []);

  const currentBoss = BOSSES.find((b) => b.number === playerData.unlockedBossNumber) || BOSSES[0];
  const canContinue = playerData.defeatedBosses.length > 0 || playerData.unlockedBossNumber > 1 || playerData.soulCoins > 100;

  const claimableChallengesCount = Object.values(playerData.challenges || {}).filter(
    (c) => c.isCompleted && !c.isClaimed
  ).length;

  return (
    <div className="relative w-full h-full flex flex-col items-center justify-between p-3 overflow-hidden select-none">
      {/* Animated Floating Souls / Starfield Background */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {stars.map((s) => (
          <div
            key={s.id}
            className="absolute rounded-full bg-cyan-400 pixelated"
            style={{
              left: `${s.x}%`,
              top: `${s.y}%`,
              width: `${s.size}px`,
              height: `${s.size}px`,
              opacity: s.opacity,
              boxShadow: '0 0 6px rgba(56, 189, 248, 0.8)',
            }}
          />
        ))}
        <div className="absolute inset-0 bg-radial from-purple-950/25 via-transparent to-black" />
      </div>

      {/* Top Bar: Saved Progress & Profile Quick Launch */}
      <div className="relative z-10 w-full max-w-sm flex items-center justify-between bg-black/75 border border-gray-800 rounded-xl p-2 backdrop-blur-md text-xs text-gray-300 shadow-md">
        {/* Profile Button */}
        <button
          onClick={() => {
            soundManager.playSelect();
            onOpenProfile();
          }}
          className="flex items-center gap-1.5 bg-gray-900/90 hover:bg-gray-800 active:scale-95 border border-cyan-500/80 px-2 py-1 rounded-lg text-cyan-300 font-bold transition-all"
        >
          <User size={13} />
          <span className="text-[11px] truncate max-w-[80px]">{playerData.playerName}</span>
          <span className="bg-cyan-950 text-[9px] px-1 rounded font-pixel">Lv.{playerData.level}</span>
        </button>

        {/* Soul Coins */}
        <div className="flex items-center gap-1 font-pixel text-amber-400">
          <Coins size={13} className="text-amber-400" />
          <span>{playerData.soulCoins}</span>
        </div>

        {/* Health */}
        <div className="flex items-center gap-1 text-red-400 font-pixel">
          <Heart size={13} className="text-red-500 fill-red-500" />
          <span>{playerData.maxHp} HP</span>
        </div>
      </div>

      {/* Centerpiece: Logo & 2.1 Update Branding */}
      <div className="relative z-10 flex flex-col items-center text-center my-auto">
        {/* Pulsing Red Soul Core */}
        <div className="relative mb-1.5 animate-pulse-glow">
          <div className="w-12 h-12 relative flex items-center justify-center">
            <svg viewBox="0 0 24 24" className="w-11 h-11 fill-red-600 filter drop-shadow-[0_0_18px_rgba(239,68,68,0.95)] pixelated">
              <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z" />
            </svg>
          </div>
        </div>

        {/* Title Lockup */}
        <h1 className="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-b from-white via-red-200 to-red-600 tracking-wider">
          SOULS OF DOOM
        </h1>
        <h2 className="text-sm font-extrabold text-red-500 font-pixel tracking-wider">
          معركة الأرواح
        </h2>

        {/* 2.1 Soul Polish Badge */}
        <div className="mt-1 flex items-center gap-1 bg-gradient-to-r from-emerald-950 via-cyan-950 to-purple-950 border border-cyan-500/80 px-2.5 py-0.5 rounded-full text-[10px] text-cyan-200 font-bold shadow-[0_0_10px_rgba(6,182,212,0.4)]">
          <Sparkles size={11} className="text-emerald-400" />
          <span>تحديث 2.1 — صقل الأرواح ⚔️</span>
        </div>
      </div>

      {/* Navigation Buttons Stack */}
      <div className="relative z-10 w-full max-w-sm flex flex-col gap-1.5 my-auto">
        {/* Start Adventure */}
        <button
          onClick={() => {
            soundManager.playSelect();
            onStartAdventure();
          }}
          className="w-full py-2 px-3 bg-gradient-to-r from-red-700 to-red-600 hover:from-red-600 hover:to-red-500 active:scale-95 text-white font-bold rounded-lg border-2 border-red-400 shadow-[0_0_14px_rgba(239,68,68,0.5)] flex items-center justify-center gap-2 text-xs transition-all"
        >
          <Play size={15} className="fill-white" />
          <span>ابدأ المغامرة (الزعيم #1)</span>
        </button>

        {/* Continue Game */}
        <button
          onClick={() => {
            soundManager.playSelect();
            onContinue();
          }}
          disabled={!canContinue}
          className={`w-full py-1.5 px-3 rounded-lg border-2 font-bold flex items-center justify-center gap-2 text-xs transition-all ${
            canContinue
              ? 'bg-gray-800/90 hover:bg-gray-700/90 border-cyan-500 text-cyan-200 active:scale-95 shadow-[0_0_8px_rgba(6,182,212,0.3)]'
              : 'bg-gray-900/40 border-gray-800 text-gray-600 cursor-not-allowed opacity-50'
          }`}
        >
          <RotateCcw size={14} />
          <span>متابعة القتال ({currentBoss.nameAr} #{playerData.unlockedBossNumber})</span>
        </button>

        {/* UPDATE 2.1 Quick Trio (News / Battle History / Challenges) */}
        <div className="grid grid-cols-3 gap-1.5">
          {/* Soul News */}
          <button
            onClick={() => {
              soundManager.playSelect();
              onOpenNews();
            }}
            className="relative py-1.5 px-1 bg-cyan-950/70 hover:bg-cyan-900/80 active:scale-95 border border-cyan-500/80 rounded-lg text-cyan-200 text-[11px] font-bold flex items-center justify-center gap-1 transition-all"
          >
            <Newspaper size={13} className="text-cyan-400" />
            <span>الأخبار</span>
            {!playerData.hasReadNewsV21 && (
              <span className="absolute -top-1 -right-1 flex h-2.5 w-2.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-red-500"></span>
              </span>
            )}
          </button>

          {/* Battle History */}
          <button
            onClick={() => {
              soundManager.playSelect();
              onOpenHistory();
            }}
            className="py-1.5 px-1 bg-amber-950/70 hover:bg-amber-900/80 active:scale-95 border border-amber-500/80 rounded-lg text-amber-200 text-[11px] font-bold flex items-center justify-center gap-1 transition-all"
          >
            <ScrollText size={13} className="text-amber-400" />
            <span>سجل المعارك</span>
          </button>

          {/* Soul Challenges */}
          <button
            onClick={() => {
              soundManager.playSelect();
              onOpenChallenges();
            }}
            className="relative py-1.5 px-1 bg-emerald-950/70 hover:bg-emerald-900/80 active:scale-95 border border-emerald-500/80 rounded-lg text-emerald-200 text-[11px] font-bold flex items-center justify-center gap-1 transition-all"
          >
            <Target size={13} className="text-emerald-400" />
            <span>التحديات</span>
            {claimableChallengesCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-emerald-500 text-black text-[9px] font-pixel w-4 h-4 rounded-full flex items-center justify-center font-bold animate-bounce shadow">
                {claimableChallengesCount}
              </span>
            )}
          </button>
        </div>

        {/* UPDATE 2.2 Android App Packaging & WebAPK Hub */}
        <button
          onClick={() => {
            soundManager.playSelect();
            onOpenAndroidPackage();
          }}
          className="w-full py-1.5 px-2.5 bg-gradient-to-r from-emerald-950/80 via-teal-900/80 to-emerald-950/80 hover:from-emerald-900 hover:to-teal-900 active:scale-95 border-2 border-emerald-500/90 rounded-lg text-emerald-200 text-xs font-bold flex items-center justify-between transition-all shadow-[0_0_12px_rgba(16,185,129,0.25)]"
        >
          <div className="flex items-center gap-2">
            <Smartphone size={14} className="text-emerald-400 animate-pulse" />
            <span>تجهيز اللعبة كتطبيق Android (WebAPK)</span>
          </div>
          <span className="px-1.5 py-0.5 rounded text-[9px] bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-pixel">
            جاهز للتثبيت 📱
          </span>
        </button>

        {/* Main 6 Actions Grid */}
        <div className="grid grid-cols-2 gap-1.5">
          {/* Boss Select */}
          <button
            onClick={() => {
              soundManager.playSelect();
              onOpenBossSelect();
            }}
            className="py-1.5 px-2 bg-gray-900/85 hover:bg-gray-800 active:scale-95 border border-purple-500/70 rounded-lg text-purple-200 text-xs font-semibold flex items-center justify-center gap-1.5 transition-all shadow-[0_0_6px_rgba(168,85,247,0.2)]"
          >
            <Skull size={13} className="text-purple-400" />
            <span>اختيار الزعيم (8)</span>
          </button>

          {/* Boss Bestiary */}
          <button
            onClick={() => {
              soundManager.playSelect();
              onOpenBestiary();
            }}
            className="py-1.5 px-2 bg-gray-900/85 hover:bg-gray-800 active:scale-95 border border-indigo-500/70 rounded-lg text-indigo-200 text-xs font-semibold flex items-center justify-center gap-1.5 transition-all shadow-[0_0_6px_rgba(99,102,241,0.2)]"
          >
            <BookOpen size={13} className="text-indigo-400" />
            <span>دفتر الزعماء</span>
          </button>

          {/* Shop */}
          <button
            onClick={() => {
              soundManager.playSelect();
              onOpenShop();
            }}
            className="py-1.5 px-2 bg-gray-900/85 hover:bg-gray-800 active:scale-95 border border-amber-500/70 rounded-lg text-amber-200 text-xs font-semibold flex items-center justify-center gap-1.5 transition-all shadow-[0_0_6px_rgba(245,158,11,0.2)]"
          >
            <ShoppingBag size={13} className="text-amber-400" />
            <span>المتجر والترقيات</span>
          </button>

          {/* Profile */}
          <button
            onClick={() => {
              soundManager.playSelect();
              onOpenProfile();
            }}
            className="py-1.5 px-2 bg-gray-900/85 hover:bg-gray-800 active:scale-95 border border-cyan-500/70 rounded-lg text-cyan-200 text-xs font-semibold flex items-center justify-center gap-1.5 transition-all shadow-[0_0_6px_rgba(6,182,212,0.2)]"
          >
            <User size={13} className="text-cyan-400" />
            <span>الملف الشخصي</span>
          </button>

          {/* Settings */}
          <button
            onClick={() => {
              soundManager.playSelect();
              onOpenSettings();
            }}
            className="py-1.5 px-2 bg-gray-900/85 hover:bg-gray-800 active:scale-95 border border-gray-700 rounded-lg text-gray-300 text-xs font-semibold flex items-center justify-center gap-1.5 transition-all"
          >
            <SettingsIcon size={13} className="text-gray-400" />
            <span>الإعدادات والأداء</span>
          </button>

          {/* Info */}
          <button
            onClick={() => {
              soundManager.playSelect();
              onOpenInfo();
            }}
            className="py-1.5 px-2 bg-gray-900/85 hover:bg-gray-800 active:scale-95 border border-gray-700 rounded-lg text-gray-300 text-xs font-semibold flex items-center justify-center gap-1.5 transition-all"
          >
            <Info size={13} className="text-blue-400" />
            <span>معلومات اللعبة</span>
          </button>
        </div>
      </div>

      {/* Bottom Hint */}
      <div className="relative z-10 text-[9px] text-gray-500 font-pixel mt-1 text-center">
        تحديث 2.2: عودة ملك العظام 👑💀 · حزمة تطبيق Android · أداء 60FPS
      </div>
    </div>
  );
};
