import React from 'react';
import { BossData, PlayerSaveData } from '../types/game';
import { BOSSES } from '../data/bosses';
import { soundManager } from '../audio/soundManager';
import { Lock, CheckCircle2, Swords, ArrowRight, Coins, Star } from 'lucide-react';

interface BossSelectProps {
  playerData: PlayerSaveData;
  onSelectBoss: (boss: BossData) => void;
  onBackToMenu: () => void;
}

export const BossSelect: React.FC<BossSelectProps> = ({
  playerData,
  onSelectBoss,
  onBackToMenu,
}) => {
  return (
    <div className="relative w-full h-full flex flex-col p-4 bg-gradient-to-b from-gray-950 via-black to-gray-950 overflow-y-auto select-none">
      {/* Top Header */}
      <div className="flex items-center justify-between border-b border-gray-800 pb-3 mb-3">
        <button
          onClick={() => {
            soundManager.playSelect();
            onBackToMenu();
          }}
          className="flex items-center gap-1.5 text-xs text-gray-400 hover:text-white bg-gray-900 border border-gray-700 px-3 py-1.5 rounded active:scale-95 transition-all"
        >
          <ArrowRight size={16} />
          <span>الرئيسية</span>
        </button>

        <h2 className="text-base font-bold text-white flex items-center gap-2">
          <span>اختيار الزعيم</span>
          <span className="text-xs bg-red-950 border border-red-700 text-red-300 px-2 py-0.5 rounded font-pixel">
            8 زعماء
          </span>
        </h2>
      </div>

      {/* Boss Cards List */}
      <div className="flex flex-col gap-3 max-w-md mx-auto w-full pb-6">
        {BOSSES.map((boss) => {
          const isUnlocked = boss.number <= playerData.unlockedBossNumber;
          const isDefeated = playerData.defeatedBosses.includes(boss.id);

          return (
            <div
              key={boss.id}
              className={`relative rounded-xl border-2 p-3.5 transition-all ${
                isDefeated
                  ? 'bg-amber-950/20 border-amber-500/60 shadow-[0_0_10px_rgba(245,158,11,0.2)]'
                  : isUnlocked
                  ? 'bg-gray-900/90 border-cyan-500/70 shadow-[0_0_12px_rgba(6,182,212,0.2)]'
                  : 'bg-gray-950/60 border-gray-800 opacity-60'
              }`}
            >
              {/* Header inside card */}
              <div className="flex items-start justify-between mb-2">
                <div className="flex items-center gap-2">
                  <span
                    className="w-7 h-7 rounded-lg flex items-center justify-center font-pixel text-xs font-bold"
                    style={{
                      backgroundColor: isUnlocked ? `${boss.colorTheme}33` : '#1f2937',
                      color: isUnlocked ? boss.colorTheme : '#6b7280',
                      border: `1px solid ${isUnlocked ? boss.colorTheme : '#374151'}`,
                    }}
                  >
                    #{boss.number}
                  </span>
                  <div>
                    <h3 className="font-bold text-sm text-white flex items-center gap-1.5">
                      {isUnlocked ? boss.nameAr : `الزعيم #${boss.number}`}
                      {isDefeated && (
                        <CheckCircle2 size={16} className="text-amber-400" />
                      )}
                    </h3>
                    <div className="text-[11px] text-gray-400">
                      {isUnlocked ? boss.titleAr : 'مغلق حتى تهزم الزعيم السابق'}
                    </div>
                  </div>
                </div>

                {/* Status Badge */}
                <div className="text-[11px] font-semibold">
                  {isDefeated ? (
                    <span className="bg-amber-950 text-amber-300 border border-amber-600 px-2 py-0.5 rounded">
                      مهـزوم 🏆
                    </span>
                  ) : isUnlocked ? (
                    <span className="bg-cyan-950 text-cyan-300 border border-cyan-600 px-2 py-0.5 rounded animate-pulse">
                      متـاح للقتال
                    </span>
                  ) : (
                    <span className="bg-gray-900 text-gray-500 border border-gray-700 px-2 py-0.5 rounded flex items-center gap-1">
                      <Lock size={12} />
                      مغـلق
                    </span>
                  )}
                </div>
              </div>

              {/* Description */}
              <p className="text-xs text-gray-300 leading-relaxed mb-3">
                {isUnlocked ? boss.descriptionAr : 'كيان غامض يتطلب شجاعة فائقة لمواجهته.'}
              </p>

              {/* Card Meta footer */}
              <div className="flex items-center justify-between pt-2 border-t border-gray-800/80 text-xs">
                {/* Reward and Stars */}
                <div className="flex items-center gap-3">
                  <div className="flex items-center gap-1 text-amber-400 font-pixel text-[10px]">
                    <Coins size={13} />
                    <span>+{boss.rewardCoins}</span>
                  </div>

                  <div className="flex items-center gap-0.5">
                    {Array.from({ length: 7 }).map((_, idx) => (
                      <Star
                        key={idx}
                        size={11}
                        className={
                          idx < boss.number
                            ? 'text-amber-400 fill-amber-400'
                            : 'text-gray-700'
                        }
                      />
                    ))}
                  </div>
                </div>

                {/* Action Button */}
                {isUnlocked ? (
                  <button
                    onClick={() => {
                      soundManager.playSelect();
                      onSelectBoss(boss);
                    }}
                    className="py-1.5 px-3 bg-red-600 hover:bg-red-500 active:scale-95 text-white font-bold rounded text-xs flex items-center gap-1.5 shadow transition-all"
                  >
                    <Swords size={14} />
                    <span>{isDefeated ? 'إعادة التحدي' : 'قاتـل الآن'}</span>
                  </button>
                ) : (
                  <div className="text-[10px] text-gray-500 flex items-center gap-1">
                    <Lock size={11} />
                    <span>اهزم الزعيم #{boss.number - 1} للفتح</span>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
