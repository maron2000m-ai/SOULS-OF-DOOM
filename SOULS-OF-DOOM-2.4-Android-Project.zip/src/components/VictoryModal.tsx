import React from 'react';
import { BossData } from '../types/game';
import { soundManager } from '../audio/soundManager';
import { Trophy, Coins, ArrowRight, Play, Sparkles, CheckCircle } from 'lucide-react';

interface VictoryModalProps {
  boss: BossData;
  earnedCoins: number;
  unlockedNextBoss: boolean;
  isMercyWin: boolean;
  onNextBoss: () => void;
  onReturnToMenu: () => void;
}

export const VictoryModal: React.FC<VictoryModalProps> = ({
  boss,
  earnedCoins,
  unlockedNextBoss,
  isMercyWin,
  onNextBoss,
  onReturnToMenu,
}) => {
  return (
    <div className="absolute inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md select-none">
      <div className="w-full max-w-sm bg-gray-900 border-2 border-amber-500 rounded-2xl p-5 flex flex-col items-center text-center shadow-[0_0_30px_rgba(245,158,11,0.3)] animate-pulse-glow">
        {/* Trophy / Victory Badge */}
        <div className="w-16 h-16 rounded-full bg-amber-950 border-2 border-amber-400 flex items-center justify-center mb-3 shadow-[0_0_15px_rgba(245,158,11,0.6)]">
          <Trophy size={32} className="text-amber-400 animate-bounce" />
        </div>

        {/* Title */}
        <h2 className="text-xl font-black text-amber-300 font-pixel mb-1">
          {isMercyWin ? 'انتصار بالرحمة!' : 'انتـصار ساحـق!'}
        </h2>
        <p className="text-xs text-gray-300 mb-3">
          {isMercyWin
            ? `لقد أظهرت نبل الروح وحصلت على احترام ${boss.nameAr}!`
            : `تمت هزيمة ${boss.nameAr} وكسر شوكة ظلامه!`}
        </p>

        {/* Boss 5 Ultimate Conqueror Title */}
        {boss.number === 5 && (
          <div className="w-full p-2.5 bg-gradient-to-r from-red-950 via-purple-950 to-red-950 border border-red-500 rounded-xl mb-3">
            <div className="text-xs font-bold text-red-300 flex items-center justify-center gap-1">
              <Sparkles size={14} className="text-yellow-400" />
              <span>لقب أسطوري مكتسب:</span>
            </div>
            <div className="text-sm font-black text-yellow-300 mt-0.5">
              👑 فاتـح الأرواح (Conqueror of Souls)
            </div>
          </div>
        )}

        {/* Reward Coins Box */}
        <div className="w-full bg-gray-950 border border-gray-800 rounded-xl p-3 mb-4 flex items-center justify-around text-xs">
          <div className="flex items-center gap-2 text-amber-400 font-pixel">
            <Coins size={18} className="text-amber-400" />
            <span className="text-sm">+{earnedCoins}</span>
            <span className="font-sans text-gray-400">قطعة روح</span>
          </div>

          {unlockedNextBoss && (
            <div className="flex items-center gap-1 text-cyan-400 font-semibold text-[11px]">
              <CheckCircle size={14} />
              <span>فُتح الزعيم التالي!</span>
            </div>
          )}
        </div>

        {/* Action Buttons */}
        <div className="w-full flex flex-col gap-2">
          {boss.number < 5 ? (
            <button
              onClick={() => {
                soundManager.playSelect();
                onNextBoss();
              }}
              className="w-full py-2.5 bg-amber-600 hover:bg-amber-500 active:scale-95 text-white font-bold rounded-lg shadow-[0_0_12px_rgba(245,158,11,0.4)] flex items-center justify-center gap-2 text-xs transition-all"
            >
              <Play size={16} className="fill-white" />
              <span>مواجهة الزعيم التالي (#{boss.number + 1})</span>
            </button>
          ) : (
            <button
              onClick={() => {
                soundManager.playSelect();
                onReturnToMenu();
              }}
              className="w-full py-2.5 bg-red-600 hover:bg-red-500 active:scale-95 text-white font-bold rounded-lg shadow-[0_0_12px_rgba(239,68,68,0.4)] flex items-center justify-center gap-2 text-xs transition-all"
            >
              <Trophy size={16} />
              <span>تهانينا! أكملت اللعبة بالكامل!</span>
            </button>
          )}

          <button
            onClick={() => {
              soundManager.playSelect();
              onReturnToMenu();
            }}
            className="w-full py-2 bg-gray-800 hover:bg-gray-700 active:scale-95 border border-gray-700 text-gray-300 font-semibold rounded-lg flex items-center justify-center gap-1.5 text-xs transition-all"
          >
            <ArrowRight size={15} />
            <span>العودة للقائمة الرئيسية</span>
          </button>
        </div>
      </div>
    </div>
  );
};
