import React, { useState } from 'react';
import { PlayerSaveData } from '../types/game';
import { SOUL_CHALLENGES } from '../data/shop';
import { soundManager } from '../audio/soundManager';
import { ArrowRight, Swords, CheckCircle2, Award, Coins, Sparkles, Shield, Flame } from 'lucide-react';

interface ChallengesModalProps {
  playerData: PlayerSaveData;
  onUpdatePlayerData: (updater: (prev: PlayerSaveData) => PlayerSaveData) => void;
  onBackToMenu: () => void;
}

export const ChallengesModal: React.FC<ChallengesModalProps> = ({
  playerData,
  onUpdatePlayerData,
  onBackToMenu,
}) => {
  const [claimNotice, setClaimNotice] = useState<string | null>(null);

  const handleClaimReward = (chalId: string) => {
    const chal = SOUL_CHALLENGES.find((c) => c.id === chalId);
    if (!chal) return;

    onUpdatePlayerData((prev) => {
      let coins = prev.soulCoins + chal.rewardCoins;
      let titles = [...prev.unlockedTitles];
      let frames = [...prev.unlockedFrames];
      let trails = [...prev.unlockedTrails];

      if (chal.rewardTitle && !titles.includes(chal.rewardTitle)) {
        titles.push(chal.rewardTitle);
      }
      if (chal.rewardFrame && !frames.includes(chal.rewardFrame)) {
        frames.push(chal.rewardFrame);
      }
      if (chal.rewardTrail && !trails.includes(chal.rewardTrail)) {
        trails.push(chal.rewardTrail);
      }

      return {
        ...prev,
        soulCoins: coins,
        totalCoinsEarned: prev.totalCoinsEarned + chal.rewardCoins,
        unlockedTitles: titles,
        unlockedFrames: frames,
        unlockedTrails: trails,
        challenges: {
          ...prev.challenges,
          [chalId]: {
            ...prev.challenges[chalId],
            isCompleted: true,
            isClaimed: true,
          },
        },
      };
    });

    soundManager.playVictory();
    setClaimNotice(`تم استلام مكافأة "${chal.titleAr}" بنجاح! 🎉`);
    setTimeout(() => setClaimNotice(null), 2500);
  };

  return (
    <div className="relative w-full h-full flex flex-col p-4 bg-gradient-to-b from-gray-950 via-black to-gray-950 overflow-y-auto select-none">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-gray-800 pb-3 mb-3">
        <button
          onClick={() => {
            soundManager.playSelect();
            onBackToMenu();
          }}
          className="flex items-center gap-1.5 text-xs text-gray-400 hover:text-white bg-gray-900 border border-gray-700 px-3 py-1.5 rounded active:scale-95 transition-all"
        >
          <ArrowRight size={16} />
          <span>الرئيسية</span>
        </button>

        <h2 className="text-base font-bold text-white flex items-center gap-2">
          <Swords size={18} className="text-amber-400" />
          <span>تحديات الأرواح — SOUL CHALLENGES</span>
        </h2>
      </div>

      {claimNotice && (
        <div className="sticky top-0 z-30 mb-2 py-1.5 px-3 bg-green-900/90 border border-green-400 text-green-100 rounded text-center text-xs font-semibold animate-pulse shadow-lg">
          {claimNotice}
        </div>
      )}

      <div className="max-w-md mx-auto w-full flex flex-col gap-3 pb-8 text-right text-xs">
        <div className="p-2.5 bg-gray-900/80 border border-gray-800 rounded-xl text-gray-400 text-[11px] leading-relaxed">
          ⚔️ أكمل هذه التحديات التكتيكية أثناء خوض معارك الزعماء لتحصل على عملات إضافية وألقاب وإطارات حصرية لملفك الشخصي!
        </div>

        {SOUL_CHALLENGES.map((chal) => {
          const userState = playerData.challenges[chal.id] || { isCompleted: false, isClaimed: false };
          const isDone = userState.isCompleted;
          const isClaimed = userState.isClaimed;

          return (
            <div
              key={chal.id}
              className={`p-4 rounded-2xl border transition-all flex flex-col gap-3 ${
                isClaimed
                  ? 'bg-gray-950/70 border-gray-800 opacity-75'
                  : isDone
                  ? 'bg-amber-950/30 border-amber-500/80 shadow-[0_0_15px_rgba(245,158,11,0.25)]'
                  : 'bg-gray-900/90 border-gray-800 shadow-md'
              }`}
            >
              <div className="flex items-start justify-between border-b border-gray-800/80 pb-2">
                <div>
                  <h3 className="font-bold text-sm text-white flex items-center gap-1.5">
                    <span>{chal.titleAr}</span>
                    {isDone && <CheckCircle2 size={16} className="text-green-400" />}
                  </h3>
                  <div className="text-[11px] text-gray-400 mt-0.5">{chal.descriptionAr}</div>
                </div>

                <div className="font-pixel text-[10px] text-amber-400 bg-amber-950/60 border border-amber-600/60 px-2 py-0.5 rounded">
                  +{chal.rewardCoins} 🪙
                </div>
              </div>

              {/* Condition Note */}
              <div className="bg-gray-950 p-2 rounded-lg border border-gray-800/80 text-[11px] text-gray-300">
                🎯 <span className="font-bold text-amber-300">شرط الإكمال:</span> {chal.conditionAr}
              </div>

              {/* Reward Extras Badge */}
              <div className="flex items-center justify-between pt-1">
                <div className="text-[10px] text-purple-300 font-semibold flex items-center gap-1">
                  {chal.rewardTitle && <span>👑 اللقب: {chal.rewardTitle}</span>}
                  {chal.rewardFrame && <span>🖼️ إطار: حارس الأرواح</span>}
                  {chal.rewardTrail && <span>✨ أثر: أثر الروح الأزرق</span>}
                </div>

                {isClaimed ? (
                  <span className="text-[10px] text-green-400 font-bold bg-green-950/60 px-2.5 py-1 rounded border border-green-800">
                    تم الاستلام ✅
                  </span>
                ) : isDone ? (
                  <button
                    onClick={() => handleClaimReward(chal.id)}
                    className="py-1 px-3 bg-gradient-to-r from-amber-600 to-yellow-500 hover:from-amber-500 text-white font-bold rounded-lg text-xs shadow-md animate-pulse active:scale-95"
                  >
                    استلم المكافأة! 🎁
                  </button>
                ) : (
                  <span className="text-[10px] text-gray-500 bg-gray-950 px-2 py-0.5 rounded border border-gray-800">
                    قيد التحدي ⏳
                  </span>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
