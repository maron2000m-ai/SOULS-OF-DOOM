import React, { useState } from 'react';
import { PlayerSaveData } from '../types/game';
import { INITIAL_ACHIEVEMENTS } from '../data/shop';
import { soundManager } from '../audio/soundManager';
import { ArrowRight, User, Shield, Trophy, Flame, Coins, Clock, Award, Check, Edit2, Crown, Sparkles, Gem } from 'lucide-react';

interface ProfileModalProps {
  playerData: PlayerSaveData;
  onUpdatePlayerData: (updater: (prev: PlayerSaveData) => PlayerSaveData) => void;
  onBackToMenu: () => void;
}

const AVATARS = [
  { id: 'avatar_soul', label: 'الروح الأصلية', color: '#ef4444' },
  { id: 'avatar_skeleton', label: 'عظام الظلام', color: '#38bdf8' },
  { id: 'avatar_witch', label: 'ساحرة اللهب', color: '#c084fc' },
  { id: 'avatar_knight', label: 'فارس الفراغ', color: '#06b6d4' },
  { id: 'avatar_time', label: 'حارس الزمن', color: '#f59e0b' },
  { id: 'avatar_reaper', label: 'حاصد الأرواح', color: '#a855f7' },
  { id: 'avatar_dragon', label: 'التنين الصفري', color: '#0284c7' },
];

export const ProfileModal: React.FC<ProfileModalProps> = ({
  playerData,
  onUpdatePlayerData,
  onBackToMenu,
}) => {
  const [activeTab, setActiveTab] = useState<'STATS' | 'TITLES' | 'ACHIEVEMENTS'>('STATS');
  const [isEditingName, setIsEditingName] = useState(false);
  const [nameInput, setNameInput] = useState(playerData.playerName);

  // Format playtime
  const hours = Math.floor(playerData.playtimeSeconds / 3600);
  const minutes = Math.floor((playerData.playtimeSeconds % 3600) / 60);
  const seconds = playerData.playtimeSeconds % 60;
  const timeFormatted = `${hours}س ${minutes}د ${seconds}ث`;

  // XP Progress formula: each level takes (level * 200) XP
  const xpNeeded = playerData.level * 200;
  const xpPercent = Math.min(100, Math.round((playerData.xp / xpNeeded) * 100));

  const handleSaveName = () => {
    if (nameInput.trim()) {
      onUpdatePlayerData((prev) => ({
        ...prev,
        playerName: nameInput.trim().slice(0, 20),
      }));
      soundManager.playSelect();
    }
    setIsEditingName(false);
  };

  const handleSelectAvatar = (avId: string) => {
    soundManager.playEquip();
    onUpdatePlayerData((prev) => ({
      ...prev,
      avatar: avId,
    }));
  };

  const handleEquipTitle = (title: string) => {
    soundManager.playEquip();
    onUpdatePlayerData((prev) => ({
      ...prev,
      equippedTitle: title,
    }));
  };

  const currentAvatar = AVATARS.find((a) => a.id === playerData.avatar) || AVATARS[0];

  return (
    <div className="relative w-full h-full flex flex-col p-4 bg-gradient-to-b from-gray-950 via-black to-gray-950 overflow-y-auto select-none">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-gray-800 pb-3 mb-3">
        <button
          onClick={() => {
            soundManager.playSelect();
            onBackToMenu();
          }}
          className="flex items-center gap-1.5 text-xs text-gray-400 hover:text-white bg-gray-900 border border-gray-700 px-3 py-1.5 rounded active:scale-95 transition-all"
        >
          <ArrowRight size={16} />
          <span>الرئيسية</span>
        </button>

        <h2 className="text-base font-bold text-white flex items-center gap-2">
          <User size={18} className="text-cyan-400" />
          <span>الملف الشخصي للمحارب</span>
        </h2>
      </div>

      {/* Main Content Area */}
      <div className="max-w-md mx-auto w-full flex flex-col gap-3 pb-8">
        {/* Profile Card Header */}
        <div className="bg-gradient-to-b from-gray-900 to-gray-950 border-2 border-gray-700/80 rounded-2xl p-4 flex flex-col gap-3 shadow-xl relative overflow-hidden">
          <div className="flex items-center gap-3.5">
            {/* Avatar Frame Box */}
            <div
              className="w-16 h-16 rounded-2xl border-2 flex items-center justify-center relative shadow-lg"
              style={{
                borderColor: currentAvatar.color,
                backgroundColor: `${currentAvatar.color}22`,
                boxShadow: `0 0 15px ${currentAvatar.color}44`,
              }}
            >
              <svg viewBox="0 0 24 24" className="w-9 h-9 pixelated" style={{ fill: currentAvatar.color }}>
                <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z" />
              </svg>
              <div className="absolute -bottom-2 bg-black border border-gray-700 px-1.5 py-0.2 rounded font-pixel text-[9px] text-amber-300">
                مستوى {playerData.level}
              </div>
            </div>

            {/* Name, Title, and Level */}
            <div className="flex-1 text-right">
              <div className="flex items-center justify-end gap-2">
                {isEditingName ? (
                  <div className="flex items-center gap-1">
                    <input
                      type="text"
                      value={nameInput}
                      onChange={(e) => setNameInput(e.target.value)}
                      className="bg-black border border-cyan-500 rounded px-2 py-0.5 text-xs text-white max-w-[130px] text-right"
                      autoFocus
                    />
                    <button
                      onClick={handleSaveName}
                      className="p-1 bg-cyan-600 hover:bg-cyan-500 rounded text-white"
                    >
                      <Check size={14} />
                    </button>
                  </div>
                ) : (
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => setIsEditingName(true)}
                      className="text-gray-500 hover:text-gray-300 p-0.5"
                      title="تعديل الاسم"
                    >
                      <Edit2 size={13} />
                    </button>
                    <span className="font-bold text-sm text-white">{playerData.playerName}</span>
                  </div>
                )}
              </div>

              {/* Equipped Title */}
              <div className="text-[11px] font-bold text-amber-300 flex items-center justify-end gap-1 mt-0.5">
                <Crown size={13} className="text-amber-400" />
                <span>{playerData.equippedTitle}</span>
              </div>

              {/* XP Bar */}
              <div className="mt-2">
                <div className="flex items-center justify-between text-[10px] text-gray-400 mb-0.5">
                  <span className="font-pixel text-[9px]">{xpPercent}%</span>
                  <span>الخبرة: {playerData.xp} / {xpNeeded} XP</span>
                </div>
                <div className="w-full h-2 bg-gray-950 border border-gray-700 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-cyan-500 to-blue-500 transition-all duration-300 rounded-full"
                    style={{ width: `${xpPercent}%` }}
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Avatar Selector Tray */}
          <div className="border-t border-gray-800/80 pt-2 flex flex-col gap-1.5">
            <span className="text-[10px] text-gray-400 text-right">تغيير الصورة الشخصية:</span>
            <div className="flex items-center justify-between gap-1 overflow-x-auto py-1">
              {AVATARS.map((av) => {
                const isSelected = playerData.avatar === av.id;
                return (
                  <button
                    key={av.id}
                    onClick={() => handleSelectAvatar(av.id)}
                    className={`p-1.5 rounded-xl border-2 transition-all flex flex-col items-center gap-0.5 ${
                      isSelected
                        ? 'border-cyan-400 bg-cyan-950/60 shadow-[0_0_8px_rgba(6,182,212,0.4)]'
                        : 'border-gray-800 bg-gray-900/60 opacity-60 hover:opacity-100'
                    }`}
                  >
                    <div
                      className="w-6 h-6 rounded-lg flex items-center justify-center"
                      style={{ backgroundColor: `${av.color}33` }}
                    >
                      <div className="w-3.5 h-3.5 rounded-full" style={{ backgroundColor: av.color }} />
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex gap-1.5">
          <button
            onClick={() => {
              soundManager.playSelect();
              setActiveTab('STATS');
            }}
            className={`flex-1 py-1.5 rounded-lg text-xs font-bold border transition-all ${
              activeTab === 'STATS'
                ? 'bg-cyan-950 border-cyan-500 text-cyan-200'
                : 'bg-gray-900/60 border-gray-800 text-gray-400'
            }`}
          >
            الإحصائيات
          </button>
          <button
            onClick={() => {
              soundManager.playSelect();
              setActiveTab('TITLES');
            }}
            className={`flex-1 py-1.5 rounded-lg text-xs font-bold border transition-all ${
              activeTab === 'TITLES'
                ? 'bg-amber-950 border-amber-500 text-amber-200'
                : 'bg-gray-900/60 border-gray-800 text-gray-400'
            }`}
          >
            الألقاب المفتوحة
          </button>
          <button
            onClick={() => {
              soundManager.playSelect();
              setActiveTab('ACHIEVEMENTS');
            }}
            className={`flex-1 py-1.5 rounded-lg text-xs font-bold border transition-all ${
              activeTab === 'ACHIEVEMENTS'
                ? 'bg-purple-950 border-purple-500 text-purple-200'
                : 'bg-gray-900/60 border-gray-800 text-gray-400'
            }`}
          >
            الإنجازات
          </button>
        </div>

        {/* Tab 1: Detailed Stats */}
        {activeTab === 'STATS' && (
          <div className="grid grid-cols-2 gap-2 text-right text-xs">
            <div className="p-2.5 bg-gray-900/80 border border-gray-800 rounded-xl flex flex-col justify-between">
              <span className="text-gray-400 flex items-center gap-1">
                <Trophy size={14} className="text-amber-400" />
                <span>الزعماء المهزومون:</span>
              </span>
              <span className="font-pixel text-sm text-white mt-1">
                {playerData.defeatedBosses.length} / 7
              </span>
            </div>

            <div className="p-2.5 bg-gray-900/80 border border-gray-800 rounded-xl flex flex-col justify-between">
              <span className="text-gray-400 flex items-center gap-1">
                <Shield size={14} className="text-cyan-400" />
                <span>سجل الانتصارات:</span>
              </span>
              <span className="font-pixel text-sm text-green-400 mt-1">
                {playerData.totalWins} فوز / {playerData.totalLosses} هزيمة
              </span>
            </div>

            <div className="p-2.5 bg-gray-900/80 border border-gray-800 rounded-xl flex flex-col justify-between">
              <span className="text-gray-400 flex items-center gap-1">
                <Coins size={14} className="text-amber-400" />
                <span>إجمالي العملات المكتسبة:</span>
              </span>
              <span className="font-pixel text-sm text-amber-400 mt-1">
                {playerData.totalCoinsEarned}
              </span>
            </div>

            <div className="p-2.5 bg-gray-900/80 border border-gray-800 rounded-xl flex flex-col justify-between">
              <span className="text-gray-400 flex items-center gap-1">
                <Gem size={14} className="text-purple-400" />
                <span>السكنات المملوكة:</span>
              </span>
              <span className="font-pixel text-sm text-purple-300 mt-1">
                {playerData.purchasedSkins.length} سكن
              </span>
            </div>

            <div className="p-2.5 bg-gray-900/80 border border-gray-800 rounded-xl flex flex-col justify-between">
              <span className="text-gray-400 flex items-center gap-1">
                <Flame size={14} className="text-red-400" />
                <span>أصعب زعيم تم هزيمته:</span>
              </span>
              <span className="text-xs font-bold text-red-300 mt-1">
                {playerData.hardestBossDefeated}
              </span>
            </div>

            <div className="p-2.5 bg-gray-900/80 border border-gray-800 rounded-xl flex flex-col justify-between">
              <span className="text-gray-400 flex items-center gap-1">
                <Clock size={14} className="text-blue-400" />
                <span>إجمالي وقت اللعب:</span>
              </span>
              <span className="text-xs font-semibold text-gray-300 mt-1">
                {timeFormatted}
              </span>
            </div>
          </div>
        )}

        {/* Tab 2: Titles List & Equip */}
        {activeTab === 'TITLES' && (
          <div className="flex flex-col gap-2 text-right text-xs">
            {playerData.unlockedTitles.map((title) => {
              const isEquipped = playerData.equippedTitle === title;
              return (
                <div
                  key={title}
                  className={`p-3 rounded-xl border flex items-center justify-between transition-all ${
                    isEquipped
                      ? 'bg-amber-950/40 border-amber-500 shadow-[0_0_10px_rgba(245,158,11,0.2)]'
                      : 'bg-gray-900/80 border-gray-800'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <Crown size={16} className={isEquipped ? 'text-amber-400' : 'text-gray-500'} />
                    <span className="font-bold text-white">{title}</span>
                  </div>

                  <button
                    onClick={() => handleEquipTitle(title)}
                    disabled={isEquipped}
                    className={`px-3 py-1 rounded text-[11px] font-bold transition-all ${
                      isEquipped
                        ? 'bg-amber-600 text-white cursor-default'
                        : 'bg-gray-800 hover:bg-gray-700 text-gray-300 active:scale-95'
                    }`}
                  >
                    {isEquipped ? 'مجهز' : 'تجهيز'}
                  </button>
                </div>
              );
            })}
          </div>
        )}

        {/* Tab 3: Achievements List */}
        {activeTab === 'ACHIEVEMENTS' && (
          <div className="flex flex-col gap-2 text-right text-xs">
            {INITIAL_ACHIEVEMENTS.map((ach) => {
              const isUnlocked = playerData.achievements.includes(ach.id);
              return (
                <div
                  key={ach.id}
                  className={`p-3 rounded-xl border flex items-start justify-between gap-2.5 transition-all ${
                    isUnlocked
                      ? 'bg-purple-950/30 border-purple-500/80 shadow-[0_0_10px_rgba(168,85,247,0.2)]'
                      : 'bg-gray-950/70 border-gray-800 opacity-60'
                  }`}
                >
                  <div className="flex-1">
                    <div className="flex items-center gap-1.5 font-bold text-white text-xs mb-0.5">
                      <Award size={14} className={isUnlocked ? 'text-purple-400' : 'text-gray-500'} />
                      <span>{ach.titleAr}</span>
                      {isUnlocked && (
                        <span className="bg-purple-900 text-purple-200 text-[9px] px-1.5 py-0.2 rounded font-sans">
                          مكتمل ✅
                        </span>
                      )}
                    </div>
                    <div className="text-[11px] text-gray-400">{ach.descriptionAr}</div>
                    {ach.rewardTitle && (
                      <div className="text-[10px] text-amber-300 mt-1">
                        🏆 اللقب المكتسب: {ach.rewardTitle}
                      </div>
                    )}
                  </div>

                  <div className="flex flex-col items-end gap-1 font-pixel text-[10px] text-amber-400 shrink-0">
                    <span>+{ach.rewardCoins} 🪙</span>
                    <span className="text-cyan-400 font-pixel">+{ach.rewardXp} XP</span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
