import React from 'react';
import { soundManager } from '../audio/soundManager';
import { ArrowRight, Info, BookOpen, Swords, HeartHandshake, Sparkles, Shield, Smartphone, Gamepad2 } from 'lucide-react';

interface InfoModalProps {
  onBackToMenu: () => void;
}

export const InfoModal: React.FC<InfoModalProps> = ({ onBackToMenu }) => {
  return (
    <div className="relative w-full h-full flex flex-col p-4 bg-gradient-to-b from-gray-950 via-black to-gray-950 overflow-y-auto select-none">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-gray-800 pb-3 mb-3">
        <button
          onClick={() => {
            soundManager.playSelect();
            onBackToMenu();
          }}
          className="flex items-center gap-1.5 text-xs text-gray-400 hover:text-white bg-gray-900 border border-gray-700 px-3 py-1.5 rounded active:scale-95 transition-all"
        >
          <ArrowRight size={16} />
          <span>الرئيسية</span>
        </button>

        <h2 className="text-base font-bold text-white flex items-center gap-2">
          <Info size={18} className="text-blue-400" />
          <span>دليل ومعلومات اللعبة</span>
        </h2>
      </div>

      {/* Info Content */}
      <div className="max-w-md mx-auto w-full flex flex-col gap-3.5 pb-8 text-right text-xs leading-relaxed text-gray-300">
        {/* Story */}
        <div className="bg-gray-900/80 border border-gray-800 rounded-xl p-3.5 flex flex-col gap-2">
          <div className="font-bold text-sm text-red-400 flex items-center gap-1.5 border-b border-gray-800 pb-1.5">
            <BookOpen size={16} />
            <span>قصة معركة الأرواح</span>
          </div>
          <p>
            في عالم طغت عليه ظلال العدم، حُبست شعلة روحك النقية في ساحة اختبار مظلمة. خمسة زعماء أسطوريين يقفون بينك وبين استعادة حرية الأرواح. لن تنقذك القوة وحدها؛ رشاقة المراوغة ونقاء القلب وقوة العزيمة هي أسلحتك الحقيقية.
          </p>
        </div>

        {/* 4 Commands Guide */}
        <div className="bg-gray-900/80 border border-gray-800 rounded-xl p-3.5 flex flex-col gap-2.5">
          <div className="font-bold text-sm text-amber-400 flex items-center gap-1.5 border-b border-gray-800 pb-1.5">
            <Swords size={16} />
            <span>أوامر القتال الأربعة</span>
          </div>

          <div className="flex flex-col gap-2 text-[11px]">
            <div className="p-2 bg-red-950/30 border border-red-900/50 rounded flex items-start gap-2">
              <Swords size={16} className="text-red-400 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold text-red-300">قتـال:</span> إطلاق مقياس دقة الهجوم. اضغط عندما يكون المؤشر في المنتصف تمامًا لتحقيق ضربة حرجة وإلحاق ضرر مضاعف بالزعيم!
              </div>
            </div>

            <div className="p-2 bg-cyan-950/30 border border-cyan-900/50 rounded flex items-start gap-2">
              <Info size={16} className="text-cyan-400 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold text-cyan-300">فحـص:</span> يحلل إحصائيات هجوم ودفاع الزعيم، ويعطيك نصائح تكتيكية ثمينة لتجاوز أنماط هجماته.
              </div>
            </div>

            <div className="p-2 bg-purple-950/30 border border-purple-900/50 rounded flex items-start gap-2">
              <Sparkles size={16} className="text-purple-400 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold text-purple-300">عنصـر:</span> استخدام الجرعات العلاجية والدروع المخزنة في حقيبتك لاستعادة الصحة أو امتصاص الضرر.
              </div>
            </div>

            <div className="p-2 bg-amber-950/30 border border-amber-900/50 rounded flex items-start gap-2">
              <HeartHandshake size={16} className="text-amber-400 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold text-amber-300">رحمـة:</span> عندما تنخفض صحة الزعيم، يمكنك منحه الهدنة وإيقاف المعركة بشرف للحصول على مكافآت خاصة وحوارات فريدة.
              </div>
            </div>
          </div>
        </div>

        {/* Controls Guide */}
        <div className="bg-gray-900/80 border border-gray-800 rounded-xl p-3.5 flex flex-col gap-2.5">
          <div className="font-bold text-sm text-cyan-400 flex items-center gap-1.5 border-b border-gray-800 pb-1.5">
            <Smartphone size={16} />
            <span>طريقة التحكم</span>
          </div>

          <div className="grid grid-cols-2 gap-2 text-[11px]">
            <div className="bg-gray-950 p-2 rounded border border-gray-800">
              <div className="font-bold text-white mb-1 flex items-center gap-1">
                <Smartphone size={14} className="text-cyan-400" />
                <span>هواتف Android:</span>
              </div>
              <ul className="text-gray-400 space-y-1">
                <li>• أزرار الاتجاهات (D-Pad) السفلية.</li>
                <li>• أو لمس وسحب الإصبع داخل الساحة مباشرة.</li>
              </ul>
            </div>

            <div className="bg-gray-950 p-2 rounded border border-gray-800">
              <div className="font-bold text-white mb-1 flex items-center gap-1">
                <Gamepad2 size={14} className="text-purple-400" />
                <span>لوحة المفاتيح:</span>
              </div>
              <ul className="text-gray-400 space-y-1">
                <li>• الأسهم أو مفاتيح WASD للحركة.</li>
                <li>• مسافة (Space) لضرب الهجوم.</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Mechanics Tip */}
        <div className="p-3 bg-cyan-950/40 border border-cyan-600/40 rounded-xl text-cyan-200 text-xs">
          🛡️ <span className="font-bold">فترة الحماية (I-Frames):</span> عند تلقي الضرر، تومض الروح لمدة ثانية واحدة وتكون محصنة تمامًا من الهجمات لمنع الهزيمة اللحظية!
        </div>
      </div>
    </div>
  );
};
