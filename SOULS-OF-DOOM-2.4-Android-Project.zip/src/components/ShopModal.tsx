import React, { useState } from 'react';
import { PlayerSaveData, SoulSkin } from '../types/game';
import { SHOP_PRODUCTS, SOUL_SKINS, DAILY_STREAK_REWARDS, ShopProduct } from '../data/shop';
import { soundManager } from '../audio/soundManager';
import { ArrowRight, Coins, Heart, Shield, FlaskConical, Sparkles, Check, HeartPulse, ShoppingBag, Gift, Award, Crown, Zap, Flame, Trophy } from 'lucide-react';

interface ShopModalProps {
  playerData: PlayerSaveData;
  onUpdatePlayerData: (updater: (prev: PlayerSaveData) => PlayerSaveData) => void;
  onBackToMenu: () => void;
}

export const ShopModal: React.FC<ShopModalProps> = ({
  playerData,
  onUpdatePlayerData,
  onBackToMenu,
}) => {
  const [activeTab, setActiveTab] = useState<'SKINS' | 'ITEMS' | 'TITLES' | 'DAILY'>('SKINS');
  const [purchaseMsg, setPurchaseMsg] = useState<string | null>(null);

  const showNotification = (msg: string) => {
    setPurchaseMsg(msg);
    setTimeout(() => {
      setPurchaseMsg(null);
    }, 2400);
  };

  // Today's date string YYYY-MM-DD
  const todayStr = new Date().toISOString().split('T')[0];
  const canClaimDaily = playerData.dailyRewards.lastClaimDate !== todayStr;
  const currentStreak = playerData.dailyRewards.streak;
  const nextDayIndex = (currentStreak % 7); // 0 to 6

  // Handle Daily Streak Claim
  const handleClaimDailyReward = () => {
    if (!canClaimDaily) {
      showNotification('لقد استلمت مكافأة اليوم بالفعل! عُد غدًا لمواصلة السلسلة.');
      return;
    }

    const reward = DAILY_STREAK_REWARDS[nextDayIndex];
    const newStreak = (currentStreak % 7) + 1;

    onUpdatePlayerData((prev) => {
      let coins = prev.soulCoins;
      let inv = [...prev.inventory];
      let frames = [...prev.unlockedFrames];

      if (reward.type === 'COINS' || reward.type === 'CHEST') {
        coins += (reward.amount || 0);
      } else if (reward.type === 'ITEM') {
        const exist = inv.find((i) => i.type === reward.itemType);
        if (exist) {
          inv = inv.map((i) => i.type === reward.itemType ? { ...i, quantity: i.quantity + 1 } : i);
        } else {
          inv.push({
            id: 'daily_potion_full',
            nameAr: 'جرعة علاج فائقة',
            descriptionAr: 'تستعيد 100% من الصحة.',
            type: 'HEAL_FULL',
            quantity: 1,
            iconName: 'Sparkles',
          });
        }
      } else if (reward.type === 'FRAME' && reward.frameId) {
        if (!frames.includes(reward.frameId)) frames.push(reward.frameId);
      }

      return {
        ...prev,
        soulCoins: coins,
        totalCoinsEarned: prev.totalCoinsEarned + (reward.amount || 0),
        inventory: inv,
        unlockedFrames: frames,
        dailyRewards: {
          ...prev.dailyRewards,
          lastClaimDate: todayStr,
          streak: newStreak,
        },
      };
    });

    soundManager.playChestOpen();
    showNotification(`مبروك! استلمت مكافأة اليوم ${newStreak}: ${reward.label}! 🎉`);
  };

  // Handle Free Milestone Boss Chest
  const handleClaimMilestoneChest = () => {
    if (playerData.defeatedBosses.length === 0) {
      showNotification('اهزم زعيمًا واحدًا على الأقل لفتح هذا الصندوق المجاني!');
      return;
    }
    if (playerData.dailyRewards.bossMilestoneClaimed) {
      showNotification('تم استلام صندوق إنجاز الزعماء بالفعل لهذا الحساب!');
      return;
    }

    onUpdatePlayerData((prev) => ({
      ...prev,
      soulCoins: prev.soulCoins + 200,
      totalCoinsEarned: prev.totalCoinsEarned + 200,
      dailyRewards: {
        ...prev.dailyRewards,
        bossMilestoneClaimed: true,
      },
    }));

    soundManager.playVictory();
    showNotification('فتحت صندوق إنجاز الزعماء بنجاح! حصلت على 200 قطعة روح! 🎁');
  };

  // Buy or Equip Skin
  const handleBuyOrEquipSkin = (skin: SoulSkin) => {
    const isOwned = playerData.purchasedSkins.includes(skin.id);
    const isEquipped = playerData.equippedSkin === skin.id;

    // Special King Skin unlock check: defeat 3 bosses
    if (!isOwned && skin.id === 'skin_king' && playerData.defeatedBosses.length >= 3) {
      onUpdatePlayerData((prev) => ({
        ...prev,
        purchasedSkins: [...prev.purchasedSkins, skin.id],
        equippedSkin: skin.id,
      }));
      soundManager.playVictory();
      showNotification('فتحت قلب الملك 👑 مجانًا لإسقاطك 3 زعماء! تم التجهيز.');
      return;
    }

    if (isEquipped) {
      // Unequip -> reverts to Crimson default
      onUpdatePlayerData((prev) => ({
        ...prev,
        equippedSkin: 'skin_crimson',
        equippedTrail: 'none',
      }));
      soundManager.playSelect();
      showNotification('تمت إزالة التجهيز والعودة إلى الروح الأصلية.');
      return;
    }

    if (isOwned) {
      // Equip
      onUpdatePlayerData((prev) => ({
        ...prev,
        equippedSkin: skin.id,
        equippedTrail: skin.trailType || 'none',
      }));
      soundManager.playEquip();
      showNotification(`تم تجهيز "${skin.nameAr}" بنجاح!`);
      return;
    }

    // Purchase
    if (playerData.soulCoins < skin.price) {
      soundManager.playDamage();
      showNotification('رصيدك من قطع الروح غير كافٍ لشراء هذا السكن!');
      return;
    }

    onUpdatePlayerData((prev) => ({
      ...prev,
      soulCoins: prev.soulCoins - skin.price,
      totalCoinsSpent: prev.totalCoinsSpent + skin.price,
      purchasedSkins: [...prev.purchasedSkins, skin.id],
      equippedSkin: skin.id,
      equippedTrail: skin.trailType || 'none',
    }));

    soundManager.playVictory();
    showNotification(`تم شراء وتجهيز "${skin.nameAr}"! ✨`);
  };

  // Buy Shop Product (Potions, Upgrades, Titles, Frames)
  const handleBuyProduct = (prod: ShopProduct) => {
    if (playerData.soulCoins < prod.price) {
      soundManager.playDamage();
      showNotification('رصيدك من قطع الروح غير كافٍ!');
      return;
    }

    if (prod.type === 'MAX_HP_UPGRADE') {
      if (playerData.hpUpgradesBought >= 3) {
        showNotification('وصلت للحد الأقصى لترقيات الصحة (3/3)!');
        return;
      }
      onUpdatePlayerData((prev) => ({
        ...prev,
        soulCoins: prev.soulCoins - prod.price,
        totalCoinsSpent: prev.totalCoinsSpent + prod.price,
        maxHp: prev.maxHp + 10,
        currentHp: prev.currentHp + 10,
        hpUpgradesBought: prev.hpUpgradesBought + 1,
      }));
      soundManager.playHeal();
      showNotification(`تمت ترقية الصحة بنجاح! الحد الأقصى: ${playerData.maxHp + 10} HP`);
      return;
    }

    if (prod.type === 'TITLE') {
      const titleName = prod.nameAr.replace('لقب: ', '');
      if (playerData.unlockedTitles.includes(titleName)) {
        showNotification('أنت تمتلك هذا اللقب بالفعل!');
        return;
      }
      onUpdatePlayerData((prev) => ({
        ...prev,
        soulCoins: prev.soulCoins - prod.price,
        totalCoinsSpent: prev.totalCoinsSpent + prod.price,
        unlockedTitles: [...prev.unlockedTitles, titleName],
        equippedTitle: titleName,
      }));
      soundManager.playEquip();
      showNotification(`تم شراء اللقب "${titleName}" وتجهيزه! 👑`);
      return;
    }

    if (prod.type === 'POTION' || prod.type === 'MEGA_POTION' || prod.type === 'SHIELD') {
      onUpdatePlayerData((prev) => {
        const itemType =
          prod.type === 'POTION'
            ? 'HEAL_30'
            : prod.type === 'MEGA_POTION'
            ? 'HEAL_FULL'
            : 'SHIELD_BUFF';

        const existing = prev.inventory.find((i) => i.type === itemType);
        let newInv = [...prev.inventory];
        if (existing) {
          newInv = newInv.map((i) =>
            i.type === itemType ? { ...i, quantity: i.quantity + 1 } : i
          );
        } else {
          newInv.push({
            id: prod.id,
            nameAr: prod.nameAr,
            descriptionAr: prod.descriptionAr,
            type: itemType,
            quantity: 1,
            iconName: prod.icon,
          });
        }

        return {
          ...prev,
          soulCoins: prev.soulCoins - prod.price,
          totalCoinsSpent: prev.totalCoinsSpent + prod.price,
          inventory: newInv,
        };
      });

      soundManager.playHeal();
      showNotification(`تم شراء "${prod.nameAr}" وأضيفت لحقيبتك!`);
    }
  };

  return (
    <div className="relative w-full h-full flex flex-col p-4 bg-gradient-to-b from-gray-950 via-black to-gray-950 overflow-y-auto select-none">
      {/* Top Header */}
      <div className="flex items-center justify-between border-b border-gray-800 pb-3 mb-3">
        <button
          onClick={() => {
            soundManager.playSelect();
            onBackToMenu();
          }}
          className="flex items-center gap-1.5 text-xs text-gray-400 hover:text-white bg-gray-900 border border-gray-700 px-3 py-1.5 rounded active:scale-95 transition-all"
        >
          <ArrowRight size={16} />
          <span>الرئيسية</span>
        </button>

        <div className="flex items-center gap-2">
          <ShoppingBag size={18} className="text-amber-400" />
          <h2 className="text-base font-bold text-white">متجر الأرواح — SOUL SHOP</h2>
        </div>

        {/* Current Coin Balance */}
        <div className="flex items-center gap-1.5 bg-amber-950/60 border border-amber-600/80 px-2.5 py-1 rounded text-xs font-pixel text-amber-300">
          <Coins size={14} className="text-amber-400" />
          <span>{playerData.soulCoins}</span>
        </div>
      </div>

      {/* Floating alert */}
      {purchaseMsg && (
        <div className="sticky top-0 z-30 mb-2 py-1.5 px-3 bg-cyan-900/90 border border-cyan-400 text-cyan-100 rounded text-center text-xs font-semibold animate-pulse shadow-lg">
          {purchaseMsg}
        </div>
      )}

      {/* Tabs */}
      <div className="grid grid-cols-4 gap-1.5 mb-3 max-w-md mx-auto w-full">
        <button
          onClick={() => {
            soundManager.playSelect();
            setActiveTab('SKINS');
          }}
          className={`py-2 rounded-lg text-[11px] font-bold border transition-all ${
            activeTab === 'SKINS'
              ? 'bg-purple-950 border-purple-500 text-purple-200'
              : 'bg-gray-900/60 border-gray-800 text-gray-400 hover:bg-gray-800'
          }`}
        >
          السكنات 🎨
        </button>

        <button
          onClick={() => {
            soundManager.playSelect();
            setActiveTab('ITEMS');
          }}
          className={`py-2 rounded-lg text-[11px] font-bold border transition-all ${
            activeTab === 'ITEMS'
              ? 'bg-amber-950 border-amber-500 text-amber-200'
              : 'bg-gray-900/60 border-gray-800 text-gray-400 hover:bg-gray-800'
          }`}
        >
          العناصر والترقيات 🧪
        </button>

        <button
          onClick={() => {
            soundManager.playSelect();
            setActiveTab('TITLES');
          }}
          className={`py-2 rounded-lg text-[11px] font-bold border transition-all ${
            activeTab === 'TITLES'
              ? 'bg-blue-950 border-blue-500 text-blue-200'
              : 'bg-gray-900/60 border-gray-800 text-gray-400 hover:bg-gray-800'
          }`}
        >
          الألقاب 👑
        </button>

        <button
          onClick={() => {
            soundManager.playSelect();
            setActiveTab('DAILY');
          }}
          className={`py-2 rounded-lg text-[11px] font-bold border transition-all relative ${
            activeTab === 'DAILY'
              ? 'bg-green-950 border-green-500 text-green-200'
              : 'bg-gray-900/60 border-gray-800 text-gray-400 hover:bg-gray-800'
          }`}
        >
          المكافآت 🎁
          {canClaimDaily && (
            <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-green-500 rounded-full animate-ping" />
          )}
        </button>
      </div>

      {/* Main Content */}
      <div className="max-w-md mx-auto w-full flex flex-col gap-3 pb-8">
        {/* TAB 1: SKINS */}
        {activeTab === 'SKINS' && (
          <div className="flex flex-col gap-2.5">
            <div className="text-[11px] text-gray-400 bg-gray-900/70 p-2 rounded-lg text-right border border-gray-800">
              ✨ جميع السكنات تجميلية ولا تمنح أفضلية غير عادلة. تمنح قلبك أثر حركة فريدًا ومظهرًا نيونًا متوهجًا!
            </div>

            {SOUL_SKINS.map((skin) => {
              const isOwned = playerData.purchasedSkins.includes(skin.id);
              const isEquipped = playerData.equippedSkin === skin.id;
              const affordable = playerData.soulCoins >= skin.price;
              const canUnlockKing = skin.id === 'skin_king' && playerData.defeatedBosses.length >= 3;

              return (
                <div
                  key={skin.id}
                  className={`p-3 rounded-xl border-2 flex items-center justify-between gap-3 transition-all ${
                    isEquipped
                      ? 'bg-purple-950/40 border-purple-500 shadow-[0_0_12px_rgba(168,85,247,0.3)]'
                      : 'bg-gray-900/90 border-gray-800'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-11 h-11 rounded-lg bg-gray-950 border border-gray-700 flex items-center justify-center relative">
                      <svg
                        viewBox="0 0 24 24"
                        className="w-7 h-7 pixelated"
                        style={{
                          fill: skin.primaryColor,
                          filter: `drop-shadow(0 0 8px ${skin.primaryColor})`,
                        }}
                      >
                        <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z" />
                      </svg>
                    </div>

                    <div className="text-right">
                      <div className="font-bold text-xs text-white flex items-center gap-1.5">
                        {skin.nameAr}
                        {isEquipped && (
                          <span className="text-[9px] bg-purple-900 text-purple-200 border border-purple-600 px-1.5 rounded">
                            مُجهز
                          </span>
                        )}
                      </div>
                      <div className="text-[11px] text-gray-400">{skin.descriptionAr}</div>
                    </div>
                  </div>

                  {/* Buy / Equip / Unequip Buttons */}
                  <div className="flex flex-col gap-1 shrink-0">
                    {isEquipped ? (
                      <button
                        onClick={() => handleBuyOrEquipSkin(skin)}
                        className="py-1.5 px-3 bg-gray-800 hover:bg-gray-700 active:scale-95 text-gray-300 rounded-lg text-xs font-bold border border-gray-700 transition-all"
                      >
                        إزالة التجهيز
                      </button>
                    ) : isOwned ? (
                      <button
                        onClick={() => handleBuyOrEquipSkin(skin)}
                        className="py-1.5 px-3 bg-cyan-700 hover:bg-cyan-600 active:scale-95 text-white rounded-lg text-xs font-bold transition-all"
                      >
                        تجهيز
                      </button>
                    ) : canUnlockKing ? (
                      <button
                        onClick={() => handleBuyOrEquipSkin(skin)}
                        className="py-1.5 px-3 bg-amber-600 hover:bg-amber-500 active:scale-95 text-white rounded-lg text-xs font-bold font-pixel transition-all animate-pulse"
                      >
                        فتح مجاني!
                      </button>
                    ) : (
                      <button
                        onClick={() => handleBuyOrEquipSkin(skin)}
                        disabled={!affordable}
                        className={`py-1.5 px-3 rounded-lg text-xs font-bold font-pixel flex items-center gap-1 transition-all active:scale-95 ${
                          affordable
                            ? 'bg-amber-600 hover:bg-amber-500 text-white shadow-md'
                            : 'bg-gray-800 text-gray-600 cursor-not-allowed opacity-60'
                        }`}
                      >
                        <Coins size={12} />
                        <span>{skin.price}</span>
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* TAB 2: ITEMS & UPGRADES */}
        {activeTab === 'ITEMS' && (
          <div className="flex flex-col gap-2.5">
            {SHOP_PRODUCTS.filter((p) => p.category === 'ITEMS').map((prod) => {
              const isMaxHp = prod.type === 'MAX_HP_UPGRADE';
              const maxReached = isMaxHp && playerData.hpUpgradesBought >= 3;
              const affordable = playerData.soulCoins >= prod.price;

              return (
                <div
                  key={prod.id}
                  className="p-3 bg-gray-900/90 border border-gray-800 rounded-xl flex items-center justify-between gap-3 shadow hover:border-gray-700 transition-all"
                >
                  <div className="flex items-center gap-2.5">
                    <div className="w-10 h-10 rounded-lg bg-gray-950 border border-gray-700 flex items-center justify-center text-amber-400">
                      {prod.type === 'POTION' && <FlaskConical size={20} className="text-cyan-400" />}
                      {prod.type === 'MEGA_POTION' && <Sparkles size={20} className="text-purple-400" />}
                      {prod.type === 'MAX_HP_UPGRADE' && <HeartPulse size={20} className="text-red-400" />}
                      {prod.type === 'SHIELD' && <Shield size={20} className="text-blue-400" />}
                    </div>
                    <div className="text-right">
                      <div className="font-bold text-xs text-white flex items-center gap-2">
                        {prod.nameAr}
                        {isMaxHp && (
                          <span className="text-[10px] bg-red-950 text-red-300 border border-red-700 px-1.5 rounded font-pixel">
                            {playerData.hpUpgradesBought}/3
                          </span>
                        )}
                      </div>
                      <div className="text-[11px] text-gray-400 leading-snug">
                        {prod.descriptionAr}
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={() => handleBuyProduct(prod)}
                    disabled={maxReached || !affordable}
                    className={`py-1.5 px-3 rounded-lg font-pixel text-xs font-bold flex items-center gap-1.5 shrink-0 transition-all active:scale-95 ${
                      maxReached
                        ? 'bg-gray-800 text-gray-500 border border-gray-700 cursor-not-allowed'
                        : affordable
                        ? 'bg-amber-600 hover:bg-amber-500 text-white shadow-md'
                        : 'bg-gray-800/80 text-gray-500 border border-gray-700 cursor-not-allowed opacity-60'
                    }`}
                  >
                    <Coins size={12} />
                    <span>{maxReached ? 'مكتمل' : `${prod.price}`}</span>
                  </button>
                </div>
              );
            })}
          </div>
        )}

        {/* TAB 3: TITLES */}
        {activeTab === 'TITLES' && (
          <div className="flex flex-col gap-2.5">
            {SHOP_PRODUCTS.filter((p) => p.category === 'TITLES').map((prod) => {
              const titleName = prod.nameAr.replace('لقب: ', '');
              const isOwned = playerData.unlockedTitles.includes(titleName);
              const isEquipped = playerData.equippedTitle === titleName;
              const affordable = playerData.soulCoins >= prod.price;

              return (
                <div
                  key={prod.id}
                  className="p-3 bg-gray-900/90 border border-gray-800 rounded-xl flex items-center justify-between gap-3 shadow hover:border-gray-700 transition-all"
                >
                  <div className="flex items-center gap-2.5">
                    <div className="w-10 h-10 rounded-lg bg-gray-950 border border-gray-700 flex items-center justify-center text-amber-400">
                      <Crown size={20} />
                    </div>
                    <div className="text-right">
                      <div className="font-bold text-xs text-white">{prod.nameAr}</div>
                      <div className="text-[11px] text-gray-400">{prod.descriptionAr}</div>
                    </div>
                  </div>

                  {isEquipped ? (
                    <span className="bg-amber-950 text-amber-300 border border-amber-600 px-3 py-1.5 rounded-lg text-xs font-bold">
                      مجهز 👑
                    </span>
                  ) : isOwned ? (
                    <button
                      onClick={() => {
                        soundManager.playEquip();
                        onUpdatePlayerData((prev) => ({ ...prev, equippedTitle: titleName }));
                        showNotification(`تم تجهيز اللقب "${titleName}"!`);
                      }}
                      className="py-1.5 px-3 bg-cyan-700 hover:bg-cyan-600 active:scale-95 text-white rounded-lg text-xs font-bold transition-all"
                    >
                      تجهيز
                    </button>
                  ) : (
                    <button
                      onClick={() => handleBuyProduct(prod)}
                      disabled={!affordable}
                      className={`py-1.5 px-3 rounded-lg font-pixel text-xs font-bold flex items-center gap-1.5 shrink-0 transition-all active:scale-95 ${
                        affordable
                          ? 'bg-amber-600 hover:bg-amber-500 text-white shadow-md'
                          : 'bg-gray-800/80 text-gray-500 border border-gray-700 cursor-not-allowed opacity-60'
                      }`}
                    >
                      <Coins size={12} />
                      <span>{prod.price}</span>
                    </button>
                  )}
                </div>
              );
            })}
          </div>
        )}

        {/* TAB 4: DAILY REWARDS & DEALS */}
        {activeTab === 'DAILY' && (
          <div className="flex flex-col gap-3">
            {/* Daily Streak Card */}
            <div className="bg-gray-900 border-2 border-green-500/80 rounded-2xl p-4 flex flex-col gap-3 shadow-xl">
              <div className="flex items-center justify-between border-b border-gray-800 pb-2">
                <div className="text-right">
                  <div className="font-bold text-xs text-green-400 flex items-center gap-1">
                    <Gift size={15} />
                    <span>سلسلة المكافآت اليومية (7 أيام)</span>
                  </div>
                  <div className="text-[10px] text-gray-400">سجل الدخول يوميًا لتحصل على مكافآت تصاعدية!</div>
                </div>
                <div className="font-pixel text-xs text-amber-300 bg-black/60 px-2 py-1 rounded border border-gray-700">
                  سلسلة: {currentStreak} / 7
                </div>
              </div>

              {/* 7-Day Grid */}
              <div className="grid grid-cols-7 gap-1 text-center">
                {DAILY_STREAK_REWARDS.map((rew) => {
                  const dayNum = rew.day;
                  const isClaimedToday = (dayNum <= currentStreak && !canClaimDaily) || (dayNum < currentStreak);
                  const isCurrentTarget = dayNum === nextDayIndex + 1 && canClaimDaily;

                  return (
                    <div
                      key={dayNum}
                      className={`p-1.5 rounded-lg border flex flex-col items-center justify-center gap-1 ${
                        isClaimedToday
                          ? 'bg-green-950/60 border-green-600 text-green-300'
                          : isCurrentTarget
                          ? 'bg-amber-950/80 border-amber-400 text-amber-200 animate-pulse shadow-[0_0_8px_rgba(245,158,11,0.5)]'
                          : 'bg-gray-950 border-gray-800 text-gray-500'
                      }`}
                    >
                      <span className="font-pixel text-[9px]">يوم {dayNum}</span>
                      <div className="w-5 h-5 flex items-center justify-center text-[10px]">
                        {isClaimedToday ? '✅' : '🎁'}
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Claim Button */}
              <button
                onClick={handleClaimDailyReward}
                disabled={!canClaimDaily}
                className={`w-full py-2.5 rounded-lg font-bold text-xs flex items-center justify-center gap-2 transition-all active:scale-95 ${
                  canClaimDaily
                    ? 'bg-gradient-to-r from-green-600 to-emerald-500 hover:from-green-500 text-white shadow-lg shadow-green-900/40 animate-pulse'
                    : 'bg-gray-800 border border-gray-700 text-gray-500 cursor-not-allowed'
                }`}
              >
                <Gift size={16} />
                <span>{canClaimDaily ? 'استلم مكافأة اليوم الآن!' : 'تم استلام مكافأة اليوم (عُد غدًا)'}</span>
              </button>
            </div>

            {/* Boss Milestone Chest */}
            <div className="bg-gray-900/90 border border-amber-500/60 rounded-2xl p-4 flex items-center justify-between gap-3 shadow">
              <div className="text-right">
                <div className="font-bold text-xs text-amber-300 flex items-center gap-1.5">
                  <Trophy size={15} className="text-amber-400" />
                  <span>صندوق إنجاز الزعماء (200 🪙)</span>
                </div>
                <div className="text-[10px] text-gray-400">
                  يفتح مجانًا فور هزيمتك لأي زعيم في اللعبة!
                </div>
              </div>

              <button
                onClick={handleClaimMilestoneChest}
                disabled={playerData.dailyRewards.bossMilestoneClaimed || playerData.defeatedBosses.length === 0}
                className={`py-2 px-3 rounded-lg font-pixel text-xs font-bold transition-all active:scale-95 ${
                  !playerData.dailyRewards.bossMilestoneClaimed && playerData.defeatedBosses.length > 0
                    ? 'bg-amber-600 hover:bg-amber-500 text-white shadow-md'
                    : 'bg-gray-800 text-gray-600 cursor-not-allowed'
                }`}
              >
                {playerData.dailyRewards.bossMilestoneClaimed ? 'تم الاستلام' : 'افتح الصندوق'}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
