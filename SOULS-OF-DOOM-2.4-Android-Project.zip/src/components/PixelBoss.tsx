import React, { useEffect, useState } from 'react';
import { BossData } from '../types/game';

interface PixelBossProps {
  boss: BossData;
  currentHp: number;
  maxHp: number;
  currentPhase: number;
  isHit: boolean;
  isAttacking: boolean;
}

export const PixelBoss: React.FC<PixelBossProps> = ({
  boss,
  currentHp,
  maxHp,
  currentPhase,
  isHit,
  isAttacking,
}) => {
  const [frame, setFrame] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setFrame((prev) => (prev + 1) % 60);
    }, 50);
    return () => clearInterval(timer);
  }, []);

  const hpPercent = Math.max(0, (currentHp / maxHp) * 100);
  const floatOffset = Math.sin((frame * Math.PI) / 15) * 6;
  const breatheScale = 1 + Math.sin((frame * Math.PI) / 20) * 0.03;
  const wingFlap = Math.sin((frame * Math.PI) / 10) * 8;

  return (
    <div className="flex flex-col items-center justify-center relative w-full select-none">
      {/* Boss Health Bar */}
      <div className="w-full max-w-sm px-4 mb-2">
        <div className="flex items-center justify-between text-xs font-bold text-gray-300 mb-1">
          <span className="flex items-center gap-1.5">
            <span className="inline-block w-2.5 h-2.5 rounded-full" style={{ backgroundColor: boss.colorTheme }} />
            {boss.nameAr}
          </span>
          <span className="font-pixel text-[10px] tabular-nums text-gray-400">
            {currentHp} / {maxHp} HP
          </span>
        </div>
        <div className="w-full h-3 bg-gray-900 border-2 border-gray-600 rounded-sm overflow-hidden p-0.5">
          <div
            className="h-full transition-all duration-300 rounded-xs"
            style={{
              width: `${hpPercent}%`,
              backgroundColor: hpPercent < 30 ? '#ef4444' : boss.colorTheme,
              boxShadow: `0 0 10px ${boss.colorTheme}`,
            }}
          />
        </div>
      </div>

      {/* Boss Sprite Container */}
      <div
        className={`relative transition-transform duration-100 ${isHit ? 'animate-bounce brightness-200' : ''}`}
        style={{
          transform: `translateY(${floatOffset}px) scale(${breatheScale})`,
          filter: isHit ? 'drop-shadow(0 0 16px #ffffff)' : `drop-shadow(0 0 18px ${boss.colorTheme}66)`,
        }}
      >
        {/* Aura Ring in Phase 2 or Higher */}
        {currentPhase > 1 && (
          <div
            className="absolute inset-0 -m-4 rounded-full border-2 border-dashed opacity-60 animate-spin"
            style={{
              borderColor: boss.colorTheme,
              animationDuration: currentPhase === 3 ? '3s' : '6s',
            }}
          />
        )}

        {/* Boss 1: Dark Bones (الهيكل العظمي) */}
        {boss.id === 'boss_1' && (
          <svg width="120" height="120" viewBox="0 0 24 24" className="pixelated">
            <path d="M7 11 L17 11 L19 22 L5 22 Z" fill="#1e293b" />
            <path d="M8 12 L16 12 L17 21 L7 21 Z" fill="#0f172a" />
            <rect x="11" y="12" width="2" height="7" fill="#e2e8f0" />
            <rect x="9" y="14" width="6" height="1.5" fill="#e2e8f0" />
            <rect x="10" y="17" width="4" height="1.5" fill="#e2e8f0" />
            <rect x="8" y="4" width="8" height="7" fill="#f8fafc" />
            <rect x="9" y="11" width="6" height="2" fill="#f8fafc" />
            <rect x="7" y="6" width="1" height="3" fill="#f8fafc" />
            <rect x="16" y="6" width="1" height="3" fill="#f8fafc" />
            <rect x="9" y="6" width="2" height="3" fill="#000000" />
            <rect x="13" y="6" width="2" height="3" fill="#000000" />
            <rect x="9.5" y="6.5" width="1" height="1.5" fill={frame % 10 < 8 ? '#38bdf8' : '#ffffff'} />
            <rect x="13.5" y="6.5" width="1" height="1.5" fill={frame % 10 < 8 ? '#38bdf8' : '#ffffff'} />
            <rect x="10" y="11" width="1" height="1" fill="#000000" />
            <rect x="12" y="11" width="1" height="1" fill="#000000" />
            <rect x="14" y="11" width="1" height="1" fill="#000000" />
            <rect x="4" y="14" width="3" height="3" fill="#f8fafc" />
            <rect x="17" y="14" width="3" height="3" fill="#f8fafc" />
            {isAttacking && (
              <line x1="19" y1="13" x2="23" y2="9" stroke="#38bdf8" strokeWidth="1.5" />
            )}
          </svg>
        )}

        {/* Boss 2: Flame Witch (ساحرة اللهب) */}
        {boss.id === 'boss_2' && (
          <svg width="120" height="120" viewBox="0 0 24 24" className="pixelated">
            <path d="M6 13 L18 13 L21 23 L3 23 Z" fill="#581c87" />
            <path d="M8 14 L16 14 L18 22 L6 22 Z" fill="#3b0764" />
            <circle cx="4" cy={12 + Math.sin(frame * 0.2) * 3} r="1.5" fill="#c084fc" />
            <circle cx="20" cy={14 + Math.cos(frame * 0.2) * 3} r="1.5" fill="#f43f5e" />
            <rect x="9" y="8" width="6" height="5" fill="#fed7aa" />
            <rect x="10" y="9.5" width="1.5" height="1.5" fill="#c084fc" />
            <rect x="13" y="9.5" width="1.5" height="1.5" fill="#c084fc" />
            <polygon points="12,1 6,7 18,7" fill="#6b21a8" />
            <rect x="4" y="7" width="16" height="2" fill="#7e22ce" />
            <rect x="8" y="6" width="8" height="1.5" fill="#f43f5e" />
            <line x1="20" y1="6" x2="20" y2="22" stroke="#d97706" strokeWidth="1" />
            <circle cx="20" cy="5" r="2.5" fill={frame % 8 < 4 ? '#f43f5e' : '#c084fc'} />
          </svg>
        )}

        {/* Boss 3: Void Knight (فارس الفراغ) */}
        {boss.id === 'boss_3' && (
          <svg width="120" height="120" viewBox="0 0 24 24" className="pixelated">
            <rect x="7" y="10" width="10" height="9" fill="#1e293b" />
            <rect x="8" y="11" width="8" height="7" fill="#0f172a" />
            <rect x="5" y="9" width="3" height="4" fill="#334155" />
            <rect x="16" y="9" width="3" height="4" fill="#334155" />
            <rect x="8" y="19" width="3" height="4" fill="#1e293b" />
            <rect x="13" y="19" width="3" height="4" fill="#1e293b" />
            <rect x="7" y="3" width="10" height="7" fill="#334155" />
            <polygon points="6,3 8,1 9,3" fill="#0284c7" />
            <polygon points="18,3 16,1 15,3" fill="#0284c7" />
            <rect x="8" y="6" width="8" height="1.5" fill="#06b6d4" />
            <rect x="10" y="6.5" width="4" height="1" fill="#e0f2fe" />
            <line x1="3" y1="2" x2="3" y2="22" stroke="#0f172a" strokeWidth="2.5" />
            <line x1="3" y1="3" x2="3" y2="18" stroke="#06b6d4" strokeWidth="1.5" />
            <rect x="1" y="8" width="5" height="1.5" fill="#64748b" />
          </svg>
        )}

        {/* Boss 4: Time Warden (حارس الزمن) */}
        {boss.id === 'boss_4' && (
          <svg width="120" height="120" viewBox="0 0 24 24" className="pixelated">
            <path d="M7 10 L17 10 L19 23 L5 23 Z" fill="#78350f" />
            <path d="M8 11 L16 11 L17 22 L7 22 Z" fill="#451a03" />
            <circle cx="18" cy="14" r="3.5" fill="#f59e0b" stroke="#d97706" strokeWidth="0.8" />
            <line
              x1="18"
              y1="14"
              x2={18 + Math.cos(frame * 0.4) * 2}
              y2={14 + Math.sin(frame * 0.4) * 2}
              stroke="#451a03"
              strokeWidth="1"
            />
            <path d="M7 3 C7 1, 17 1, 17 3 L18 10 L6 10 Z" fill="#92400e" />
            <rect x="8" y="5" width="8" height="4" fill="#000000" />
            <circle cx="10" cy="7" r="1" fill="#f59e0b" />
            <circle cx="14" cy="7" r="1" fill="#06b6d4" />
            <circle
              cx="12"
              cy="6"
              r="7"
              fill="none"
              stroke="#f59e0b"
              strokeWidth="0.8"
              strokeDasharray="2,2"
              className="animate-spin"
            />
          </svg>
        )}

        {/* Boss 5: King of the Void (ملك العدم) */}
        {boss.id === 'boss_5' && (
          <svg width="130" height="130" viewBox="0 0 26 26" className="pixelated">
            <path d="M4 11 L22 11 L25 25 L1 25 Z" fill="#450a0a" />
            <path d="M6 12 L20 12 L22 24 L4 24 Z" fill="#18181b" />
            <polygon points="7,4 9,1 11,4 13,0 15,4 17,1 19,4" fill="#dc2626" />
            <rect x="7" y="4" width="12" height="2" fill="#ef4444" />
            <circle cx="13" cy="5" r="1" fill="#fef08a" />
            <rect x="8" y="6" width="10" height="7" fill="#09090b" />
            <rect x="9.5" y="8" width="2" height="2" fill="#ef4444" />
            <rect x="14.5" y="8" width="2" height="2" fill="#ef4444" />
            <rect x="10" y="8.5" width="1" height="1" fill="#ffffff" />
            <rect x="15" y="8.5" width="1" height="1" fill="#ffffff" />
            <polygon points="13,13 16,16 13,19 10,16" fill="#dc2626" />
            <rect x="2" y="12" width="4" height="6" fill="#18181b" />
            <rect x="20" y="12" width="4" height="6" fill="#18181b" />
            <rect x="2" y="18" width="3" height="3" fill="#ef4444" />
            <rect x="21" y="18" width="3" height="3" fill="#ef4444" />
          </svg>
        )}

        {/* Boss 6: Soul Reaper (حاصد الأرواح) - New in Update 2.0 */}
        {boss.id === 'boss_6' && (
          <svg width="130" height="130" viewBox="0 0 26 26" className="pixelated">
            {/* Ragged Reaper Cloak */}
            <path d="M6 10 L20 10 L23 25 L3 25 Z" fill="#2e1065" />
            <path d="M8 12 L18 12 L19 24 L7 24 Z" fill="#1e1b4b" />
            
            {/* Deep Hood */}
            <path d="M7 4 L19 4 L20 11 L6 11 Z" fill="#3b0764" />
            <polygon points="13,1 6,4 20,4" fill="#581c87" />
            {/* Black void face inside hood */}
            <rect x="8" y="6" width="10" height="5" fill="#050508" />
            {/* Glowing violet demonic eye */}
            <circle cx="11" cy="8.5" r="1.5" fill="#c084fc" />
            <circle cx="15" cy="8.5" r="1.5" fill="#a855f7" />
            <circle cx="11" cy="8.5" r="0.5" fill="#ffffff" />

            {/* Giant Crescent Purple Scythe */}
            <line x1="22" y1="2" x2="22" y2="24" stroke="#475569" strokeWidth="1.5" />
            {/* Curved Scythe Blade */}
            <path
              d="M22 3 Q14 1, 10 9 Q16 7, 22 11 Z"
              fill={frame % 8 < 4 ? '#c084fc' : '#a855f7'}
              stroke="#e9d5ff"
              strokeWidth="0.8"
            />
            {/* Floating souls around reaper */}
            <circle cx={4 + Math.sin(frame * 0.25) * 3} cy="12" r="1.5" fill="#c084fc" opacity="0.8" />
            <circle cx={24 + Math.cos(frame * 0.25) * 2} cy="16" r="1.5" fill="#818cf8" opacity="0.8" />
          </svg>
        )}

        {/* Boss 7: The Zero Dragon (التنين الصفري) - New in Update 2.0 */}
        {boss.id === 'boss_7' && (
          <svg width="140" height="140" viewBox="0 0 28 28" className="pixelated">
            {/* Electric Blue Wings Flapping */}
            <polygon
              points={`2,${10 - wingFlap} 10,8 10,18 2,${20 - wingFlap}`}
              fill="#0284c7"
              stroke="#38bdf8"
              strokeWidth="0.8"
            />
            <polygon
              points={`26,${10 - wingFlap} 18,8 18,18 26,${20 - wingFlap}`}
              fill="#0284c7"
              stroke="#38bdf8"
              strokeWidth="0.8"
            />

            {/* Dragon Obsidian Body */}
            <path d="M10 8 L18 8 L20 22 L8 22 Z" fill="#09090b" />
            <path d="M11 9 L17 9 L18 20 L10 20 Z" fill="#18181b" />

            {/* Glowing Cyan Chest Core */}
            <polygon points="14,12 17,15 14,18 11,15" fill={frame % 6 < 3 ? '#38bdf8' : '#e0f2fe'} />

            {/* Dragon Horned Head */}
            <polygon points="14,2 11,6 17,6" fill="#09090b" />
            <polygon points="9,2 11,5 10,6" fill="#38bdf8" />
            <polygon points="19,2 17,5 18,6" fill="#38bdf8" />
            <rect x="10" y="5" width="8" height="5" fill="#0f172a" />
            {/* Slit Electric Cyan Dragon Eyes */}
            <rect x="11.5" y="7" width="2" height="1.5" fill="#38bdf8" />
            <rect x="14.5" y="7" width="2" height="1.5" fill="#38bdf8" />

            {/* Draconic Lightning Sparks */}
            <line x1="6" y1="14" x2="4" y2="16" stroke="#38bdf8" strokeWidth="1" />
            <line x1="22" y1="14" x2="24" y2="16" stroke="#38bdf8" strokeWidth="1" />
          </svg>
        )}

        {/* Boss 8: Ancient Bone King (ملك العظام القديم) - UPDATE 2.2 */}
        {boss.id === 'boss_8' && (
          <svg width="150" height="150" viewBox="0 0 32 32" className="pixelated">
            {/* Royal Obsidian Mantle */}
            <path d="M6 14 L26 14 L28 30 L4 30 Z" fill="#090d16" />
            <path d="M7 15 L25 15 L26 29 L6 29 Z" fill="#0f172a" />
            {/* Gold Embroidered Mantle Trim */}
            <path d="M6 14 L10 30" stroke="#eab308" strokeWidth="0.8" fill="none" />
            <path d="M26 14 L22 30" stroke="#eab308" strokeWidth="0.8" fill="none" />

            {/* Skeletal Spine & Golden Bone Ribcage */}
            <rect x="15" y="16" width="2" height="10" fill="#f1f5f9" />
            <rect x="12" y="17" width="8" height="1.5" fill="#f8fafc" />
            <rect x="11" y="20" width="10" height="1.5" fill="#f8fafc" />
            <rect x="13" y="23" width="6" height="1.5" fill="#f8fafc" />

            {/* Glowing Deep Blue Heart Core inside Ribs */}
            <circle cx="16" cy="19" r="2.2" fill={frame % 8 < 4 ? '#38bdf8' : '#60a5fa'} />
            <circle cx="16" cy="19" r="1" fill="#ffffff" />

            {/* Massive Royal Skeletal Head */}
            <rect x="10" y="7" width="12" height="8" fill="#f8fafc" />
            <rect x="11" y="14" width="10" height="2" fill="#e2e8f0" />
            {/* Cheekbones */}
            <rect x="9" y="10" width="1.5" height="4" fill="#cbd5e1" />
            <rect x="21.5" y="10" width="1.5" height="4" fill="#cbd5e1" />

            {/* Deep Blue Glowing Eye Sockets */}
            <rect x="12" y="9" width="3" height="3" fill="#020617" />
            <rect x="17" y="9" width="3" height="3" fill="#020617" />
            <rect x="12.5" y="9.5" width="2" height="2" fill={frame % 10 < 8 ? '#38bdf8' : '#e0f2fe'} />
            <rect x="17.5" y="9.5" width="2" height="2" fill={frame % 10 < 8 ? '#38bdf8' : '#e0f2fe'} />

            {/* Skeletal Teeth */}
            <rect x="12" y="14" width="1" height="2" fill="#020617" />
            <rect x="14" y="14" width="1" height="2" fill="#020617" />
            <rect x="16" y="14" width="1" height="2" fill="#020617" />
            <rect x="18" y="14" width="1" height="2" fill="#020617" />

            {/* Cracked Golden Crown */}
            <polygon points="10,7 10,2 12,4 16,1 20,4 22,2 22,7" fill="#eab308" />
            <polygon points="11,7 11,3 12,4.5 16,2 20,4.5 21,3 21,7" fill="#facc15" />
            {/* Crown Jewel */}
            <rect x="15" y="4" width="2" height="2" fill="#38bdf8" />
            {/* Crack on Crown */}
            <polyline points="18,3 17,5 19,6" stroke="#451a03" strokeWidth="0.6" fill="none" />

            {/* Black Magical Staff in Right Hand */}
            <rect x="26" y="4" width="2" height="27" fill="#000000" />
            <rect x="25.5" y="6" width="3" height="2" fill="#eab308" />
            {/* Staff Headpiece: Skull & Glowing Crystal */}
            <rect x="25" y="2" width="4" height="4" fill="#1e293b" />
            <circle cx="27" cy="4" r="1.8" fill={frame % 6 < 3 ? '#38bdf8' : '#93c5fd'} />
            {/* Magical Sparks emitting from Staff */}
            {isAttacking && (
              <>
                <circle cx="27" cy="1" r="1" fill="#38bdf8" className="animate-ping" />
                <line x1="27" y1="2" x2="29" y2="0" stroke="#38bdf8" strokeWidth="0.8" />
                <line x1="27" y1="2" x2="24" y2="1" stroke="#eab308" strokeWidth="0.8" />
              </>
            )}

            {/* Left Skeletal Hand */}
            <rect x="4" y="18" width="3" height="3" fill="#f8fafc" />
            <rect x="3" y="19" width="1.5" height="1" fill="#cbd5e1" />

            {/* Orbiting Blue Bone Shards */}
            <circle cx={6 + Math.sin(frame * 0.2) * 3} cy="10" r="1.5" fill="#38bdf8" opacity="0.9" />
            <circle cx={24 + Math.cos(frame * 0.2) * 3} cy="22" r="1.5" fill="#eab308" opacity="0.8" />
          </svg>
        )}
      </div>

      {/* Boss Title Badge */}
      <div className="mt-1 flex items-center gap-1 bg-black/60 px-2 py-0.5 rounded border border-gray-700/60 text-[11px] text-gray-300">
        <span>{boss.titleAr}</span>
        <span className="text-gray-500">•</span>
        <span className="text-amber-400 font-semibold">مرحلة {currentPhase}</span>
      </div>
    </div>
  );
};
