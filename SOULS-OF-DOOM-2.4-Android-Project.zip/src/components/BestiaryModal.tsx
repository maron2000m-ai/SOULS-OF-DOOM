import React, { useState } from 'react';
import { BossData, PlayerSaveData } from '../types/game';
import { BOSSES } from '../data/bosses';
import { soundManager } from '../audio/soundManager';
import { ArrowRight, BookOpen, Swords, Lock, CheckCircle2, Star, Shield, Skull, Zap } from 'lucide-react';

interface BestiaryModalProps {
  playerData: PlayerSaveData;
  onSelectBoss: (boss: BossData) => void;
  onBackToMenu: () => void;
}

export const BestiaryModal: React.FC<BestiaryModalProps> = ({
  playerData,
  onSelectBoss,
  onBackToMenu,
}) => {
  const [selectedBossIndex, setSelectedBossIndex] = useState(0);

  const selectedBoss = BOSSES[selectedBossIndex];
  const isUnlocked = selectedBoss.number <= playerData.unlockedBossNumber;
  const isDefeated = playerData.defeatedBosses.includes(selectedBoss.id);
  const bossRecord = playerData.bossRecords[selectedBoss.id] || { wins: 0, losses: 0 };

  return (
    <div className="relative w-full h-full flex flex-col p-4 bg-gradient-to-b from-gray-950 via-black to-gray-950 overflow-y-auto select-none">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-gray-800 pb-3 mb-3">
        <button
          onClick={() => {
            soundManager.playSelect();
            onBackToMenu();
          }}
          className="flex items-center gap-1.5 text-xs text-gray-400 hover:text-white bg-gray-900 border border-gray-700 px-3 py-1.5 rounded active:scale-95 transition-all"
        >
          <ArrowRight size={16} />
          <span>الرئيسية</span>
        </button>

        <h2 className="text-base font-bold text-white flex items-center gap-2">
          <BookOpen size={18} className="text-purple-400" />
          <span>دفتر وسجل الزعماء (8 زعماء)</span>
        </h2>
      </div>

      <div className="max-w-md mx-auto w-full flex flex-col gap-3 pb-8">
        {/* Horizontal Boss Selector Thumbnails */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1">
          {BOSSES.map((boss, idx) => {
            const unlocked = boss.number <= playerData.unlockedBossNumber;
            const defeated = playerData.defeatedBosses.includes(boss.id);
            const isCurrent = idx === selectedBossIndex;

            return (
              <button
                key={boss.id}
                onClick={() => {
                  soundManager.playSelect();
                  setSelectedBossIndex(idx);
                }}
                className={`flex-shrink-0 px-3 py-2 rounded-xl border flex flex-col items-center gap-1 transition-all ${
                  isCurrent
                    ? 'border-purple-400 bg-purple-950/60 shadow-[0_0_10px_rgba(168,85,247,0.3)]'
                    : 'border-gray-800 bg-gray-900/60 opacity-70 hover:opacity-100'
                }`}
              >
                <div
                  className="w-7 h-7 rounded-lg flex items-center justify-center font-pixel text-xs font-bold"
                  style={{
                    backgroundColor: unlocked ? `${boss.colorTheme}33` : '#1f2937',
                    color: unlocked ? boss.colorTheme : '#6b7280',
                  }}
                >
                  {unlocked ? `#${boss.number}` : <Lock size={12} />}
                </div>
                <span className="text-[10px] font-semibold text-gray-300 truncate max-w-[65px]">
                  {unlocked ? boss.nameAr : '؟؟؟؟'}
                </span>
              </button>
            );
          })}
        </div>

        {/* Selected Boss Detailed Dossier */}
        <div className="bg-gray-900/90 border-2 border-gray-800 rounded-2xl p-4 flex flex-col gap-3 shadow-xl text-right">
          {/* Header of Dossier */}
          <div className="flex items-start justify-between border-b border-gray-800 pb-3">
            <div className="flex items-center gap-2">
              <div
                className="w-12 h-12 rounded-xl border-2 flex items-center justify-center"
                style={{
                  borderColor: isUnlocked ? selectedBoss.colorTheme : '#374151',
                  backgroundColor: isUnlocked ? `${selectedBoss.colorTheme}22` : '#111827',
                }}
              >
                {isUnlocked ? (
                  <Skull size={24} style={{ color: selectedBoss.colorTheme }} />
                ) : (
                  <Lock size={20} className="text-gray-600" />
                )}
              </div>
              <div className="text-right">
                <h3 className="font-bold text-sm text-white flex items-center gap-1.5">
                  {isUnlocked ? selectedBoss.nameAr : 'زعيم غامض في الظلام'}
                  {isDefeated && <CheckCircle2 size={16} className="text-amber-400" />}
                </h3>
                <div className="text-[11px] text-gray-400">
                  {isUnlocked ? selectedBoss.titleAr : 'مغلق حتى تهزم الزعيم السابق'}
                </div>
              </div>
            </div>

            {/* Status Badge */}
            <div>
              {isDefeated ? (
                <span className="bg-amber-950 text-amber-300 border border-amber-600 px-2 py-0.5 rounded text-[11px] font-semibold">
                  مهـزوم 🏆
                </span>
              ) : isUnlocked ? (
                <span className="bg-cyan-950 text-cyan-300 border border-cyan-500 px-2 py-0.5 rounded text-[11px] font-semibold animate-pulse">
                  متـاح
                </span>
              ) : (
                <span className="bg-gray-800 text-gray-500 border border-gray-700 px-2 py-0.5 rounded text-[11px] flex items-center gap-1">
                  <Lock size={12} />
                  مغـلق
                </span>
              )}
            </div>
          </div>

          {/* Lore & Description */}
          <p className="text-xs text-gray-300 leading-relaxed">
            {isUnlocked
              ? selectedBoss.descriptionAr
              : 'لم تتم مواجهة هذا الكيان المظلم بعد. اهزم الزعماء السابقين لإزاحة الستار عن أسراره وهجماته.'}
          </p>

          {/* Difficulty & Stats */}
          {isUnlocked && (
            <div className="grid grid-cols-2 gap-2 text-[11px]">
              <div className="p-2 bg-gray-950 rounded border border-gray-800 flex items-center justify-between">
                <span className="text-gray-400">مستوى الصعوبة:</span>
                <div className="flex items-center gap-0.5">
                  {Array.from({ length: 7 }).map((_, i) => (
                    <Star
                      key={i}
                      size={11}
                      className={
                        i < selectedBoss.number
                          ? 'text-amber-400 fill-amber-400'
                          : 'text-gray-700'
                      }
                    />
                  ))}
                </div>
              </div>

              <div className="p-2 bg-gray-950 rounded border border-gray-800 flex items-center justify-between">
                <span className="text-gray-400">سجل النزالات:</span>
                <span className="font-pixel text-[10px] text-cyan-300">
                  {bossRecord.wins} فوز / {bossRecord.losses} هزيمة
                </span>
              </div>
            </div>
          )}

          {/* Discovered Attack Patterns */}
          {isUnlocked && (
            <div className="bg-gray-950/70 p-3 rounded-xl border border-gray-800/80 flex flex-col gap-1.5">
              <span className="text-[11px] font-bold text-purple-400 flex items-center gap-1">
                <Zap size={13} />
                <span>أنماط الهجوم المكتشفة:</span>
              </span>
              <ul className="text-[11px] text-gray-300 space-y-1 pr-2 list-disc list-inside">
                {selectedBoss.checkInfo.discoveredPatterns.map((pat, idx) => (
                  <li key={idx}>{pat}</li>
                ))}
              </ul>
            </div>
          )}

          {/* Action: Fight this Boss */}
          {isUnlocked ? (
            <button
              onClick={() => {
                soundManager.playSelect();
                onSelectBoss(selectedBoss);
              }}
              className="w-full py-2.5 bg-red-600 hover:bg-red-500 active:scale-95 text-white font-bold rounded-lg shadow-lg flex items-center justify-center gap-2 text-xs transition-all mt-1"
            >
              <Swords size={16} />
              <span>{isDefeated ? 'إعادة التحدي' : 'بـدء المعركـة الآن'}</span>
            </button>
          ) : (
            <div className="w-full py-2 bg-gray-800 text-gray-500 rounded text-center text-xs flex items-center justify-center gap-1.5">
              <Lock size={14} />
              <span>اهزم الزعيم السابق لفتح هذا الملف والمعركة</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
