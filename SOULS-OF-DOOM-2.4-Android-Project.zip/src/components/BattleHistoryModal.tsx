import React from 'react';
import { PlayerSaveData } from '../types/game';
import { BOSSES } from '../data/bosses';
import { soundManager } from '../audio/soundManager';
import { ArrowRight, History, Trophy, Skull, Clock, Sparkles, Shield, Flame } from 'lucide-react';

interface BattleHistoryModalProps {
  playerData: PlayerSaveData;
  onBackToMenu: () => void;
}

export const BattleHistoryModal: React.FC<BattleHistoryModalProps> = ({ playerData, onBackToMenu }) => {
  return (
    <div className="relative w-full h-full flex flex-col p-4 bg-gradient-to-b from-gray-950 via-black to-gray-950 overflow-y-auto select-none">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-gray-800 pb-3 mb-3">
        <button
          onClick={() => {
            soundManager.playSelect();
            onBackToMenu();
          }}
          className="flex items-center gap-1.5 text-xs text-gray-400 hover:text-white bg-gray-900 border border-gray-700 px-3 py-1.5 rounded active:scale-95 transition-all"
        >
          <ArrowRight size={16} />
          <span>الرئيسية</span>
        </button>

        <h2 className="text-base font-bold text-white flex items-center gap-2">
          <History size={18} className="text-cyan-400" />
          <span>سجل المعارك — روحك تتذكر</span>
        </h2>
      </div>

      <div className="max-w-md mx-auto w-full flex flex-col gap-3 pb-8 text-right text-xs">
        <div className="p-2.5 bg-gray-900/80 border border-gray-800 rounded-xl text-gray-400 text-[11px] leading-relaxed">
          📜 يسجل هذا السجل تاريخ نزال روحك الفعلي ضد كل زعيم من زعماء الظلام السبعة، وإحصائيات الثبات وسرعة الحسم.
        </div>

        {/* Boss History Cards */}
        {BOSSES.map((boss) => {
          const entry = playerData.battleHistory[boss.id] || {
            bossId: boss.id,
            bossNameAr: boss.nameAr,
            encounters: 0,
            wins: 0,
            losses: 0,
            lastResult: 'NONE',
            lastDurationSeconds: 0,
            lastItemsUsed: 0,
            winStreak: 0,
          };

          const isUnlocked = boss.number <= playerData.unlockedBossNumber;

          return (
            <div
              key={boss.id}
              className={`p-3.5 rounded-2xl border transition-all flex flex-col gap-2.5 ${
                isUnlocked
                  ? 'bg-gray-900/90 border-gray-800 shadow-md'
                  : 'bg-gray-950/60 border-gray-900 opacity-50'
              }`}
            >
              {/* Header */}
              <div className="flex items-center justify-between border-b border-gray-800/80 pb-2">
                <div className="flex items-center gap-2">
                  <div
                    className="w-8 h-8 rounded-lg flex items-center justify-center font-pixel text-xs font-bold"
                    style={{
                      backgroundColor: `${boss.colorTheme}22`,
                      color: boss.colorTheme,
                      border: `1px solid ${boss.colorTheme}66`,
                    }}
                  >
                    #{boss.number}
                  </div>
                  <div>
                    <h3 className="font-bold text-white text-xs">{boss.nameAr}</h3>
                    <div className="text-[10px] text-gray-500">{boss.titleAr}</div>
                  </div>
                </div>

                {/* Last Result Badge */}
                <div>
                  {entry.lastResult === 'VICTORY' ? (
                    <span className="bg-green-950 text-green-300 border border-green-600 px-2 py-0.5 rounded text-[10px] font-bold">
                      آخر نتيجة: انتصار 🏆
                    </span>
                  ) : entry.lastResult === 'DEFEAT' ? (
                    <span className="bg-red-950 text-red-300 border border-red-600 px-2 py-0.5 rounded text-[10px] font-bold">
                      آخر نتيجة: هزيمة 💀
                    </span>
                  ) : (
                    <span className="bg-gray-950 text-gray-500 border border-gray-800 px-2 py-0.5 rounded text-[10px]">
                      لم تتم المواجهة بعد
                    </span>
                  )}
                </div>
              </div>

              {/* Stats Grid */}
              <div className="grid grid-cols-4 gap-1.5 text-center">
                <div className="bg-gray-950 p-2 rounded-lg border border-gray-800">
                  <span className="text-[10px] text-gray-400 block">المواجهات</span>
                  <span className="font-pixel text-xs text-white">{entry.encounters}</span>
                </div>

                <div className="bg-gray-950 p-2 rounded-lg border border-gray-800">
                  <span className="text-[10px] text-gray-400 block">انتصارات</span>
                  <span className="font-pixel text-xs text-green-400">{entry.wins}</span>
                </div>

                <div className="bg-gray-950 p-2 rounded-lg border border-gray-800">
                  <span className="text-[10px] text-gray-400 block">هزائم</span>
                  <span className="font-pixel text-xs text-red-400">{entry.losses}</span>
                </div>

                <div className="bg-gray-950 p-2 rounded-lg border border-gray-800">
                  <span className="text-[10px] text-gray-400 block">سلسلة فوز</span>
                  <span className="font-pixel text-xs text-amber-400">x{entry.winStreak}</span>
                </div>
              </div>

              {/* Last Match Metadata */}
              {entry.encounters > 0 && (
                <div className="bg-gray-950/60 p-2 rounded-lg border border-gray-800/80 flex items-center justify-between text-[10px] text-gray-400">
                  <span className="flex items-center gap-1">
                    <Clock size={12} className="text-cyan-400" />
                    <span>مدة آخر نزال: {entry.lastDurationSeconds} ث</span>
                  </span>

                  <span className="flex items-center gap-1">
                    <Shield size={12} className="text-purple-400" />
                    <span>أدوات مستخدمة: {entry.lastItemsUsed}</span>
                  </span>

                  {entry.lastVictoryDate && (
                    <span className="text-gray-500 font-pixel text-[9px]">
                      {entry.lastVictoryDate}
                    </span>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
