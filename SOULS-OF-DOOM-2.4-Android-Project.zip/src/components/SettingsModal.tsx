import React, { useState } from 'react';
import { GameSettings, Difficulty, DpadSize, HeartScale, UiScale, PlayerSaveData } from '../types/game';
import { soundManager } from '../audio/soundManager';
import { exportSaveBackup, importSaveBackup } from '../utils/storage';
import {
  ArrowRight,
  Music,
  Sliders,
  Smartphone,
  AlertTriangle,
  Monitor,
  Maximize2,
  Minimize2,
  Trash2,
  Download,
  Upload,
  RotateCcw,
  Vibrate,
  Zap,
  Activity,
} from 'lucide-react';

interface SettingsModalProps {
  settings: GameSettings;
  playerData: PlayerSaveData;
  onUpdateSettings: (newSettings: GameSettings) => void;
  onUpdatePlayerData: (updater: (prev: PlayerSaveData) => PlayerSaveData) => void;
  onResetProgress: () => void;
  onBackToMenu: () => void;
  onOpenAndroidPackage?: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  settings,
  playerData,
  onUpdateSettings,
  onUpdatePlayerData,
  onResetProgress,
  onBackToMenu,
  onOpenAndroidPackage,
}) => {
  const [activeTab, setActiveTab] = useState<'PERFORMANCE' | 'DISPLAY' | 'CONTROLS' | 'AUDIO' | 'BACKUP'>('PERFORMANCE');
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  const [backupNotice, setBackupNotice] = useState<string | null>(null);

  // Apply Performance Preset
  const handleSelectPreset = (preset: 'SAVER' | 'BALANCED' | 'QUALITY') => {
    soundManager.playSelect();
    if (preset === 'SAVER') {
      onUpdateSettings({
        ...settings,
        performancePreset: 'SAVER',
        targetFps: 30,
        reduceParticles: true,
        reduceBloom: true,
        shadowQuality: 'OFF',
        animatedBackground: false,
      });
      setBackupNotice('تم تفعيل وضع توفير الطاقة وتثبيت 30 إطار/ثانية!');
    } else if (preset === 'BALANCED') {
      onUpdateSettings({
        ...settings,
        performancePreset: 'BALANCED',
        targetFps: 60,
        reduceParticles: false,
        reduceBloom: false,
        shadowQuality: 'LOW',
        animatedBackground: true,
      });
      setBackupNotice('تم تفعيل الوضع المتوازن (60 إطار/ثانية وسلاسة متكاملة)!');
    } else {
      onUpdateSettings({
        ...settings,
        performancePreset: 'QUALITY',
        targetFps: 60,
        reduceParticles: false,
        reduceBloom: false,
        shadowQuality: 'HIGH',
        animatedBackground: true,
      });
      setBackupNotice('تم تفعيل وضع الجودة الفائقة والمؤثرات الكاملة!');
    }
    setTimeout(() => setBackupNotice(null), 2500);
  };

  // Toggle Fullscreen API
  const handleToggleFullscreen = () => {
    soundManager.playSelect();
    try {
      if (!document.fullscreenElement) {
        document.documentElement.requestFullscreen().catch(() => {});
        onUpdateSettings({ ...settings, isFullscreen: true });
      } else {
        document.exitFullscreen().catch(() => {});
        onUpdateSettings({ ...settings, isFullscreen: false });
      }
    } catch {
      onUpdateSettings({ ...settings, isFullscreen: !settings.isFullscreen });
    }
  };

  const handleResetDisplayDefaults = () => {
    soundManager.playSelect();
    onUpdateSettings({
      ...settings,
      gameScale: 1.0,
      arenaScale: 1.0,
      heartScale: 'LARGE',
      zenMode: false,
      uiScale: 'NORMAL',
      autoFit: true,
    });
    setBackupNotice('تمت استعادة إعدادات العرض الافتراضية بنجاح!');
    setTimeout(() => setBackupNotice(null), 2000);
  };

  const handleExportBackup = () => {
    soundManager.playSelect();
    const jsonStr = exportSaveBackup(playerData);
    navigator.clipboard?.writeText(jsonStr);
    setBackupNotice('تم نسخ بيانات الحفظ الاحتياطية إلى الحافظة!');
    setTimeout(() => setBackupNotice(null), 2500);
  };

  const handleImportBackup = () => {
    const raw = prompt('الصق نص النسخة الاحتياطية هنا:');
    if (raw) {
      const imported = importSaveBackup(raw);
      if (imported) {
        onUpdatePlayerData(() => imported);
        soundManager.playVictory();
        setBackupNotice('تم استيراد بيانات الحفظ بنجاح!');
      } else {
        soundManager.playDamage();
        setBackupNotice('فشل استيراد البيانات، تأكد من صحة النص!');
      }
      setTimeout(() => setBackupNotice(null), 2500);
    }
  };

  return (
    <div className="relative w-full h-full flex flex-col p-4 bg-gradient-to-b from-gray-950 via-black to-gray-950 overflow-y-auto select-none">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-gray-800 pb-3 mb-3">
        <button
          onClick={() => {
            soundManager.playSelect();
            onBackToMenu();
          }}
          className="flex items-center gap-1.5 text-xs text-gray-400 hover:text-white bg-gray-900 border border-gray-700 px-3 py-1.5 rounded active:scale-95 transition-all"
        >
          <ArrowRight size={16} />
          <span>الرئيسية</span>
        </button>

        <h2 className="text-base font-bold text-white flex items-center gap-2">
          <Sliders size={18} className="text-cyan-400" />
          <span>إعدادات اللعبة 2.2</span>
        </h2>
      </div>

      {backupNotice && (
        <div className="sticky top-0 z-30 mb-2 py-1.5 px-3 bg-cyan-900/90 border border-cyan-400 text-cyan-100 rounded text-center text-xs font-semibold animate-pulse shadow-lg">
          {backupNotice}
        </div>
      )}

      {/* UPDATE 2.2 Android Packaging Quick Hub */}
      {onOpenAndroidPackage && (
        <div className="max-w-md mx-auto w-full mb-3 p-2.5 rounded-lg bg-gradient-to-r from-emerald-950/80 via-teal-900/60 to-emerald-950/80 border border-emerald-500/80 flex items-center justify-between shadow">
          <div className="flex items-center gap-2">
            <Smartphone size={16} className="text-emerald-400" />
            <div>
              <div className="text-xs font-bold text-emerald-200">تطبيق Android و WebAPK</div>
              <div className="text-[10px] text-emerald-400/80">فحص وتثبيت فوري بدون متجر أو تنزيل حزمة</div>
            </div>
          </div>
          <button
            onClick={() => {
              soundManager.playSelect();
              onOpenAndroidPackage();
            }}
            className="px-2.5 py-1 bg-emerald-500 hover:bg-emerald-400 text-black text-xs font-bold rounded shadow active:scale-95 transition-all"
          >
            تجهيز وتثبيت 📱
          </button>
        </div>
      )}

      {/* Settings Navigation Tabs */}
      <div className="flex flex-wrap gap-1.5 mb-3 max-w-md mx-auto w-full">
        <button
          onClick={() => {
            soundManager.playSelect();
            setActiveTab('PERFORMANCE');
          }}
          className={`flex-1 min-w-[70px] py-1.5 px-1 rounded-lg text-[10px] sm:text-[11px] font-bold border transition-all ${
            activeTab === 'PERFORMANCE'
              ? 'bg-emerald-950 border-emerald-500 text-emerald-200'
              : 'bg-gray-900/60 border-gray-800 text-gray-400'
          }`}
        >
          الأداء والسلاسة ⚡
        </button>

        <button
          onClick={() => {
            soundManager.playSelect();
            setActiveTab('DISPLAY');
          }}
          className={`flex-1 min-w-[70px] py-1.5 px-1 rounded-lg text-[10px] sm:text-[11px] font-bold border transition-all ${
            activeTab === 'DISPLAY'
              ? 'bg-cyan-950 border-cyan-500 text-cyan-200'
              : 'bg-gray-900/60 border-gray-800 text-gray-400'
          }`}
        >
          الشاشة 🖥️
        </button>

        <button
          onClick={() => {
            soundManager.playSelect();
            setActiveTab('CONTROLS');
          }}
          className={`flex-1 min-w-[70px] py-1.5 px-1 rounded-lg text-[10px] sm:text-[11px] font-bold border transition-all ${
            activeTab === 'CONTROLS'
              ? 'bg-purple-950 border-purple-500 text-purple-200'
              : 'bg-gray-900/60 border-gray-800 text-gray-400'
          }`}
        >
          التحكم 🕹️
        </button>

        <button
          onClick={() => {
            soundManager.playSelect();
            setActiveTab('AUDIO');
          }}
          className={`flex-1 min-w-[70px] py-1.5 px-1 rounded-lg text-[10px] sm:text-[11px] font-bold border transition-all ${
            activeTab === 'AUDIO'
              ? 'bg-amber-950 border-amber-500 text-amber-200'
              : 'bg-gray-900/60 border-gray-800 text-gray-400'
          }`}
        >
          الصوت والصعوبة 🔊
        </button>

        <button
          onClick={() => {
            soundManager.playSelect();
            setActiveTab('BACKUP');
          }}
          className={`flex-1 min-w-[70px] py-1.5 px-1 rounded-lg text-[10px] sm:text-[11px] font-bold border transition-all ${
            activeTab === 'BACKUP'
              ? 'bg-red-950 border-red-500 text-red-200'
              : 'bg-gray-900/60 border-gray-800 text-gray-400'
          }`}
        >
          النسخ 💾
        </button>
      </div>

      {/* Main Settings Body */}
      <div className="max-w-md mx-auto w-full flex flex-col gap-3.5 pb-8 text-right text-xs">
        {/* TAB 0: PERFORMANCE & SMOOTHNESS (الأداء والسلاسة - New in Update 2.1) */}
        {activeTab === 'PERFORMANCE' && (
          <div className="bg-gray-900/80 border border-gray-800 rounded-xl p-3.5 flex flex-col gap-3">
            <div className="font-bold text-sm text-emerald-400 flex items-center gap-1.5 border-b border-gray-800 pb-1.5">
              <Zap size={16} />
              <span>قسم الأداء والسلاسة ومكافحة التقطيع</span>
            </div>

            {/* Presets */}
            <div className="flex flex-col gap-1.5">
              <span className="text-gray-300 font-semibold">أوضاع الأداء الجاهزة (Presets):</span>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { id: 'SAVER', label: 'توفير الطاقة 🔋', desc: '30 FPS / خفيف' },
                  { id: 'BALANCED', label: 'متوازن ⚖️', desc: '60 FPS / مستقر' },
                  { id: 'QUALITY', label: 'جودة فائقة ✨', desc: '60 FPS / كامل' },
                ].map((p) => (
                  <button
                    key={p.id}
                    onClick={() => handleSelectPreset(p.id as 'SAVER' | 'BALANCED' | 'QUALITY')}
                    className={`py-2 px-1 rounded-lg border text-center transition-all ${
                      settings.performancePreset === p.id
                        ? 'bg-emerald-950 border-emerald-500 text-emerald-200 shadow-md ring-1 ring-emerald-400'
                        : 'bg-gray-800/80 border-gray-700 text-gray-400 hover:text-white'
                    }`}
                  >
                    <div className="font-bold text-[11px]">{p.label}</div>
                    <div className="text-[9px] text-gray-400">{p.desc}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* Target FPS Selector */}
            <div className="flex items-center justify-between pt-2 border-t border-gray-800/60">
              <div>
                <span className="text-gray-300 block font-semibold">معدل الإطارات المستهدف (Target FPS):</span>
                <span className="text-[10px] text-gray-500">اختر 30 إطار للهواتف الضعيفة لتوفير البطارية</span>
              </div>
              <div className="flex gap-1.5">
                {[30, 60].map((fps) => (
                  <button
                    key={fps}
                    onClick={() => {
                      soundManager.playSelect();
                      onUpdateSettings({ ...settings, targetFps: fps as 30 | 60 });
                    }}
                    className={`px-3 py-1 rounded text-xs font-bold border transition-all ${
                      settings.targetFps === fps
                        ? 'bg-emerald-950 border-emerald-500 text-emerald-200'
                        : 'bg-gray-800 border-gray-700 text-gray-400'
                    }`}
                  >
                    {fps} FPS
                  </button>
                ))}
              </div>
            </div>

            {/* Reduce Particles Toggle */}
            <div className="flex items-center justify-between pt-2 border-t border-gray-800/60">
              <div>
                <span className="text-gray-300 block font-semibold">تقليل الجزيئات والمقذوفات:</span>
                <span className="text-[10px] text-gray-500">يخفف الضغط على المعالج أثناء الهجمات الكثيفة</span>
              </div>
              <button
                onClick={() => {
                  soundManager.playSelect();
                  onUpdateSettings({ ...settings, reduceParticles: !settings.reduceParticles });
                }}
                className={`py-1 px-3 rounded text-[11px] font-bold border transition-all ${
                  settings.reduceParticles
                    ? 'bg-emerald-950 border-emerald-500 text-emerald-200'
                    : 'bg-gray-800 border-gray-700 text-gray-400'
                }`}
              >
                {settings.reduceParticles ? 'مفعل' : 'معطل'}
              </button>
            </div>

            {/* Reduce Glow & Bloom */}
            <div className="flex items-center justify-between pt-2 border-t border-gray-800/60">
              <div>
                <span className="text-gray-300 block font-semibold">تقليل التوهج والإضاءة (Bloom):</span>
                <span className="text-[10px] text-gray-500">إلغاء التظليل الثقيل على كرت الشاشة</span>
              </div>
              <button
                onClick={() => {
                  soundManager.playSelect();
                  onUpdateSettings({ ...settings, reduceBloom: !settings.reduceBloom });
                }}
                className={`py-1 px-3 rounded text-[11px] font-bold border transition-all ${
                  settings.reduceBloom
                    ? 'bg-emerald-950 border-emerald-500 text-emerald-200'
                    : 'bg-gray-800 border-gray-700 text-gray-400'
                }`}
              >
                {settings.reduceBloom ? 'مفعل' : 'معطل'}
              </button>
            </div>

            {/* Shadow Quality */}
            <div className="flex flex-col gap-1.5 pt-2 border-t border-gray-800/60">
              <span className="text-gray-300 font-semibold">جودة الظلال الميدانية:</span>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { id: 'OFF', label: 'معطلة (أقصى سرعة)' },
                  { id: 'LOW', label: 'منخفضة' },
                  { id: 'HIGH', label: 'عالية' },
                ].map((sq) => (
                  <button
                    key={sq.id}
                    onClick={() => {
                      soundManager.playSelect();
                      onUpdateSettings({ ...settings, shadowQuality: sq.id as 'OFF' | 'LOW' | 'HIGH' });
                    }}
                    className={`py-1.5 rounded-lg border text-[11px] font-bold ${
                      settings.shadowQuality === sq.id
                        ? 'bg-emerald-950 border-emerald-500 text-emerald-200'
                        : 'bg-gray-800 border-gray-700 text-gray-400'
                    }`}
                  >
                    {sq.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Animated Background */}
            <div className="flex items-center justify-between pt-2 border-t border-gray-800/60">
              <div>
                <span className="text-gray-300 block font-semibold">خلفيات البكسل المتحركة:</span>
                <span className="text-[10px] text-gray-500">إيقافها يوفر طاقة المعالج بشكل ملحوظ</span>
              </div>
              <button
                onClick={() => {
                  soundManager.playSelect();
                  onUpdateSettings({ ...settings, animatedBackground: !settings.animatedBackground });
                }}
                className={`py-1 px-3 rounded text-[11px] font-bold border transition-all ${
                  settings.animatedBackground
                    ? 'bg-emerald-950 border-emerald-500 text-emerald-200'
                    : 'bg-gray-800 border-gray-700 text-gray-400'
                }`}
              >
                {settings.animatedBackground ? 'مفعلة' : 'معطلة'}
              </button>
            </div>

            {/* Performance HUD (FPS / Frame Time / Objects Diagnostic) */}
            <div className="flex items-center justify-between pt-2 border-t border-gray-800/60">
              <div className="flex items-center gap-1.5">
                <Activity size={15} className="text-emerald-400" />
                <div>
                  <span className="text-gray-300 block font-semibold">مؤشر تشخيص الأداء المباشر (HUD):</span>
                  <span className="text-[10px] text-gray-500">يعرض معدل FPS وزمن المعالجة وعدد المقذوفات</span>
                </div>
              </div>
              <button
                onClick={() => {
                  soundManager.playSelect();
                  onUpdateSettings({ ...settings, showPerfHud: !settings.showPerfHud });
                }}
                className={`py-1 px-3 rounded text-[11px] font-bold border transition-all ${
                  settings.showPerfHud
                    ? 'bg-emerald-950 border-emerald-500 text-emerald-200'
                    : 'bg-gray-800 border-gray-700 text-gray-400'
                }`}
              >
                {settings.showPerfHud ? 'ظاهر' : 'مخفي'}
              </button>
            </div>
          </div>
        )}
        {/* TAB 1: DISPLAY & SCREEN (العرض والشاشة - New in Update 2.0) */}
        {activeTab === 'DISPLAY' && (
          <div className="bg-gray-900/80 border border-gray-800 rounded-xl p-3.5 flex flex-col gap-3">
            <div className="font-bold text-sm text-cyan-400 flex items-center gap-1.5 border-b border-gray-800 pb-1.5">
              <Monitor size={16} />
              <span>قسم العرض وتكبير الشاشة</span>
            </div>

            {/* 1. Fullscreen Button */}
            <div className="flex items-center justify-between">
              <span className="text-gray-300">وضع ملء الشاشة (Fullscreen):</span>
              <button
                onClick={handleToggleFullscreen}
                className="py-1 px-3 bg-cyan-900/70 hover:bg-cyan-800 active:scale-95 border border-cyan-500 rounded text-cyan-200 text-xs font-bold flex items-center gap-1.5"
              >
                {settings.isFullscreen ? <Minimize2 size={14} /> : <Maximize2 size={14} />}
                <span>{settings.isFullscreen ? 'تصغير' : 'ملء الشاشة'}</span>
              </button>
            </div>

            {/* 2. Combat Arena Zoom Scale */}
            <div className="flex flex-col gap-1.5 pt-2 border-t border-gray-800/60">
              <span className="text-gray-300">تكبير ساحة القتال (Arena Zoom):</span>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { scale: 1.0, label: '1.0x (افتراضي)' },
                  { scale: 1.15, label: '1.15x (متوسط)' },
                  { scale: 1.25, label: '1.25x (مكبر)' },
                ].map((item) => (
                  <button
                    key={item.scale}
                    onClick={() => {
                      soundManager.playSelect();
                      onUpdateSettings({ ...settings, arenaScale: item.scale });
                    }}
                    className={`py-1.5 rounded-lg border text-[11px] font-bold ${
                      settings.arenaScale === item.scale
                        ? 'bg-cyan-950 border-cyan-500 text-cyan-200'
                        : 'bg-gray-800 border-gray-700 text-gray-400'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>

            {/* 3. Player Character & Heart Zoom */}
            <div className="flex flex-col gap-1.5 pt-2 border-t border-gray-800/60">
              <span className="text-gray-300">حجم شخصية القلب (Heart Size):</span>
              <div className="grid grid-cols-3 gap-2">
                {(['NORMAL', 'LARGE', 'XLARGE'] as HeartScale[]).map((scale) => {
                  const label = scale === 'NORMAL' ? 'عادي' : scale === 'LARGE' ? 'كبير (واضح)' : 'كبير جدًا';
                  return (
                    <button
                      key={scale}
                      onClick={() => {
                        soundManager.playSelect();
                        onUpdateSettings({ ...settings, heartScale: scale });
                      }}
                      className={`py-1.5 rounded-lg border text-[11px] font-bold ${
                        settings.heartScale === scale
                          ? 'bg-cyan-950 border-cyan-500 text-cyan-200'
                          : 'bg-gray-800 border-gray-700 text-gray-400'
                      }`}
                    >
                      {label}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* 4. Zen Mode: Hide Non-Essential UI during Combat */}
            <div className="flex items-center justify-between pt-2 border-t border-gray-800/60">
              <div>
                <span className="text-gray-300 block font-semibold">إخفاء العناصر غير الضرورية أثناء القتال:</span>
                <span className="text-[10px] text-gray-500">لتركيز كامل وسلاسة رؤية المقذوفات</span>
              </div>
              <button
                onClick={() => {
                  soundManager.playSelect();
                  onUpdateSettings({ ...settings, zenMode: !settings.zenMode });
                }}
                className={`py-1 px-3 rounded text-[11px] font-bold border transition-all ${
                  settings.zenMode
                    ? 'bg-cyan-950 border-cyan-500 text-cyan-200'
                    : 'bg-gray-800 border-gray-700 text-gray-400'
                }`}
              >
                {settings.zenMode ? 'مفعل' : 'معطل'}
              </button>
            </div>

            {/* 5. Reset Display Settings to Default */}
            <button
              onClick={handleResetDisplayDefaults}
              className="mt-2 py-2 bg-gray-800 hover:bg-gray-700 active:scale-95 border border-gray-700 rounded-lg text-gray-300 font-semibold text-xs flex items-center justify-center gap-1.5 transition-all"
            >
              <RotateCcw size={14} />
              <span>إعادة ضبط إعدادات العرض للوضع الافتراضي</span>
            </button>
          </div>
        )}

        {/* TAB 2: CONTROLS & VIRTUAL JOYSTICK */}
        {activeTab === 'CONTROLS' && (
          <div className="bg-gray-900/80 border border-gray-800 rounded-xl p-3.5 flex flex-col gap-3">
            <div className="font-bold text-sm text-purple-400 flex items-center gap-1.5 border-b border-gray-800 pb-1.5">
              <Smartphone size={16} />
              <span>إعدادات عصا التحكم الافتراضية واللمس</span>
            </div>

            {/* Control Type Selector */}
            <div className="flex flex-col gap-1.5">
              <span className="text-gray-300">نمط التحكم المفضل:</span>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { id: 'JOYSTICK', label: 'العصا الدائرية 🕹️' },
                  { id: 'DPAD', label: 'أسهم الاتجاهات 🎛️' },
                  { id: 'TOUCH_FOLLOW', label: 'السحب المباشر 👆' },
                ].map((item) => (
                  <button
                    key={item.id}
                    onClick={() => {
                      soundManager.playSelect();
                      onUpdateSettings({
                        ...settings,
                        controlType: item.id as 'JOYSTICK' | 'DPAD' | 'TOUCH_FOLLOW',
                      });
                    }}
                    className={`py-2 px-1 rounded-lg border text-[11px] font-bold ${
                      settings.controlType === item.id
                        ? 'bg-purple-950 border-purple-500 text-purple-200 shadow-md'
                        : 'bg-gray-800 border-gray-700 text-gray-400'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Joystick Size */}
            {settings.controlType === 'JOYSTICK' && (
              <>
                <div className="flex flex-col gap-1.5 pt-2 border-t border-gray-800/60">
                  <span className="text-gray-300">حجم العصا الدائرية:</span>
                  <div className="grid grid-cols-3 gap-2">
                    {(['SMALL', 'MEDIUM', 'LARGE'] as DpadSize[]).map((sz) => {
                      const label = sz === 'SMALL' ? 'صغير' : sz === 'MEDIUM' ? 'متوسط' : 'كبير';
                      return (
                        <button
                          key={sz}
                          onClick={() => {
                            soundManager.playSelect();
                            onUpdateSettings({ ...settings, joystickSize: sz });
                          }}
                          className={`py-1.5 rounded-lg border text-[11px] font-bold ${
                            settings.joystickSize === sz
                              ? 'bg-purple-950 border-purple-500 text-purple-200'
                              : 'bg-gray-800 border-gray-700 text-gray-400'
                          }`}
                        >
                          {label}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Joystick Opacity */}
                <div className="flex flex-col gap-1.5 pt-2 border-t border-gray-800/60">
                  <div className="flex items-center justify-between text-gray-300">
                    <span>شفافية العصا:</span>
                    <span className="font-pixel text-[10px] text-purple-300">
                      {Math.round(settings.joystickOpacity * 100)}%
                    </span>
                  </div>
                  <input
                    type="range"
                    min="0.3"
                    max="1.0"
                    step="0.05"
                    value={settings.joystickOpacity}
                    onChange={(e) =>
                      onUpdateSettings({ ...settings, joystickOpacity: parseFloat(e.target.value) })
                    }
                    className="w-full accent-purple-500 h-1.5 bg-gray-700 rounded-lg cursor-pointer"
                  />
                </div>

                {/* Joystick Position */}
                <div className="flex flex-col gap-1.5 pt-2 border-t border-gray-800/60">
                  <span className="text-gray-300">موضع العصا:</span>
                  <div className="grid grid-cols-3 gap-2">
                    {[
                      { id: 'BOTTOM_LEFT', label: 'أسفل يسار' },
                      { id: 'BOTTOM_CENTER', label: 'أسفل وسط' },
                      { id: 'BOTTOM_RIGHT', label: 'أسفل يمين' },
                    ].map((pos) => (
                      <button
                        key={pos.id}
                        onClick={() => {
                          soundManager.playSelect();
                          onUpdateSettings({
                            ...settings,
                            joystickPosition: pos.id as 'BOTTOM_LEFT' | 'BOTTOM_RIGHT' | 'BOTTOM_CENTER',
                          });
                        }}
                        className={`py-1.5 rounded-lg border text-[11px] font-bold ${
                          settings.joystickPosition === pos.id
                            ? 'bg-purple-950 border-purple-500 text-purple-200'
                            : 'bg-gray-800 border-gray-700 text-gray-400'
                        }`}
                      >
                        {pos.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Joystick Sensitivity */}
                <div className="flex flex-col gap-1.5 pt-2 border-t border-gray-800/60">
                  <span className="text-gray-300">حساسية استجابة العصا (Sensitivity):</span>
                  <div className="grid grid-cols-4 gap-1.5">
                    {[
                      { val: 0.8, label: '0.8x هادئ' },
                      { val: 1.0, label: '1.0x عادي' },
                      { val: 1.25, label: '1.25x سريع' },
                      { val: 1.5, label: '1.5x فائق' },
                    ].map((sens) => (
                      <button
                        key={sens.val}
                        onClick={() => {
                          soundManager.playSelect();
                          onUpdateSettings({ ...settings, joystickSensitivity: sens.val });
                        }}
                        className={`py-1.5 rounded-lg border text-[10px] font-bold ${
                          (settings.joystickSensitivity || 1.0) === sens.val
                            ? 'bg-purple-950 border-purple-500 text-purple-200'
                            : 'bg-gray-800 border-gray-700 text-gray-400'
                        }`}
                      >
                        {sens.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Floating Joystick Toggle */}
                <div className="flex items-center justify-between pt-2 border-t border-gray-800/60">
                  <div>
                    <span className="text-gray-300 block font-semibold">عصا عائمة (Floating):</span>
                    <span className="text-[10px] text-gray-500">تظهر العصا في النقطة التي تلمسها مباشرة</span>
                  </div>
                  <button
                    onClick={() => {
                      soundManager.playSelect();
                      onUpdateSettings({ ...settings, joystickFloating: !settings.joystickFloating });
                    }}
                    className={`py-1 px-3 rounded text-[11px] font-bold border transition-all ${
                      settings.joystickFloating
                        ? 'bg-purple-950 border-purple-500 text-purple-200'
                        : 'bg-gray-800 border-gray-700 text-gray-400'
                    }`}
                  >
                    {settings.joystickFloating ? 'مفعل' : 'معطل'}
                  </button>
                </div>
              </>
            )}

            {/* Haptic Feedback */}
            <div className="flex items-center justify-between pt-2 border-t border-gray-800/60">
              <div className="flex items-center gap-1.5">
                <Vibrate size={15} className="text-purple-400" />
                <span className="text-gray-300">الاهتزاز عند تلقي الضرر:</span>
              </div>
              <button
                onClick={() => {
                  soundManager.playSelect();
                  onUpdateSettings({ ...settings, hapticFeedback: !settings.hapticFeedback });
                }}
                className={`py-1 px-3 rounded text-[11px] font-bold border transition-all ${
                  settings.hapticFeedback
                    ? 'bg-purple-950 border-purple-500 text-purple-200'
                    : 'bg-gray-800 border-gray-700 text-gray-400'
                }`}
              >
                {settings.hapticFeedback ? 'مفعل' : 'معطل'}
              </button>
            </div>
          </div>
        )}

        {/* TAB 3: AUDIO & DIFFICULTY */}
        {activeTab === 'AUDIO' && (
          <div className="bg-gray-900/80 border border-gray-800 rounded-xl p-3.5 flex flex-col gap-3">
            <div className="font-bold text-sm text-amber-400 flex items-center gap-1.5 border-b border-gray-800 pb-1.5">
              <Music size={16} />
              <span>الصوت ومستوى الصعوبة</span>
            </div>

            {/* Music */}
            <div className="flex flex-col gap-1.5">
              <div className="flex items-center justify-between">
                <span className="text-gray-300">موسيقى الخلفية (Chiptune)</span>
                <button
                  onClick={() => {
                    const next = !settings.musicEnabled;
                    soundManager.toggleMusic(next);
                    onUpdateSettings({ ...settings, musicEnabled: next });
                  }}
                  className={`px-3 py-1 rounded text-[11px] font-bold border transition-all ${
                    settings.musicEnabled
                      ? 'bg-amber-950 border-amber-500 text-amber-200'
                      : 'bg-gray-800 border-gray-700 text-gray-400'
                  }`}
                >
                  {settings.musicEnabled ? 'مفعلة' : 'معطلة'}
                </button>
              </div>
              <input
                type="range"
                min="0"
                max="1"
                step="0.05"
                value={settings.musicVolume}
                onChange={(e) => {
                  const val = parseFloat(e.target.value);
                  soundManager.setMusicVolume(val);
                  onUpdateSettings({ ...settings, musicVolume: val });
                }}
                disabled={!settings.musicEnabled}
                className="w-full accent-amber-500 h-1.5 bg-gray-700 rounded-lg cursor-pointer"
              />
            </div>

            {/* SFX */}
            <div className="flex flex-col gap-1.5 pt-1 border-t border-gray-800/60">
              <div className="flex items-center justify-between">
                <span className="text-gray-300">المؤثرات الصوتية (SFX)</span>
                <button
                  onClick={() => {
                    const next = !settings.sfxEnabled;
                    soundManager.toggleSfx(next);
                    onUpdateSettings({ ...settings, sfxEnabled: next });
                  }}
                  className={`px-3 py-1 rounded text-[11px] font-bold border transition-all ${
                    settings.sfxEnabled
                      ? 'bg-amber-950 border-amber-500 text-amber-200'
                      : 'bg-gray-800 border-gray-700 text-gray-400'
                  }`}
                >
                  {settings.sfxEnabled ? 'مفعلة' : 'معطلة'}
                </button>
              </div>
              <input
                type="range"
                min="0"
                max="1"
                step="0.05"
                value={settings.sfxVolume}
                onChange={(e) => {
                  const val = parseFloat(e.target.value);
                  soundManager.setSfxVolume(val);
                  onUpdateSettings({ ...settings, sfxVolume: val });
                }}
                disabled={!settings.sfxEnabled}
                className="w-full accent-amber-500 h-1.5 bg-gray-700 rounded-lg cursor-pointer"
              />
            </div>

            {/* Difficulty */}
            <div className="flex flex-col gap-1.5 pt-2 border-t border-gray-800/60">
              <span className="text-gray-300">مستوى الصعوبة العام:</span>
              <div className="grid grid-cols-3 gap-2">
                {(['EASY', 'NORMAL', 'HARD'] as Difficulty[]).map((diff) => {
                  const label = diff === 'EASY' ? 'سهل' : diff === 'NORMAL' ? 'عادي' : 'صعب';
                  return (
                    <button
                      key={diff}
                      onClick={() => {
                        soundManager.playSelect();
                        onUpdateSettings({ ...settings, difficulty: diff });
                      }}
                      className={`py-1.5 rounded-lg border font-bold text-xs ${
                        settings.difficulty === diff
                          ? 'bg-amber-950 border-amber-500 text-amber-200'
                          : 'bg-gray-800 border-gray-700 text-gray-400'
                      }`}
                    >
                      {label}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: BACKUP & PROGRESS MANAGEMENT */}
        {activeTab === 'BACKUP' && (
          <div className="bg-gray-900/80 border border-gray-800 rounded-xl p-3.5 flex flex-col gap-3">
            <div className="font-bold text-sm text-red-400 flex items-center gap-1.5 border-b border-gray-800 pb-1.5">
              <Trash2 size={16} />
              <span>إدارة التقدم والنسخ الاحتياطي</span>
            </div>

            <p className="text-gray-400 text-[11px] leading-relaxed">
              يمكنك نسخ وحفظ بيانات تقدمك كاملة (المستوى، السكنات، العملات، والزعماء) كملف نصي، أو استعادتها في أي وقت.
            </p>

            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={handleExportBackup}
                className="py-2 px-3 bg-cyan-900/70 hover:bg-cyan-800 active:scale-95 border border-cyan-500 rounded-lg text-cyan-200 text-xs font-bold flex items-center justify-center gap-1.5 transition-all"
              >
                <Download size={14} />
                <span>تصدير نسخة احتياطية</span>
              </button>

              <button
                onClick={handleImportBackup}
                className="py-2 px-3 bg-purple-900/70 hover:bg-purple-800 active:scale-95 border border-purple-500 rounded-lg text-purple-200 text-xs font-bold flex items-center justify-center gap-1.5 transition-all"
              >
                <Upload size={14} />
                <span>استيراد نسخة سابقة</span>
              </button>
            </div>

            {/* Reset Progress Section */}
            <div className="pt-2 border-t border-gray-800/80">
              {!showResetConfirm ? (
                <button
                  onClick={() => setShowResetConfirm(true)}
                  className="w-full py-2 bg-red-950/40 hover:bg-red-900/60 active:scale-95 border border-red-700 rounded-lg text-red-300 font-bold text-xs flex items-center justify-center gap-1.5 transition-all"
                >
                  <AlertTriangle size={15} />
                  <span>إعادة تعيين التقدم بالكامل</span>
                </button>
              ) : (
                <div className="p-3 bg-red-950 border border-red-500 rounded-lg flex flex-col gap-2">
                  <span className="text-xs font-bold text-red-200 text-center">
                    هل أنت متأكد من مسح جميع بيانات الحفظ والبدء من الصفر؟
                  </span>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => {
                        soundManager.playDamage();
                        onResetProgress();
                        setShowResetConfirm(false);
                      }}
                      className="py-1.5 bg-red-600 hover:bg-red-500 text-white rounded font-bold text-xs"
                    >
                      نعم، امسح كل شيء
                    </button>
                    <button
                      onClick={() => setShowResetConfirm(false)}
                      className="py-1.5 bg-gray-800 hover:bg-gray-700 text-gray-300 rounded text-xs"
                    >
                      إلغاء
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
