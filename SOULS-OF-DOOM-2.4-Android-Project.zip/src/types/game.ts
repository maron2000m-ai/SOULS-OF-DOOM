export type GameScreen = 
  | 'MENU' 
  | 'BATTLE' 
  | 'BOSS_SELECT' 
  | 'BESTIARY'
  | 'SHOP' 
  | 'SETTINGS' 
  | 'PROFILE'
  | 'INFO'
  | 'SOUL_NEWS'
  | 'BATTLE_HISTORY'
  | 'CHALLENGES'
  | 'ANDROID_PACKAGE';

export type BattlePhase = 
  | 'MENU_SELECT'        // Player choosing Fight, Check, Item, Mercy
  | 'ATTACK_MINIGAME'   // Timing cursor minigame
  | 'ENEMY_DIALOGUE'    // Boss speech before attacking
  | 'DODGE_PHASE'       // Bullet hell dodge in the box
  | 'ITEM_SELECT'       // Choosing item from inventory
  | 'CHECK_INFO'        // Reading boss stats and tactical tips
  | 'MERCY_TRY'         // Sparing attempt
  | 'VICTORY'           // Boss defeated
  | 'GAME_OVER';        // Player HP = 0

export type Difficulty = 'EASY' | 'NORMAL' | 'HARD';
export type DpadSize = 'SMALL' | 'MEDIUM' | 'LARGE';
export type HeartScale = 'NORMAL' | 'LARGE' | 'XLARGE';
export type UiScale = 'SMALL' | 'NORMAL' | 'LARGE';

export type PerformancePreset = 'SAVER' | 'BALANCED' | 'QUALITY';
export type GraphicsQuality = 'LOW' | 'MEDIUM' | 'HIGH';
export type ShadowQuality = 'OFF' | 'LOW' | 'HIGH';

export interface Projectile {
  id: string;
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  type: 
    | 'bone' 
    | 'fireball' 
    | 'laser' 
    | 'orb' 
    | 'star' 
    | 'void_blade' 
    | 'time_gear'
    | 'scythe_arc'
    | 'spectral_soul'
    | 'dragon_orb'
    | 'lightning_beam'
    | 'shockwave_ring'
    | 'royal_bone'
    | 'giant_bone';
  color: string;
  damage: number;
  rotation?: number;
  vRot?: number;
  width?: number;
  height?: number;
  warningTime?: number;
  active?: boolean;
  opacity?: number;
  phase?: number;
  homing?: boolean;
  life?: number;
}

export interface HazardZone {
  id: string;
  x: number;
  y: number;
  width: number;
  height: number;
  isCircle?: boolean;
  radius?: number;
  warningDuration: number;
  activeDuration: number;
  timer: number;
  damage: number;
  color: string;
  label?: string;
}

export interface BossAttackPattern {
  name: string;
  duration: number; // in seconds
  spawnInterval: number; // in seconds
  type: 
    | 'bones_cross' 
    | 'flame_rain' 
    | 'blade_sweep' 
    | 'time_gears' 
    | 'void_vortex' 
    | 'laser_barrage' 
    | 'scythe_reap'
    | 'spectral_summon'
    | 'dragon_cross_fire'
    | 'dragon_apocalypse'
    | 'bone_king_barrage'
    | 'mixed_madness';
  descriptionAr: string;
  warningHintAr?: string;
}

export interface BossPhase {
  phaseNumber: number;
  hpThresholdPercent: number;
  dialogue: string;
  attackPatterns: BossAttackPattern[];
  speedMultiplier: number;
  auraColor: string;
}

export interface BossData {
  id: string;
  number: number;
  nameAr: string;
  titleAr: string;
  descriptionAr: string;
  maxHp: number;
  rewardCoins: number;
  rewardXp: number;
  colorTheme: string;
  secondaryColor: string;
  bgParticles: 'bones' | 'flames' | 'void' | 'gears' | 'stars' | 'souls' | 'lightning';
  phases: BossPhase[];
  checkInfo: {
    attack: string;
    defense: string;
    description: string;
    strategy: string;
    discoveredPatterns: string[];
  };
  mercyQuote: string;
  mercyHpPercentThreshold: number;
  victoryTitle?: string;
}

export interface InventoryItem {
  id: string;
  nameAr: string;
  descriptionAr: string;
  type: 'HEAL_30' | 'HEAL_FULL' | 'SHIELD_BUFF';
  quantity: number;
  iconName: string;
}

export interface SoulSkin {
  id: string;
  nameAr: string;
  descriptionAr: string;
  price: number;
  primaryColor: string;
  glowClass: string;
  particleColor: string;
  trailType?: 'flame' | 'ice' | 'shadow' | 'galaxy' | 'gold' | 'toxic' | 'blue' | 'purple' | 'none';
  unlockCondition?: string;
}

export interface Achievement {
  id: string;
  titleAr: string;
  descriptionAr: string;
  rewardCoins: number;
  rewardXp: number;
  rewardTitle?: string;
  icon: string;
  isUnlocked: boolean;
  progress?: number;
  maxProgress?: number;
}

export interface SoulChallenge {
  id: string;
  number: number;
  titleAr: string;
  descriptionAr: string;
  conditionAr: string;
  rewardCoins: number;
  rewardTitle?: string;
  rewardFrame?: string;
  rewardTrail?: string;
  isCompleted: boolean;
  isClaimed: boolean;
}

export interface BattleHistoryEntry {
  bossId: string;
  bossNameAr: string;
  encounters: number;
  wins: number;
  losses: number;
  lastResult: 'VICTORY' | 'DEFEAT' | 'NONE';
  lastDurationSeconds: number;
  lastItemsUsed: number;
  winStreak: number;
  bestTimeSeconds?: number;
  lastDamageTaken?: number;
  lastVictoryDate?: string;
}

export interface DailyRewardsData {
  lastClaimDate: string; // 'YYYY-MM-DD'
  streak: number;        // 1 to 7
  bossMilestoneClaimed: boolean;
}

export interface BossRecord {
  wins: number;
  losses: number;
  bestTimeSeconds?: number;
}

export interface BattleStats {
  damageTaken: number;
  hitsReceived: number;
  itemsUsed: number;
  durationSeconds: number;
  bossId: string;
  isVictory: boolean;
  earnedCoins: number;
  earnedXp: number;
  dodgedProjectilesCount?: number;
}

export interface PlayerSaveData {
  // Identity & Profile
  playerName: string;
  avatar: string;
  avatarFrame: string;
  profileBg: string;
  level: number;
  xp: number;
  equippedTitle: string;
  unlockedTitles: string[];
  unlockedFrames: string[];
  unlockedBackgrounds: string[];
  
  // Combat & Stats
  currentHp: number;
  maxHp: number;
  baseMaxHp: number;
  hpUpgradesBought: number; // Max 3
  soulCoins: number;
  unlockedBossNumber: number; // 1 to 7
  defeatedBosses: string[];
  selectedBossId: string;
  totalWins: number;
  totalLosses: number;
  totalCoinsEarned: number;
  totalCoinsSpent: number;
  playtimeSeconds: number;
  hardestBossDefeated: string;
  bossRecords: Record<string, BossRecord>;
  battleHistory: Record<string, BattleHistoryEntry>;

  // Cosmetics & Inventory
  inventory: InventoryItem[];
  equippedSkin: string;
  purchasedSkins: string[];
  equippedTrail: string;
  unlockedTrails: string[];
  equippedVictoryAura: string;
  unlockedVictoryAuras: string[];
  shieldActiveForBattles: number;

  // Progression, Daily & Challenges
  achievements: string[]; // IDs of unlocked achievements
  challenges: Record<string, { isCompleted: boolean; isClaimed: boolean; currentProgress?: number }>;
  dailyRewards: DailyRewardsData;

  // Update 2.1 News state
  hasReadNewsV21: boolean;
  lastSaveTimestamp: string;
}

export interface GameSettings {
  // Audio
  musicVolume: number;
  sfxVolume: number;
  musicEnabled: boolean;
  sfxEnabled: boolean;
  
  // Difficulty & Gameplay
  difficulty: Difficulty;
  hapticFeedback: boolean;

  // Controls (Touch & Virtual Joystick)
  controlType: 'JOYSTICK' | 'DPAD' | 'TOUCH_FOLLOW';
  joystickSize: 'SMALL' | 'MEDIUM' | 'LARGE';
  joystickOpacity: number; // 0.3 to 1.0
  joystickPosition: 'BOTTOM_LEFT' | 'BOTTOM_RIGHT' | 'BOTTOM_CENTER';
  joystickSensitivity: number; // 0.5 to 1.5, default 1.0
  joystickFloating: boolean; // default false
  dpadSize: DpadSize;

  // Display & Screen (العرض والشاشة)
  gameScale: number; // 0.85 to 1.25
  isFullscreen: boolean;
  autoFit: boolean;
  arenaScale: number; // 1.0, 1.15, 1.3
  heartScale: HeartScale;
  zenMode: boolean; // Hide non-essential UI during dodge
  uiScale: UiScale;

  // Performance & Anti-Lag (الأداء والسلاسة - Update 2.1)
  performancePreset: PerformancePreset;
  targetFps: 30 | 60;
  reduceParticles: boolean;
  reduceBloom: boolean;
  shadowQuality: ShadowQuality;
  animatedBackground: boolean;
  screenShakeEnabled: boolean;
  graphicsQuality: GraphicsQuality;
  showPerfHud: boolean; // Toggleable real-time FPS and simulation benchmark
}
