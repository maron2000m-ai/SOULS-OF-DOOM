import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.soulsofdoom.pixelgame',
  appName: 'SOULS OF DOOM',
  webDir: 'dist',
  android: { allowMixedContent: false },
  plugins: { SplashScreen: { launchShowDuration: 0 } },
};
export default config;
